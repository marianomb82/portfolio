<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=(isset($_REQUEST['usuario'])) ? $_REQUEST['usuario'] : false;
	
	include ('pdf/class.ezpdf.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
								<?php 
						 				// Conectar con el servidor de base de datos
									//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
									or die ("No se puede conectar con el servidor");
					
									$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
									$id_pista=(isset($_REQUEST['id_pista'])) ? $_REQUEST['id_pista'] : false;
									$nombre_pista=(isset($_REQUEST['nombre_pista'])) ? $_REQUEST['nombre_pista'] : false;
											$error=false;
											
											if(isset($enviar))
											{
												if($id_pista=="-1")
												{
													$error=true;
													$errores["pista"]=" No existe pistas para seleccionar";
												}
											}
											if(isset($enviar) && $error==false)
											{										

												
												$instruccion1 = "select * from actividad, pista where actividad.ID_PISTA like '".$id_pista."' and pista.ID_PISTA=actividad.ID_PISTA order by NOMBRE_AC";
												
												$consulta1 = mysqli_query($conexion,$instruccion1) or die ("No se ha podido hacer la consulta");
												
												$nfilastotal1 = mysqli_num_rows($consulta1);
												
												if($nfilastotal1>0)
												{
								?>
											
											<center><h2>El número de cursos que ha impartido la escuela en la pista.</h2></center>
											<center>	
											<div class="correo">
							 				<form name="consulta7.php" method="post" enctype="multipart/form-data">
								 				<fieldset class="margen">
													
													<table cellpadding="4">
														<tr>
															<th>Actividad</th>
															<th>Fecha Incio</th>
															<th>Fecha Final</th>
															<th>Nº Plazas</th>
															<th>Monitor</th>
															<th>Pista</th>
														</tr>	
																					
												<?php 
															for($i=0; $i<$nfilastotal1; $i++)
															{
																$resultado1 = mysqli_fetch_array($consulta1);
																
												?>
													<tr>
														<td><?php echo $resultado1['NOMBRE_AC']?></td>
														<td><?php $fecha_f = date("d/n/Y",$resultado1['FECHA_IN_AC']); echo $fecha_f;?></td>
														<td><?php $fecha_f = date("d/n/Y",$resultado1['FECHA_FIN_AC']); echo $fecha_f;?></td>
														<td><?php echo $resultado1['PLAZAS']?></td>
														<td>
															<?php 
																$instruccion2 = "select * from monitor where ID_MON like '".$resultado1['ID_MON']."'";
																
																$consulta2 = mysqli_query($conexion,$instruccion2) or die ("No se puede hacer la consulta");
																
																$resultado2 = mysqli_fetch_array($consulta2);
																
																echo $resultado2['NOMBRE_MON']. " ".$resultado2['APELLIDOS_MON']."";
															?>
														</td>
														<td><?php echo $resultado1['NOMBRE_PISTA']?></td>
														
														
													</tr>
												<?php 
													}
										
										print "</table>";
										print "<table>";
										print "<tr><td>&nbsp;</td></tr>";
										print "	<td><b>Total Cursos:  " .$nfilastotal1. "</b></td>";
										print "	</tr>";
										print "</table>";
										print "</fieldset>";
							 		print "</form>";
																							
									echo "</div>";
									echo "</center>";	
												echo "<center>";
												print "<div id='insertar'>";
												print "<table><tr><td><a href='pdf7.php?id_pista=".$id_pista."&nombre_pista=".$nombre_pista."' target='_new'><img src='imagenes/pdf.png' title='Crear PDF'></img></a></td></tr></table>";
												print "<p class='necesario'><i>Pinche en el icono para crear el pdf.</i></p>";
												echo "</div>";
												echo "<center>";
												
											}
											else
											{
												print "No hay actividades";
											}
										?>
											
							<?php 	
						 			}
						 			else
									{
						?>
									<h2>El número de alumnos que ha realizado en un determinado curso</h2>
						 			<div class="correo">
						 				<form name="consulta7.php" method="post" enctype="multipart/form-data">
							 				<fieldset>
												<legend>Seleccione una Pista</legend>
												<table class="margen2">
													<tr><td>&nbsp;</td></tr>
													<tr>	
														<td>Pista :</td>
															<td>
																<select name="id_pista">
																	<?php 
																		$instruccion = "select * from pista order by NOMBRE_PISTA";
																		
																		$consulta = mysqli_query ($conexion,$instruccion) or die ("No se puede hacer la consulta");
																		
																		$nfilastotal = mysqli_num_rows($consulta);
																		
																		if($nfilastotal>0)
																		{
																			for($i=0; $i<$nfilastotal; $i++)
																			{
																				$resultado = mysqli_fetch_array($consulta);
																				
																				echo "<option value = '".$resultado['ID_PISTA']."'>".$resultado['NOMBRE_PISTA']."</option>";
																	?>
																				
																	<?php 
																			}
																		}
																		else
																		{
																			echo "<option value='-1'>No existe pistas</option>";
																		}
																	?>
																</select>
															</td>
															<td>
															<?php 
																if (trim($errores["actividad"])!= "")
																{
																	print ("<span class='error'>" . $errores["actividad"] . "</span>");
																}
															?>
															</td>
															<td><input type="submit" name="enviar" value="Crear Consulta"></input></td>
														</tr>
														
													<tr><td>&nbsp;</td></tr>
												</table>
											</fieldset>
						 				</form>	
						 			</div>
						 		<?php 
	 								}
								?>
							</div>	
				       </td>
				  	</tr>
	           </table>
	         </div>  
	        <div align="center">
					<?php include('includes/footerbis.php'); ?>
			</div>
		</div>
	</body>
</html>