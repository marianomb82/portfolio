<?php
//@utor: Mariano Martín
session_start();
$login = false;
$usuario = (isset($_SESSION['usuario'])) ? $_SESSION['usuario'] : false;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es" xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
	<title>Club Deportivo Sevilla</title>
	<link href="css/estilos.css" rel="stylesheet" type="text/css" media="screen" />
	<script language="javascript" type="text/javascript" src="js/precarga.js"></script>
</head>

<body onLoad="MM_preloadImages('imagenes/presentacion_on.png', 'imagenes/tarifa_on.png', 'imagenes/eventos_on.png','imagenes/actividades_on.png', 'imagenes/contacto_on.png', 'imagenes/login_on.png')">
	<div id="global">

		<?php include('includes/header.php'); ?>

		<div id="cuerpo">
			<div id="contenido">
				<div id="columna1" align="center">
					<img src="imagenes/login.png" border="0" alt="" style="margin-top:70px;" />
				</div>
				<div id="columna2">
					<h2>Acceso de usuarios</h2>

					<?php
					if (!empty($_REQUEST)) {
						$enviar = $_REQUEST['enviar'];
						$borrar = (isset($_REQUEST['borrar'])) ? $_REQUEST['borrar'] : false;
						$usuario = $_REQUEST['usuario'];
						$passwd = $_REQUEST['passwd'];
					}

					$error = false;

					if (isset($enviar)) {
						if (trim($usuario) == "") {
							$error = true;
							$errores['usuario'] = "Introduzca usuario.\n";
						}

						if (trim($passwd) == "") {
							$error = true;
							$errores['passwd'] = "Introduzca password.\n";
						}
						// Conectar con el servidor de base de datos
						//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die("No se puede conectar con el servidor");

						// // Seleccionar base de datos
						// $bd = mysqli_select_db("cds")
						// 	or die("No se puede seleccionar la base de datos");

						//código para introducir el usuario en la BD
						$instruccion = "select * from usuario where user like '" . $usuario . "'";


						//realizamos la consulta
						$consulta = mysqli_query($conexion, $instruccion)
							or die("El fallo en la consulta");

						$esta = mysqli_num_rows($consulta);

						if ($esta > 0) {
							$errores["usuario"] = "";


							//encriptamos la clave con $passwd y $cod
							$clave_enc = md5($passwd);

							//c�digo para introducir el usuario en la BD
							$instruccion = "select * from usuario where user like '" . $usuario . "' and password like '" . $clave_enc . "'";

							//realizamos la consulta
							$consulta = mysqli_query($conexion, $instruccion)
								or die("El fallo en la consulta");

							$esta2 = mysqli_num_rows($consulta);
						} else
											if (($esta == 0) && ($usuario != "")) {
							$error = true;
							$errores["usuario"] = "Usuario no registrado";
						}
						if (!isset($esta2) || $esta2 == 0) {
							$error = true;
							$errores["passwd"] = "Contraseña inválida";
						}
					}

					if (isset($enviar) && ($error == false) && ($esta2 > 0)) {
						$_SESSION['usuario'] = $usuario;

						$instruccion2 = "select * from usuario where user like '" . $usuario . "'";
						//realizamos la consulta

						$consulta2 = mysqli_query($conexion, $instruccion2);
						$resultado2 = mysqli_fetch_array($consulta2);
						$_SESSION['tipo'] = $resultado2['TIPO_US'];

						print("<h3>Logando al usuario <i>" . $usuario . "</i>...</h3>");
						print("<div class='margen'>&nbsp;</div>");
						print("<div><img src='imagenes/logado.png' /></div>");

						echo "<META HTTP-EQUIV='refresh' CONTENT='4; URL=index_priv.php'>";

						//cerramos la BD
						$cerrar = mysqli_close($conexion);
					} else {


					?>
						<form action="login.php" method="post">


							<br />
							<table class="margen2">
								<tr>
									<td>Usuario: </td>
									<td>
										<input type="text" name="usuario" size="20" maxlength="20" value="<?php print $usuario; ?>">
										<?php
										if (isset($errores['usuario']) && $errores['usuario'] != "")
											print "<span class='error'>" . $errores['usuario'] . "</span>"
										?>
									</td>
								</tr>
								<tr>
									<td>Password: </td>
									<td>
										<input type="password" name="passwd" size="20" maxlength="20" value="<?php print $passwd; ?>">
										<?php
										if (isset($errores['passwd']) && $errores['passwd'] != "")
											print "<span class='error'>" . $errores['passwd'] . "</span>"
										?>
									</td>
								</tr>
							</table>
							<br />
							<div class="margen3"><input type="submit" name="enviar" value="Acceder"><input type="reset" name="borrar" value="Borrar Datos"></div>

						</form>
					<?php
					}

					?>
				</div>
			</div>
		</div>

		<?php include('includes/footer.php'); ?>

	</div>
</body>

</html>