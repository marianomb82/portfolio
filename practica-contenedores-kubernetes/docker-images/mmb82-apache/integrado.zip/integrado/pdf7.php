<?php
	//@utor: Mariano Mart�n
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	


	include ('pdf/class.ezpdf.php');
	
	// Conectar con el servidor de base de datos
							//variables para la conexi�n
							$servername = getenv("DB_HOST");
							$database = getenv("DB_NAME");
							$username = getenv("DB_USER");
							$password = getenv("DB_PASSWORD");
						
							$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
	
	
	$pdf =& new Cezpdf('a4');
	$pdf->selectFont('pdf/fonts/Helvetica.afm');
	$pdf->ezSetCmMargins(1,1,1.5,1.5);
	
	$id_pista = $_REQUEST['id_pista'];
	$nombre_pista = $_REQUEST['nombre_pista'];
	
	$instruccion = "select * from pista where ID_PISTA like '".$id_pista."'";
	
	$consulta = mysql_query($instruccion, $conexion);
	
	$resul = mysql_fetch_array($consulta);
	
	$nombre_pista = $resul['NOMBRE_PISTA'];
	
		
	$fecha_f = date("n - Y",$b_fecha_i);
		
	$datacreator = array (
                    'Title'=>'Los cursos que ha impartido la escuela en .'.$nombre_pista,
                    'Author'=>'Mariano Mart�n Bugar�n',
                    'Subject'=>'Club Deportivo Sevilla',
                    
						);

	$pdf->addInfo($datacreator);
	$pdf->ezText("Los cursos que ha impartido la escuela en ".$nombre_pista, 30);
	
	$instruccion = "select * from pista where ID_PISTA like '".$id_pista."'";
	
	$consulta = mysql_query($instruccion, $conexion);
	
	$resul = mysql_fetch_array($consulta);
	
	$nombre_pista = $resul['NOMBRE_PISTA'];
	
	$instr="select * from actividad, monitor, pista where actividad.ID_PISTA like '".$id_pista."' and actividad.ID_MON=monitor.ID_MON and pista.ID_PISTA=actividad.ID_PISTA order by NOMBRE_AC asc";
		
	$cons=mysql_query($instr,$conexion)
		or die("Fallo en Consulta");
	$num=mysql_num_rows($cons);
	for($i=0;$i<$num;$i++)
	{
		$datatmp=mysql_fetch_array($cons);
		$fecha_i = date("d/n/Y",$datatmp['FECHA_IN_AC']);
		$fecha_f = date("d/n/Y",$datatmp['FECHA_FIN_AC']);
		$nombre = $datatmp['NOMBRE_MON']." ".$datatmp['APELLIDOS_MON']."";
		$data[] = array_merge($datatmp, array('num'=>$i+1), array('nombre'=>$nombre), array('FECHA_IN_AC'=>$fecha_i), array('FECHA_FIN_AC'=>$fecha_f));
		//$data[] = mysql_fetch_array($cons);
	}
	$titles = array(  
		'num'=>'<b>Num</b>', 
		'NOMBRE_AC'=>'<b>Nombre</b>', 
		'FECHA_IN_AC'=>'<b>Fecha Inicio</b>', 
		'FECHA_FIN_AC'=>'<b>Fecha Final</b>', 
		'PLAZAS'=>'<b>N� Plazas</b>', 
		'nombre'=>'<b>Monitor</b>',
		'ANCHO'=>'<b>Ancho(m)</b>',
		'LARGO'=>'<b>Largo(m)</b>',
	);
	$options = array(
                'shadeCol'=>array(0.9,0.9,0.9),
                'xOrientation'=>'center',
                'width'=>500
    );
	$pdf->ezText("\n\n\n", 10);
	$pdf->ezTable($data,$titles,'',$options );
	$pdf->ezText("\n\n\n",10);
	$pdf->ezText("<b>Total Cursos:</b> ".$num,10);
	$pdf->ezText("<b>Fecha:</b> ".date("d/m/Y"),10);
	$pdf->ezText("<b>Hora:</b> ".date("H:i:s")."\n\n",10);
	$pdf->ezStream();
?>


	
