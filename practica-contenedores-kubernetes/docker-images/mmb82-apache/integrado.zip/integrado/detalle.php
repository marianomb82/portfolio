<?php
	//@utor: Mariano Mart�n
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
		
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<title>Proyecto 11M</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>

	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo.jpg" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulo.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
				                	<?php if($login){ 
										print("<tr><td id='bienvenida'><p>Bienvenid@ " . $_SESSION['usuario'] . "</p></td></tr>");
				                	} ?>
									
				                	<tr><td><a href="index.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Presentacion','','imagenes/presentacion_over.png',1)"><img src="imagenes/presentacion.png" alt="Presentacion" name="Presentacion"/></a></td></tr>
				                    <?php if(!$login){ ?>
									<tr><td><a href="login.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Login','','imagenes/login_over.png',1)"><img src="imagenes/login.png" alt="Login" name="Login"  /></a></td></tr>
				   					<tr><td><a href="mostrar_encuesta.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Encuesta','','imagenes/encuesta_over.png',1)"><img src="imagenes/encuesta.png" alt="Encuesta" name="Encuesta" /></a></td></tr>
				   					<tr><td><a href="registro.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Alta','','imagenes/alta_over.png',1)"><img src="imagenes/alta.png" alt="Alta" name="Alta" /></a></td></tr>
									<?php } else { ?>
				                    <tr><td><a href="album.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Album','','imagenes/album_over.png',1)"><img src="imagenes/album.png" alt="Album" name="Album" /></a></td></tr>
				                    <tr><td><a href="agenda.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Agregar','','imagenes/agregar_over.png',1)"><img src="imagenes/agregar.png" alt="Agregar" name="Agregar" /></a></td></tr>
				                    <tr><td><a href="listar.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Listar','','imagenes/listar_over.png',1)"><img src="imagenes/listar.png" alt="Listar" name="Listar" /></a></td></tr>
				                    <tr><td><a href="salir.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Salir','','imagenes/salir_over.png',1)"><img src="imagenes/salir.png" alt="Salir" name="Salir" /></a></td></tr>
				                    <?php } ?>
				                </table>
		            		</div>
						</td>
						<td valign="top">

							<div id="contenido">
								<?php 
									if($usuario=="")
									{
										print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
										print ("<div class='margen'>&nbsp;</div>");
										print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
									}	
								else
								{
								
									$usuario=$_SESSION['usuario'];
									$password=$_REQUEST['password'];
									$id=$_REQUEST['id'];		
									$volver=$_REQUEST['volver'];			
								
									// Conectar con el servidor de base de datos
							//variables para la conexi�n
							$servername = getenv("DB_HOST");
							$database = getenv("DB_NAME");
							$username = getenv("DB_USER");
							$password = getenv("DB_PASSWORD");
						
							$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
								
									$instruccion = "select * from agenda where usuario='$usuario' and id='$id'";
										
									// Enviar consulta
									      
									      $consul = mysql_query ($instruccion, $conexion)
									         or die ("Fallo en la consulta");
								
								   // Mostrar resultados de la consulta
								      $nfilas = mysql_num_rows ($consul);
						      
								if ($nfilas > 0)
						      	{
						        	$resul = mysql_fetch_array ($consul);
						                      		
						         	print("<h1>Detalles del usuario</h1>");
									print("<table id='detalle'>");  
						         	print ("<tr><td><b>Nombre: </b>". $resul['nombre'] ."</td></tr>");  
									if($resul['edad']!="")
										print ("<tr><td><b>Edad: </b>". $resul['edad'] ."</td></tr>");
									if($resul['sexo']!="")
										print ("<tr><td><b>Sexo: </b>". $resul['sexo'] ."</td></tr>");
									print ("<tr><td><b>Email: </b>". $resul['email'] ."</td></tr>");
									if($resul['telefono']!="")
										print ("<tr><td><b>Tel�fono: </b>". $resul['telefono'] ."</td></tr>");
									if($resul['categoria']!="")
										print ("<tr><td><b>Categor�a: </b>". $resul['categoria'] ."</td></tr>");
									if($resul['comentario']!="")
										print ("<tr><td><b>Comentario: </b>". $resul['comentario'] ."</td></tr>");
									if($resul['fotografia']!="")
										print ("<tr><td><a href=".$resul['fotografia']." target=\"_blank\"><center><img src=".$resul['fotografia']." width='150' height='150' title=\"Pinche para ver la fotograf�a\" alt=\"IMAGEN\"></center></a></td></tr>");
							    	print("</table>");  
						      	}
							
								// Cerrar conexi�n
									mysql_close ($conexion);
								}
								?>
										
							</div>
				            <div id="firma">
				        		<p align="center">&nbsp;<br />Realizado por Mariano Mart�n Bugar�n</p>
				        	</div>
				        </td>
				  	</tr>
	           </table>
		</div>
	</body>
</html>
