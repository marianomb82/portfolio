<?php
	//@utor: Mariano Mart�n
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	include ("lib/funciones.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 		
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
							<?php 
								if($usuario=="")
								{
									print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
									print ("<div class='margen'>&nbsp;</div>");
									print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
								}	
								else
								{
									/// Conectar con el servidor de base de datos
							//variables para la conexi�n
							$servername = getenv("DB_HOST");
							$database = getenv("DB_NAME");
							$username = getenv("DB_USER");
							$password = getenv("DB_PASSWORD");
						
							$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
													
									$enviar=$_REQUEST['enviar'];
									$multa=0;
									$importe=$_REQUEST['importe'];
									$dia1=$_REQUEST['dia1'];
									$mes1=$_REQUEST['mes1'];
									$a�o1=$_REQUEST['a�o1'];
									$devuelto=$_REQUEST['devuelto'];
									$error=false;
									
									
									if (isset($enviar))
									{
																		
										$fecha_vieja= date("d/n/Y",$_SESSION['fecha']);
										unset ($_SESSION['fecha']);
										
										$k = explode ("/", $fecha_vieja);
										
										$fecha_f = gmmktime(0,0,0,$mes1,$dia1,$a�o1);
										
										if(checkdate($mes1,$dia1,$a�o1))
										{
											if($fecha_f<$fecha_vieja)
											{
												$error=true;
							      				$errores["fecha"]="�La fecha a modificar tiene que ser superior!";
											}
										}
										else
										{
											$error=true;
											$errores["fecha"]="Fecha Incorrecta";
										}
														
										$dias_multa = calculo_dia($k[0], $k[1], $k[2], $dia1, $mes1, $a�o1);
										
										$dias_multa--;
										
										if($dias_multa==0)
										{
											$dias_multa++;
										}
																			
										if($devuelto=="No")
										{
											$error=true;
						      				$errores["devuelto"]="�Para modificar el alquiler debe de ser entregado el material!";
										}
													
									}
									
									if (isset($enviar) && $error==false)
									{
	
										$instruccion5 = "select * from material where ID_MAT like '".$_SESSION['ID_MAT']."'";
					
										$consulta5 = mysql_query($instruccion5, $conexion)or die ("No se puede hacer la consulta5");
											
										$resultado5 = mysql_fetch_array ($consulta5);
										
										$fecha_vieja = gmmktime(0,0,0,$k[1], $k[0], $k[2]);
										
										if($fecha_f!=$fecha_vieja)
										{
											$multa = $dias_multa * $_SESSION['cantidad'] * $resultado5['PRECIO_MAT'];
										}
										
										$importe = $_SESSION['importe'] + $multa;
										
										$instruccion2 = "update alquila set FECHA_FIN='".$fecha_f."', IMPORTE='".$importe."', MULTA='".$multa."', DEVUELTO='".$devuelto."' where ID_AL like '".$_REQUEST['id']."'";
										
										$consulta = mysql_query($instruccion2, $conexion) or die ("No se puede hacer la consulta2");
											
										$disponible = $resultado5['EN_ALMACEN'] + $_SESSION['cantidad'];
										
										$instruccion2 = "update material set EN_ALMACEN='".$disponible."' where ID_MAT like '".$_SESSION['ID_MAT']."'";
										
										$consulta = mysql_query($instruccion2, $conexion) or die ("No se puede hacer la consulta3");
						
										$instruccion6 ="INSERT INTO historial (`id_mat`, `id_so`, `fecha_inicio`, `cantidad`, `fecha_fin`, `importe`, `devuelto`, `multa`) select ID_MAT, ID_SO, FECHA_IN, CANTIDAD, FECHA_FIN, IMPORTE, DEVUELTO, MULTA from alquila where ID_AL like '".$_REQUEST['id']."'";
						
										$consulta = mysql_query($instruccion6, $conexion) or die ("No se puede hacer la consulta4");
											
										$num = mysql_insert_id($conexion);
											
										$instruccion7 = "delete from alquila where ID_AL like '".$_REQUEST['id']."'";
						
										$consulta = mysql_query($instruccion7, $conexion) or die ("No se puede hacer la consulta6");
											
										unset ($_SESSION['cantidad']);
										
										unset ($_SESSION['ID_MAT']);
										
										$instruccion9 = "select * from historial, material, socio where historial.id_mat=material.ID_MAT and historial.id_so=socio.ID_SO and id_historial like '".$num."'";
										
										$consulta9 = mysql_query($instruccion9, $conexion) or die ("No se puede hacer la consulta9");
										
										$resultado9 = mysql_fetch_array ($consulta9);
										
										print("<h1>Detalle modificado del Alquiler</h1>");
										print("<table id='detalle'>");  
							         	print ("<tr><td><b>Nombre: </b>". $resultado9['NOMBRE_MAT'] ."</td></tr>");  
										print ("<tr><td><b>DNI: </b>". $resultado9['DNI_SO'] ."</td></tr>");
										print ("<tr><td><b>Cantidad: </b>". $resultado9['cantidad'] ."</td></tr>");
										print ("<tr><td><b>Importe: </b>". $resultado9['importe'] ."</td></tr>");
										$fecha_i = date("d/n/Y",$resultado9['fecha_inicio']); 
										print ("<tr><td><b>Fecha Inicio: </b>".$fecha_i."</td></tr>");
										$fecha_f = date("d/n/Y",$resultado9['fecha_fin']); 
										print ("<tr><td><b>Fecha Fin: </b>".$fecha_f."</td></tr>"); 
										if($resultado9['multa']!=0)
											print ("<tr><td><b>Multa: </b>".$resultado9['multa']."</td></tr>");
								    	print("</table>");
										
										if($completo!="")
											print ("<tr><td><a href=".$completo." target=\"_blank\"><center><img src=".$completo." width='150' height='150' title=\"Pinche para ver la fotograf�a\" alt=\"IMAGEN\"></center></a></td></tr>");
								    	print("</table>"); 
	
										$close = mysql_close ($conexion);
										
									}
									else
									{
									$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
										
									$instruccion = "select * from alquila where ID_AL like '".$_REQUEST['id']."'";
									
									$consulta = mysql_query($instruccion, $conexion) or die ("No se puede hacer la consulta");
									
									$resultado = mysql_fetch_array ($consulta);
									
									$_SESSION['cantidad']=$resultado['CANTIDAD'];
				
									$_SESSION['importe']=$resultado['IMPORTE'];
							
				
										// Buscar nombre monitor
							        	
							        	$instruccion4 = "select * from material where ID_MAT like '".$resultado['ID_MAT']."'";
							        	
							        	$_SESSION['ID_MAT']=$resultado['ID_MAT'];
																	
										$consulta4 = mysql_query($instruccion4, $conexion)
											or die ("No se puede hacer la consulta4");
											
										$resultado4 = mysql_fetch_array ($consulta4);
										
										
										
										//Buscar nombre pista
										$instruccion5 = "select * from socio where ID_SO like '".$resultado['ID_SO']."'";
																	
										$consulta5 = mysql_query($instruccion5, $conexion)
											or die ("No se puede hacer la consulta5");
									
										$resultado5 = mysql_fetch_array ($consulta5);						
									?>
									<!-- Estructura de nuestro formulario y env�o de los datos a las variables junto con la llamada a la comprobaci�n de errores -->
									
									<h2>Modificar Alquiler</h2>
									
									<form action="modificar_alquiler.php?id=<?php print $_REQUEST['id'] ?>" method="post" enctype="multipart/form-data">
										<fieldset>
											<legend>Datos de alquiler</legend>
											<table class="margen2">
												<tr>	
													<td>Nombre: </td>
													<td>
														<?php print $resultado4['NOMBRE_MAT'];?>
													</td>
												</tr>
												<tr>	
													<td>DNI: </td>
													<td>
														<?php print $resultado5['DNI_SO'];?>
													</td>
												</tr>
												<tr>	
													<td>Cantidad: </td>
													<td>
														<?php print $resultado['CANTIDAD'];?>
													</td>
												</tr>
												<tr>	
													<td>Fecha inicio: </td>
													<td>
														<?php
															$fecha_i = date("d/n/Y",$resultado['FECHA_IN']); 
															print ("$fecha_i");
														?>
														
													</td>
												</tr>
												<tr>
													<td>Fecha Fin :</td>
													<td>
														<select name="dia1">
															<?php 
																$fecha1 = date("d/n/Y",$resultado['FECHA_FIN']);
																
																$_SESSION['fecha'] = $resultado['FECHA_FIN'];
																
																$pieces = explode("/", $fecha1);
																
																for ($i=1;$i<32;$i++)
																{
																	$a = $pieces[0];
																	
																	if($i<10)
																	{
																		$i="0".$i;
																	}
																	
																	if ($i == $a)
																	{
																		print "<option value='".$i."' selected>".$i."";
																	}
																	else
																	{
																		print "<option value='".$i."'>".$i."";
																	}
																	
																}
															?>
														</select>
														
														<select name="mes1">
															<?php 
																$meses="Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre";
																$num = explode(",", $meses);
																for ($i=0;$i<12;$i++)
																{
																	$b=$i+1;
																	$a = $pieces[1];
																	if ($b==$a)
																	{
																		print "<option value='".$b."' selected>".$num[$i]."";
																	}
																	else
																	{
																		print "<option value='".$b."'>".$num[$i]."";
																	}
																	
																}
															?>
														</select>
														
														<select name="a�o1">
															<?php 
																$a = $pieces[2];
																
																$b=$a+6;
																for ($i=$a;$i<$b;$i++)
																{
																	if($a==$i)
																	{
																		print "<option value='".$i."' selected>".$i."";
																	}
																	else
																	{
																		print "<option value='".$i."'>".$i."";
																	}
																	
																}
															?>
														</select>
														<?php 
														if (trim($errores["fecha_f"])!= "")
														{
															print ("<span class='error'>" . $errores["fecha_f"] . "</span>");
														}
													?>
													</td>
													
												</tr>
														
												<tr>	
													<td>Devuelto: </td>
													<td>
														<select name="devuelto">
															<option value="No" selected>No</option>
															<option value="Si">Si</option>
														</select>
														<?php 
														if (trim($errores["devuelto"])!= "")
														{
															print ("<span class='error'>" . $errores["devuelto"] . "</span>");
														}
														?>
													</td>
												</tr>
											</table>
										</fieldset>
									<div class="margen8"><input type="submit" name="enviar" value="Enviar Datos"><input type="reset" name="borrar" value="Borrar Datos"></div>
								</form>
							<?php 
								}
							}
							?>
						
			
			</div>
			</td>
			</tr>
			</table>
		<div align="center">
			<?php include('includes/footerbis.php'); ?>
		</div>
	</body>
</html>
		
