<?php
	//@utor: Mariano Mart�n
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	


	include ('pdf/class.ezpdf.php');
	
	// Conectar con el servidor de base de datos
							//variables para la conexi�n
							$servername = getenv("DB_HOST");
							$database = getenv("DB_NAME");
							$username = getenv("DB_USER");
							$password = getenv("DB_PASSWORD");
						
							$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
	
	
	$pdf =& new Cezpdf('a4');
	$pdf->selectFont('pdf/fonts/Helvetica.afm');
	$pdf->ezSetCmMargins(1,1,1.5,1.5);
	
	$monitor=$_REQUEST['monitor'];
	
	$instruccion = "select * from monitor where ID_MON like '".$monitor."'";
	
	//Ejecutamos la consulta						
	$consulta=mysql_query ($instruccion, $conexion)
		or die ("No se ha podido hacer la consulta");
						
    $resultado = mysql_fetch_array ($consulta);
	
	$nombre_monitor=$resultado['NOMBRE_MON']." ".$resultado['APELLIDOS_MON']."";
	
	$datacreator = array (
                    'Title'=>'Listado de cursos que ha impartido el monitor '.$nombre_monitor,
                    'Author'=>'Mariano Mart�n Bugar�n',
                    'Subject'=>'Club Deportivo Sevilla',
                    
						);
	
	
	
	$pdf->addInfo($datacreator);
	$pdf->ezText("Listado de cursos que ha impartido el monitor ".$nombre_monitor, 30);
		
	$instr="select NOMBRE_AC, FECHA_IN_AC, FECHA_FIN_AC, PLAZAS, PRECIO_AC, NOMBRE_PISTA from actividad, PISTA where ID_MON='$monitor' and actividad.ID_PISTA=pista.ID_PISTA order by FECHA_FIN_AC asc";
		
	$cons=mysql_query($instr,$conexion)
		or die("Fallo en Consulta");
	$num=mysql_num_rows($cons);
	for($i=0;$i<$num;$i++)
	{
		$datatmp=mysql_fetch_array($cons);
		$fecha_i = date("d/n/Y",$datatmp['FECHA_IN_AC']);
		$fecha_f = date("d/n/Y",$datatmp['FECHA_FIN_AC']);
		$data[] = array_merge($datatmp, array('num'=>$i+1), array('FECHA_IN_AC'=>$fecha_i), array('FECHA_FIN_AC'=>$fecha_f));
		
	}
	$titles = array(  
		'num'=>'<b>Num</b>', 
		'NOMBRE_AC'=>'<b>Nombre</b>', 
		'FECHA_IN_AC'=>'<b>Fecha Inicio</b>', 
		'FECHA_FIN_AC'=>'<b>Fecha Final</b>', 
		'PLAZAS'=>'<b>N� Plazas</b>', 
		'NOMBRE_PISTA'=>'<b>Pista</b>', 
	);
	$options = array(
                'shadeCol'=>array(0.9,0.9,0.9),
                'xOrientation'=>'center',
                'width'=>500
    );
	$pdf->ezText("\n\n\n", 10);
	$pdf->ezTable($data,$titles,'',$options );
	$pdf->ezText("\n\n\n",10);
	$pdf->ezText("<b>Total Cursos:</b> ".$num,10);
	$pdf->ezText("<b>Fecha:</b> ".date("d/m/Y"),10);
	$pdf->ezText("<b>Hora:</b> ".date("H:i:s")."\n\n",10);
	$pdf->ezStream();
	
?>
