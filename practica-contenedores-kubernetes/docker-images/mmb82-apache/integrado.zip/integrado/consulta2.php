<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=(isset($_REQUEST['usuario'])) ? $_REQUEST['usuario'] : false;
	
	include ('pdf/class.ezpdf.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
								<?php 
						 			// Conectar con el servidor de base de datos
									//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
									or die ("No se puede conectar con el servidor");
					
									$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
									$mes=(isset($_REQUEST['mes'])) ? $_REQUEST['mes'] : false;
									$año=(isset($_REQUEST['año'])) ? $_REQUEST['año'] : false;
									$error = false;
													
									if(isset($enviar))
									{
										$b_fecha_i = gmmktime(0,0,0,$mes,01,$año);
										$b_fecha_f = gmmktime(0,0,0,$mes,31,$año);
									}
									
									if(isset($enviar) && $error==false)
									{
							
										$instruccion1 = "select * from actividad where ";
										
										$a ="(actividad.FECHA_IN_AC<=$b_fecha_f && (actividad.FECHA_FIN_AC>=$b_fecha_i && actividad.FECHA_FIN_AC<=$b_fecha_f))";
										
										$b = " || ((actividad.FECHA_IN_AC>=$b_fecha_i && actividad.FECHA_IN_AC<=$b_fecha_f) && actividad.FECHA_FIN_AC>=$b_fecha_f)";
										
										$c = " || (actividad.FECHA_IN_AC<=$b_fecha_i and actividad.FECHA_FIN_AC>=$b_fecha_f) order by FECHA_FIN_AC ASC, FECHA_IN_AC ASC";
										
										$instruccion1 = $instruccion1.$a.$b.$c;
										
										$consulta1 = mysqli_query($conexion,$instruccion1);
										
										$nfilastotal1 = mysqli_num_rows($consulta1);
										
										if($nfilastotal1>0)
										{
											?>
											<center><h2>Listado de los cursos impartidos en la fecha seleccionada</h2></center>
											<center>	
											<div class="correo">
							 				<form name="consulta1.php" method="post" enctype="multipart/form-data">
								 				<fieldset class="margen">
													
													<table cellpadding="4">
														<tr>												<tr>
															<th>Actividad</th>
															<th>Fecha Incio</th>
															<th>Fecha Fin</th>
															<th>Nº Plazas</th>
															<th>Monitor</th>
															<th>Pista</th>
															<th>Precio</th>
														</tr>
														
												<?php 
						
													for ($i=0; $i<$nfilastotal1; $i++)
													{
														$resultado1 = mysqli_fetch_array($consulta1);
												?>
													<tr>
														<td>
															<?php print $resultado1['NOMBRE_AC']?>
														</td>
														<td>
															<?php $fecha_i = date("d/n/Y",$resultado1['FECHA_IN_AC']); echo $fecha_i;?>
														</td>
														<td>
															<?php $fecha_f = date("d/n/Y",$resultado1['FECHA_FIN_AC']); echo $fecha_f;?>
														</td>
														<td>
															<?php echo $resultado1['PLAZAS']?>
														</td>
														<td>
															<?php 
																$instruccion2 = "select * from monitor where ID_MON like '".$resultado1['ID_MON']."'";
																$consulta2 = mysqli_query($conexion,$instruccion2);
																$resultado2 = mysqli_fetch_array($consulta2);
																echo $resultado2['NOMBRE_MON']." ".$resultado2['APELLIDOS_MON'].""
															?>
														</td>
														<td>
															<?php 
																$instruccion2 = "select * from pista where ID_PISTA like '".$resultado1['ID_PISTA']."'";
																$consulta2 = mysqli_query($conexion,$instruccion2);
																$resultado2 = mysqli_fetch_array($consulta2);
																echo $resultado2['NOMBRE_PISTA']
															?>
														</td>
														<td>
															<?php echo $resultado1['PRECIO_AC']."€"?>
														</td>
													</tr>
																									<?php 
													}
										
										print "<tr><td>&nbsp;</td></tr>";
										print "	<td><b>Total Cursos: " .$nfilastotal1. "</b></td>";
										print "	</tr>";
										
										print "</table>";
										print "</fieldset>";
							 		print "</form>";
																							
									echo "</div>";
									echo "</center>";	
												echo "<center>";
												print "<div id='insertar'>";
												print "<table><tr><td><a href='pdf2.php?b_fecha_i=".$b_fecha_i."&b_fecha_f=".$b_fecha_f."' target='_new'><img src='imagenes/pdf.png' title='Crear PDF'></img></a></td></tr></table>";
												print "<p class='necesario'><i>Pinche en el icono para crear el pdf.</i></p>";
												echo "</div>";
												echo "<center>";
												
											}
											else
											{
												print "No hay actividades";
											}
										?>
											
							<?php 	
						 			}
						 			else
						 			{
						 			
						 			$instruccion = "select * from actividad order by FECHA_FIN_AC asc";
					
									$consulta = mysqli_query($conexion,$instruccion) or die ("No se puede hacer la consulta");
									
									$nfilastotal = mysqli_num_rows($consulta);
									
									if($nfilastotal>0)
									{
										for($i=0; $i<$nfilastotal; $i++)
										{
											$resultado = mysqli_fetch_array($consulta);
											
											if($i==0)
											{								
												$año_ini = date("d/n/Y",$resultado['FECHA_IN_AC']);
											}
											
											if($i+1==$nfilastotal)
											{
												$año_fin = date("d/n/Y",$resultado['FECHA_FIN_AC']);
											}
										}
									}
									else
									{
										$errores["actividad"] = "No existen actividades";
										$error = true;
									}
									?>
									
						 			<h2>Listado de los cursos impartidos en la fecha seleccionada</h2>
						 			<div class="correo">
						 				<form name="consulta2.php" method="post" enctype="multipart/form-data">
							 				<fieldset>
												<legend>Seleccione un Monitor</legend>
												<table class="margen2">
													<tr><td>&nbsp;</td></tr>
													<tr>	
														<td>Nombre: </td>
														<td>
															Mes:
															<select name="mes">
																<?php 
																	$meses="Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre";
																	$num = explode(",", $meses);
																	for ($i=0;$i<12;$i++)
																	{
																		$b=$i+1;
																		print "<option value='".$b."'>".$num[$i]."";
																	}
																?>
															</select>
															
															Año:
															<select name="año">
																<?php 
																	if($error==false)
																	{
																		$año_inicio = explode ("/", $año_ini);
																		$año_final = explode ("/", $año_fin);
																		
																		for($i=$año_inicio[2]; $i<=$año_final[2]; $i++)
																		{
																			echo "<option value='$i'>$i</option>";
																		}
																	}
																	else
																	{
																		echo "<option value='".date('Y')."'>".date('Y')."</option>";
																	}
																?>
															</select>
														</td>
								 						<td>
								 							<?php 
																if (trim($errores["actividad"])!= "")
																{
																	print ("<span class='error'>" . $errores["actividad"] . "</span>");
																}
															?>
														</td>
								 						<td><input type="submit" name="enviar" value="Crear Consulta"></input></td>											</tr>	
													</tr>
													<tr><td>&nbsp;</td></tr>
												</table>
											</fieldset>
						 				</form>	
						 			</div>
						 		<?php 
	 								}
								?>
							</div>	
				       </td>
				  	</tr>
	           </table>
	         </div>  
	        <div align="center">
					<?php include('includes/footerbis.php'); ?>
			</div>
		</div>
	</body>
</html>