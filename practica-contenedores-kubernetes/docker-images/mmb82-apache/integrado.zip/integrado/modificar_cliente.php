<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
							<?php 
								if($usuario=="")
								{
									print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
									print ("<div class='margen'>&nbsp;</div>");
									print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
								}	
							else
							{
							//Con esto llamamos al archivo donde tenemos las funciones
							
								$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
								$borrar=(isset($_REQUEST['borrar'])) ? $_REQUEST['borrar'] : false;
								$nombre=(isset($_REQUEST['nombre'])) ? $_REQUEST['nombre'] : false;
								$apellidos=(isset($_REQUEST['apellidos'])) ? $_REQUEST['apellidos'] : false;
								$dni=(isset($_REQUEST['dni'])) ? $_REQUEST['dni'] : false;
								$telefono=(isset($_REQUEST['telefono'])) ? $_REQUEST['telefono'] : false;
								$edad=(isset($_REQUEST['edad'])) ? $_REQUEST['edad'] : false;
								$sexo=(isset($_REQUEST['sexo'])) ? $_REQUEST['sexo'] : false;
								$email=(isset($_REQUEST['email'])) ? $_REQUEST['email'] : false;
								$direccion=(isset($_REQUEST['direccion'])) ? $_REQUEST['direccion'] : false;
								$tipo=(isset($_REQUEST['tipo'])) ? $_REQUEST['tipo'] : false;
								$fotografia=(isset($_REQUEST['fotografia'])) ? $_REQUEST['fotografia'] : false;
								$tamaño=(isset($_REQUEST['MAX_FILE_SIZE'])) ? $_REQUEST['MAX_FILE_SIZE'] : false;
								$tipo_archivo=(isset($_FILES['fotografia']['type'])) ? $_FILES['fotografia']['type'] : false;
								$user=(isset($_REQUEST['user'])) ? $_REQUEST['user'] : false;
								$password=(isset($_REQUEST['password'])) ? $_REQUEST['password'] : false;
								$completo=(isset($_REQUEST['completo'])) ? $_REQUEST['completo'] : false;
								$error=false;
							
								if (isset($enviar))//Comprobamos si se no se han introducido los datos en el formulario
								{
									//Comprobamos si el nombre está vacío
									if (trim($nombre)== "")
									{
										$errores["nombre"]="Introduzca el nombre";
										$error=true;
									}
									else
									{
										$errores["nombre"]="";
									}
									
									//Comprobamos si los apellidos están vacíos
									if (trim($apellidos)== "")
									{
										$errores["apellidos"]="Introduzca los apellidos";
										$error=true;
									}
									else
									{
										$errores["apellidos"]="";
									}
									
								//Comprobamos si el DNI está vacío y correcto
									if(trim ($dni)=="")
									{
										$errores["dni"]="Introduzca el DNI";
										$error=true;
									}
									else if (!preg_match('/^[0-9]{8}[A-Z,a-z]{1}$/', $dni))
									{
										$errores["dni"]="Introduzca bien el DNI, XXXXXXXXA";
										$error=true;
									}
									else
									{
										$errores["dni"]="";
									}
																																			
									//Comprobamos si el telefono no son 9 números
									if (!preg_match('/^[0-9]{9}$/',$telefono)) 
									{
										$errores["telefono"]="Introduzca un teléfono Correcto";
										$error=true;
									}
									else
									{
										$errores["telefono"]="";
									}
									
									//Comprobamos si la edad está vacía y es correcta
									if (is_numeric($edad))
									{
									    if(ctype_digit($edad))
										{	
											if($edad>16)
											{
												if($edad>67)
												{
													$errores["edad"]="¡La edad tiene que ser menor que 67 años!";
													$error=true;
												}
											}
											else
											{
												$errores["edad"]="¡La edad tiene que ser mayor que 16 años!";
												$error=true;
											}
										}
										else
										{
											$errores["edad"]="¡Debes de introducir un número entero!";
											$error=true;
										}
									}
									else
									{
										$errores["edad"]="¡Debes de introducir un número!";
										$error=true;
									}
																		
									//Comprobamos si el email está vacío y correcto
									if(trim ($email)=="")
									{
										$errores["email"]="Introduzca el email";
										$error=true;
									}
									else if ((!preg_match('/^[^0-9][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[@][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,4}$/',$email) || $email==""))
									{
										$errores["email"]="Introduzca un Email Correcto";
										$error=true;
									}
									else
									{
										$errores["email"]="";
									}
									
									//Comprobamos si la dirección está vacía
									if (trim($direccion)== "")
									{
										$errores["direccion"]="Introduzca la dirección";
										$error=true;
									}
									else
									{
										$errores["direccion"]="";
									}
									
								}
											
								if($error==false)
								{
									// Conectar con el servidor de base de datos
									//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
									or die ("No se puede conectar con el servidor");
									
									//comprobamos si el nombre está ya registrado
										$inst_busqueda = "select * from socio where DNI_SO like '" . $dni ."' and ID_SO not like '".$_REQUEST['id']."'";
										$busqueda = mysqli_query ($conexion,$inst_busqueda)
			         						or die ("Fallo en la consulta");
			         					$res_busqueda = mysqli_num_rows ($busqueda);
			         					if($res_busqueda!=0)
			         					{
			         						$errores["dni"]="DNI de otro cliente.";
											$error=true;
			         					}
			         					else
										{
											$errores["dni"]="";
										}
																																		
									//cerramos la BD
										$cerrar=mysqli_close($conexion);
								}	
								
								if($error==false)
								{
									//Subir imagen
									if(is_uploaded_file ($_FILES['fotografia']['tmp_name']))
									{
										if($_FILES['fotografia']['error'] == UPLOAD_ERR_FORM_SIZE || $_FILES['fotografia']['error'] == UPLOAD_ERR_INI_SIZE)
										{
											$errores["fotografia"]="Imagen de Tamaño erroneo, debe tener maximo 500Kb";
											$error=true;
										}
										//Comprobacion del tipo de imagen
										else
										{
										if(strpos($tipo_archivo, "gif") || strpos($tipo_archivo, "jpeg") || strpos($tipo_archivo, "jpg") || strpos($tipo_archivo, "png"))
											{
												if(is_uploaded_file($_FILES['fotografia']['tmp_name']))
												{
													$dir="img/";
													$fichero=$usuario."-".$_FILES['fotografia']['name'];
													$completo=$dir.$fichero;
													if(is_file($completo))
													{
														$unico=time();
														$fichero=$usuario."-".$unico."-".$_FILES['fotografia']['name'];
														$completo=$dir.$fichero;
													}
													move_uploaded_file($_FILES['fotografia']['tmp_name'], $completo);
												}
												else
												{
													$errores["fotografia"]="No se ha podido subir el fichero";
													$error=true;
												}
											}
											else
											{
												$errores["fotografia"]="Imagen de tipo erroneo, debe ser JPEG, GIF o PNG";
												$error=true;
											}
										}
									}
								}
									
								//listamos el contenido de las variables en la misma página
								//Si se han introducido los datos se muestran
								
								if (isset($enviar) && $error==false)
								{
									// Conectar con el servidor de base de datos
									
						$conexion = mysqli_connect ($servername, $username, $password,$database)
									or die ("No se puede conectar con el servidor");
									
									$instruccion2 = "update socio set NOMBRE_SO='".$nombre."', APELLIDOS_SO='".$apellidos."', DNI_SO='".$dni."', TELEFONO_SO='".$telefono."', EDAD_SO='".$edad."', SEXO_SO='".$sexo."', EMAIL_SO='".$email."', DIRECCION_SO='".$direccion."', FOTO_SO='".$completo."' where ID_SO like '".$_REQUEST['id']."'";
									
									$consulta = mysqli_query($conexion,$instruccion2) or die ("No se puede hacer la consulta");
										
									print("<h1>Detalles modificados del cliente</h1>");
									print("<table id='detalle'>");  
						         	print ("<tr><td><b>Nombre: </b>". $nombre ."</td></tr>");  
									print ("<tr><td><b>Apellidos: </b>". $apellidos ."</td></tr>");
									print ("<tr><td><b>DNI: </b>". $dni ."</td></tr>");
									print ("<tr><td><b>Edad: </b>". $edad ."</td></tr>");
									print ("<tr><td><b>Sexo: </b>". $sexo ."</td></tr>");
									print ("<tr><td><b>Email: </b>". $email ."</td></tr>");
									print ("<tr><td><b>dirección: </b>". $direccion ."</td></tr>");
									if($completo!="")
										print ("<tr><td><a href=".$completo." target=\"_blank\"><center><img src=".$completo." width='150' height='150' title=\"Pinche para ver la fotograf�a\" alt=\"IMAGEN\"></center></a></td></tr>");
							    	print("</table>"); 
										
										
									echo "<META HTTP-EQUIV='refresh' CONTENT='3; URL=clientes.php'>";
									
									$close = mysqli_close ($conexion);
									
								}
								else
								{
								// Conectar con el servidor de base de datos
								
						$conexion = mysqli_connect ($servername, $username, $password,$database)
								or die ("No se puede conectar con el servidor");	
									
								$instruccion = "select * from socio where ID_SO like '".$_REQUEST['id']."'";
								
								$consulta = mysqli_query($conexion,$instruccion) or die ("No se puede hacer la consulta");
								
								$resultado = mysqli_fetch_array ($consulta);
												
														
								?>
								<!-- Estructura de nuestro formulario y envío de los datos a las variables junto con la llamada a la comprobaci�n de errores -->
								
								<h2>Modificar cliente.</h2>
								
								<form action="modificar_cliente.php?id=<?php print $_REQUEST['id'] ?>" method="post" enctype="multipart/form-data">
									<fieldset>
										<legend>Datos Personales</legend>
										<table class="margen2">
											<tr>	
												<td>Nombre: </td>
												<td>
													<input type="text" name="nombre" size="30" maxlength="30" value="<?php print $resultado['NOMBRE_SO'];?>">
													<?php 
														if (trim($errores["nombre"])!= "")
														{
															print ("<span class='error'>" . $errores["nombre"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Apellidos: </td>
												<td>
													<input type="text" name="apellidos" size="30" maxlength="30" value="<?php print $resultado['APELLIDOS_SO'];?>">
													<?php 
														if (trim($errores["apellidos"])!= "")
														{
															print ("<span class='error'>" . $errores["apellidos"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>DNI: </td>
												<td>
													<input type="text" name="dni" size="9" maxlength="9" value="<?php print $resultado['DNI_SO'];?>">
													<?php 
														if (trim($errores["dni"])!= "")
														{
															print ("<span class='error'>" . $errores["dni"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>
												<td>Teléfono: </td>
												<td>
													<input type="text" name="telefono" size="9" maxlength="9" value="<?php print $resultado['TELEFONO_SO'];?>">
													<?php 
														if (trim($errores["telefono"])!= "")
														{
															print ("<span class='error'>" . $errores["telefono"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>
												<td>Edad: </td>
												<td>
													<input type="text" name="edad" size="3" maxlength="3" value="<?php print $resultado['EDAD_SO'];?>">
													<?php 
														if (trim($errores["edad"])!= "")
														{
															print ("<span class='error'>" . $errores["edad"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr><td>Sexo: </td>
												<td>
													<select name="sexo">
														<?php 
															if($resultado['SEXO_SO']=="hombre")
															{
																print "<option value='hombre' selected>hombre</option>";
															}
															else
															{
																print "<option value='hombre'>hombre</option>";
															}
															
															if($resultado['SEXO_SO']=="mujer")
															{
																print "<option value='mujer' selected>mujer</option>";
															}
															else
															{
																print "<option value='mujer'>mujer</option>";
															}
														?>
													</select>
												</td>
											</tr>
											<tr>
										  		<td>Email: </td>
												<td>
													<input type="text" name="email" size="30" maxlength="30" value="<?php print $resultado['EMAIL_SO'];?>">
													<?php 
														if (trim($errores["email"])!= "")
														{
															print ("<span class='error'>" . $errores["email"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>
										  		<td>dirección: </td>
												<td>
													<input type="text" name="direccion" size="30" maxlength="30" value="<?php print $resultado['DIRECCION_SO'];?>">
													<?php 
														if (trim($errores["direccion"])!= "")
														{
															print ("<span class='error'>" . $errores["direccion"] . "</span>");
														}
													?>
												</td>
											</tr>
										</table>
									</fieldset>
																									
									<fieldset class="margen8">
										<legend>Adjuntar fotografía</legend>
										<table class="margen5">
											<tr>
												<td>
													<input type="hidden" name="MAX_FILE_SIZE" value="102400">
													<input type="file" name="fotografia" size="50">
													<?php 
														if (isset($errores['fotografia']) && trim($errores["fotografia"])!= "")
														{
															print ("<span class='error'>" . $errores["fotografia"] . "</span>");
														}
													?>
												</td>
											</tr>
										</table>
									</fieldset>
									
								<div class="margen8"><input type="submit" name="enviar" value="Enviar Datos"><input type="reset" name="borrar" value="Borrar Datos"></div>
							
								</form>
						<?php 
							}
						}
						?>
						
			
			
		</div>
		<div align="center">
				<?php include('includes/footerbis.php'); ?>
			</div>
	</body>
</html>
		
