<?php
	//@utor: Mariano Martín
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es" xmlns="http://www.w3.org/1999/xhtml">
<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
	<title>Club Deportivo Sevilla</title>
	<link href="css/estilos.css" rel="stylesheet" type="text/css" media="screen" />
	<script language="javascript" type="text/javascript" src="js/precarga.js"></script>
</head>

<body onLoad="MM_preloadImages('imagenes/presentacion_on.png', 'imagenes/tarifa_on.png', 'imagenes/eventos_on.png','imagenes/actividades_on.png', 'imagenes/contacto_on.png', 'imagenes/login_on.png')">
	<div id="global">

		<?php include('includes/header.php'); ?>

        <div id="cuerpo">
			<div id="contenido">
                <div id="columna3">
                	<h2>Precios</h2>
                    <table cellpadding="5" cellspacing="0" border="0" width="100%" align="center">
                    	<tr align="center" style=" font-weight:bolder;">
                        	<td>Mes</td><td>30 &euro;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                        </tr>
                    </table>
                    <h2>Horarios</h2>
                    <table cellpadding="5" cellspacing="0" border="0" width="100%" align="center">
                    	<tr align="center" style=" font-weight:bolder;">
                        	<td>&nbsp;</td><td>LUNES</td><td>MARTES</td><td>MI&Eacute;RCOLES</td><td>JUEVES</td><td>VIERNES</td>
                        </tr>
                        <tr align="center">
                        	<td>10 a 11</td><td>Step</td><td>Kenpo Contact</td><td>Spinning</td><td>Spinning</td><td>Cardio Kick Box</td>
                        </tr>
                        <tr align="center">
                        	<td>17 a 18</td><td>Kenpo Contact</td><td>Kenpo Contact</td><td>Kenpo Contact</td><td>Kenpo Contact</td><td>Pilates</td>
                        </tr>
                        <tr align="center">
                        	<td>18 a 19</td><td>Pilates</td><td>Spinning</td><td>Spinning</td><td>Spinning</td><td>Kenpo Contact</td>
                        </tr>
                        <tr align="center">
                        	<td>19 a 20</td><td>Step</td><td>Spinning</td><td>Cardio Kick Box</td><td>Spinning</td><td>Interval Box</td>
                        </tr>
                        <tr align="center">
                        	<td>20 a 21</td><td>BodyPum</td><td>Spinning</td><td>Step</td><td>BodyPum</td><td>Spinning</td>
                        </tr>
                        <tr align="center">
                        	<td>21 a 22</td><td>Spinning</td><td>Step</td><td>Step</td><td>Spinning</td><td>Kenpo Contact</td>
                        </tr>
                    </table>
                    <h2>Cursos extra</h2>
                    <table cellpadding="5" cellspacing="0" border="0" width="100%" align="center">
                    	<tr align="center" style=" font-weight:bolder;">
                        	<td>&nbsp;</td><td>Futbol</td><td>Baloncesto</td><td>Padel</td><td>Tenis</td><td>Balonmano</td>
                        </tr>
                    </table>
            	</div>
            </div>
        </div>

		<?php include('includes/footer.php'); ?>

    </div>
</body>
</html>