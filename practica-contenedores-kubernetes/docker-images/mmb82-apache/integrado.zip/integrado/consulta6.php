<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
	include ('pdf/class.ezpdf.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
								<?php 
						 			// Conectar con el servidor de base de datos
									//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
									or die ("No se puede conectar con el servidor");
					
									$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
									$id_actividad=(isset($_REQUEST['id_actividad'])) ? $_REQUEST['id_actividad'] : false;
									
				$error=false;
				
				if(isset($enviar))
				{
					if($id_actividad=="-1")
					{
						$error=true;
						$errores["actividad"]=" No existe actividades para seleccionar";
					}
					
					$instruccion3 = "select * from actividad where ID_AC like '".$id_actividad."'";
					
					$consulta3 = mysqli_query($conexion,$instruccion3) or die ("No se ha podido hacer la consulta");
					
					$resultado3 = mysqli_fetch_array($consulta3);
					
					$nombre_actividad = $resultado3['NOMBRE_AC'];
				}
				if(isset($enviar) && $error==false)
				{					
					
					$instruccion1 = "SELECT DISTINCT ID_SO FROM `historial_realiza` WHERE ID_AC LIKE '".$id_actividad."'";
					
					$consulta1 = mysqli_query($conexion,$instruccion1) or die ("No se ha podido hacer la consulta");
					
					$nfilastotal1 = mysqli_num_rows($consulta1);
					
					if($nfilastotal1>0)
					{
		?>
										
											<center><h2>El número de alumnos que ha realizado el curso</h2></center>
											<center>	
											<div class="correo">
							 				<form name="consulta6.php" method="post" enctype="multipart/form-data">
								 				<fieldset class="margen">
													
													<table cellpadding="4">
														<tr>
															<th>Socio</th>
															<th>DNI Socio</th>
															<th>Importe</th>
														</tr>	
											<?php										
												for($i=0;$i<$nfilastotal1;$i++)
												{
													$resultado1 = mysqli_fetch_array($consulta1);
													$instruccion78 = "SELECT DISTINCT ID_SO, sum( IMPORTE_CONT ) AS IMPORTE_TOTAL FROM historial_realiza WHERE ID_AC like '".$id_actividad."' AND ID_SO like '".$resultado1['ID_SO']."'";
													$consulta78 = mysqli_query($conexion, $instruccion78) or die ("No se ha podido hacer la consulta");
													$resultado78 = mysqli_fetch_array($consulta78);
											?>
													<tr>
														<td>
															<?php 
																$instruccion2 = "select * from socio where ID_SO like '".$resultado78['ID_SO']."'";
																
																$consulta2 = mysqli_query($conexion,$instruccion2) or die ("No se puede hacer la consulta");
																
																$resultado2 = mysqli_fetch_array($consulta2);
																
																echo $resultado2['NOMBRE_SO']. " ".$resultado2['APELLIDOS_SO']."";
															?>
														</td>
														<td><?php echo $resultado2['DNI_SO']?></td>
														<td><?php echo $resultado78['IMPORTE_TOTAL']."€"?></td>
													</tr>
											<?php 	
													}
										
										print "</table>";
										print "<table>";
										print "<tr><td>&nbsp;</td></tr>";
										print "	<td><b>Total Alumnos:  " .$nfilastotal1. "</b></td>";
										print "	</tr>";
										print "</table>";
										print "</fieldset>";
							 		print "</form>";
																							
									echo "</div>";
									echo "</center>";	
												echo "<center>";
												print "<div id='insertar'>";
												print "<table><tr><td><a href='pdf6.php?id_actividad=".$id_actividad."&nombre_actividad=".$nombre_actividad."' target='_new'><img src='imagenes/pdf.png' title='Crear PDF'></img></a></td></tr></table>";
												print "<p class='necesario'><i>Pinche en el icono para crear el pdf.</i></p>";
												echo "</div>";
												echo "<center>";
												
											}
											else
											{
												print "No hay clientes";
											}
										?>
											
							<?php 	
						 			}
						 			else
									{
						?>
									<h2>El número de alumnos que ha realizado en un determinado curso</h2>
						 			<div class="correo">
						 				<form name="consulta6.php" method="post" enctype="multipart/form-data">
							 				<fieldset>
												<legend>Seleccione un Curso</legend>
												<table class="margen2">
													<tr><td>&nbsp;</td></tr>
													<tr>	
														<td>Curso :</td>
														<td>
															<select name="id_actividad">
																<?php 
																	$instruccion = "select * from actividad order by NOMBRE_AC";
																	
																	$consulta = mysqli_query ($conexion,$instruccion) or die ("No se puede hacer la consulta");
																	
																	$nfilastotal = mysqli_num_rows($consulta);
																	
																	if($nfilastotal>0)
																	{
																		for($i=0; $i<$nfilastotal; $i++)
																		{
																			$resultado = mysqli_fetch_array($consulta);
																			
																			echo "<option value = '".$resultado['ID_AC']."'>".$resultado['NOMBRE_AC']."</option>";
																		}
																	}
																	else
																	{
																		echo "<option value='-1'>No existen actividades</option>";
																	}
																?>
															</select>
														</td>
															<td>
															<?php 
																if (trim($errores["actividad"])!= "")
																{
																	print ("<span class='error'>" . $errores["actividad"] . "</span>");
																}
															?>
															</td>
															<td><input type="submit" name="enviar" value="Crear Consulta"></input></td>
														</tr>
														
													<tr><td>&nbsp;</td></tr>
												</table>
											</fieldset>
						 				</form>	
						 			</div>
						 		<?php 
	 								}
								?>
							</div>	
				       </td>
				  	</tr>
	           </table>
	         </div>  
	        <div align="center">
					<?php include('includes/footerbis.php'); ?>
			</div>
		</div>
	</body>
</html>