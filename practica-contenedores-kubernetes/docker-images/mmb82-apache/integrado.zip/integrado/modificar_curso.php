<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
	include ("lib/funciones.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	    
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
							<?php 
								if($usuario=="")
								{
									print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
									print ("<div class='margen'>&nbsp;</div>");
									print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
								}	
							else
							{
							//Con esto llamamos al archivo donde tenemos las funciones
							
							$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
							$dia_f=(isset($_REQUEST['dia_f'])) ? $_REQUEST['dia_f'] : false;
							$mes_f=(isset($_REQUEST['mes_f'])) ? $_REQUEST['mes_f'] : false;
							$ano_f=(isset($_REQUEST['ano_f'])) ? $_REQUEST['ano_f'] : false;
							$dia_i=(isset($_REQUEST['dia_i'])) ? $_REQUEST['dia_i'] : false;
							$mes_i=(isset($_REQUEST['mes_i'])) ? $_REQUEST['mes_i'] : false;
							$ano_i=(isset($_REQUEST['ano_i'])) ? $_REQUEST['ano_i'] : false;
							$plazas=(isset($_REQUEST['plazas'])) ? $_REQUEST['plazas'] : false;
							$precio=(isset($_REQUEST['precio'])) ? $_REQUEST['precio'] : false;
							$nombre=(isset($_REQUEST['nombre'])) ? $_REQUEST['nombre'] : false;
							$id_monitor=(isset($_REQUEST['id_monitor'])) ? $_REQUEST['id_monitor'] : false;
							$id_pista=(isset($_REQUEST['id_pista'])) ? $_REQUEST['id_pista'] : false;
							$descripcion=(isset($_REQUEST['descripcion'])) ? $_REQUEST['descripcion'] : false;
							$fotografia=(isset($_REQUEST['fotografia'])) ? $_REQUEST['fotografia'] : false;
							$tamaño=(isset($_REQUEST['MAX_FILE_SIZE'])) ? $_REQUEST['MAX_FILE_SIZE'] : false;
							$tipo_archivo=(isset($_FILES['fotografia']['type'])) ? $_FILES['fotografia']['type'] : false;
							$fecha_inicio=(isset($_REQUEST['fecha_inicio'])) ? $_REQUEST['fecha_inicio'] : false;
							$nombreFichero=(isset($_REQUEST['nombreFichero'])) ? $_REQUEST['nombreFichero'] : false;
							$completo=(isset($_REQUEST['completo'])) ? $_REQUEST['completo'] : false;
							$error=false;
							
								if (isset($enviar))//Comprobamos si se no se han introducido los datos en el formulario
								{
									if(is_numeric($plazas))
									{
										if($plazas>0)
										{
											if(!ctype_digit($plazas))
											{
												$error=true;
							      				$errores["plazas"]="Introduzca un número entero";
											}
										}
										else
										{
											$error=true;
							      			$errores["plazas"]="Introduzca un número positivo";
										}
									}
									else
									{
										$error=true;
							      		$errores["plazas"]="Introduzca un número entero";
									}	
									
								if(is_numeric($precio))
								{
									if($precio<=0)
									{
										$error=true;
						      			$errores["precio"]="Introduzca un número positivo";
									}
								}
								else
								{
									$error=true;
						      		$errores["precio"]="Introduzca un número";
								}
									
								//Comprobamos las plazas disponibles
								//Nos conectamos el servidor
								//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
											or die ("No se puede conectar con el servidor");
								
								$hoy = gmmktime(0,0,0,date("n"), date("d"), date("Y"));
								$instruccion = "select * from realiza where ID_AC like '".$_REQUEST['id']."' and FECHA_FIN_RE >= $hoy";
												
								$consulta = mysqli_query ($conexion,$instruccion)
									or die ("Fallo en la consulta54");
									
								$nfilas = mysqli_num_rows ($consulta);
								
								$instruccion100 = "select * from actividad where ID_AC like '".$_REQUEST['id']."'";
									
								$consulta100 = mysqli_query($conexion,$instruccion100)
										or die ("No se puede hacer la consulta");
									
								$resultado100 = mysqli_fetch_array ($consulta100);
								
								$stock = $resultado100['PLAZAS'];
																
								if ($plazas > $nfilas || $plazas == $nfilas)
								{
									$disponible=$stock-$nfilas;
								}
								else
								{
									$error=true;
						      		$errores["actividad"]="¡Debe de introducir un NO de Plazas superior a $nfilas!";
								}
								
								//Comprobamos si el descripcion está vacío
									if (trim($descripcion)== "")
									{
										$errores["descripcion"]="Introduzca descripción";
										$error=true;
									}
									else
									{
										$errores["descripcion"]="";
									}
					
									$fecha_i=$_SESSION['fecha_inicio'];
									unset ($_SESSION['fecha_inicio']);
									
									if(!checkdate($mes_f, $dia_f, $ano_f))
									{
										$error=true;
										$errores["fecha_f"]="¡Fecha Incorrecta!";
									}
									
									$fecha_f = gmmktime(0,0,0,$mes_f, $dia_f, $ano_f);
									
									$fecha_inicial = $resultado100['FECHA_IN_AC'];
									
									if($error==false)
									{
										comprobar_fecha($fecha_inicial, $fecha_f, $errores, $error, $var="fecha_f");
										
										// Conectar con el servidor de base de datos
											
										/*if($error==false)
										{
											$fech_ini="$ano_i-$mes_i-$dia_i";
											$fech_fin="$ano_f-$mes_f-$dia_f";
											
											
											$meses = meses($fech_ini,$fech_fin);
																			
											if ($meses==0)
											{
												$error=true;
												$errores["fecha_f"]="¡Minimo es un mes!";
											}	
										}*/	
										
																			
										//Subir imagen
										if(is_uploaded_file ($_FILES['fotografia']['tmp_name']))
										{
											if($_FILES['fotografia']['error'] == UPLOAD_ERR_FORM_SIZE || $_FILES['fotografia']['error'] == UPLOAD_ERR_INI_SIZE)
											{
												$errores["fotografia"]="Imagen de Tamaño erroneo, debe tener maximo 500Kb";
												$error=true;
											}
										
											//Comprobacion del tipo de imagen
											else
											{
												if(strpos($tipo_archivo, "gif") || strpos($tipo_archivo, "jpeg") || strpos($tipo_archivo, "jpg") || strpos($tipo_archivo, "png"))
												{
													if(is_uploaded_file($_FILES['fotografia']['tmp_name']))
													{
														$dir="img/";
														$fichero=$usuario."-".$_FILES['fotografia']['name'];
														$completo=$dir.$fichero;
														if(is_file($completo))
														{
															$unico=time();
															$fichero=$usuario."-".$unico."-".$_FILES['fotografia']['name'];
															$completo=$dir.$fichero;
														}
														move_uploaded_file($_FILES['fotografia']['tmp_name'], $completo);
													}
													else
													{
														$errores["fotografia"]="No se ha podido subir el fichero";
														$error=true;
													}
												}
												else
												{
													$errores["fotografia"]="Imagen de tipo erroneo, debe ser JPEG, GIF o PNG";
													$error=true;
												}
											}
										}
									}
									
								}
									
								//listamos el contenido de las variables en la misma pgina
								//Si se han introducido los datos se muestran
								
								if (isset($enviar) && $error==false)
								{
									//Nos conectamos el servidor
															
						$conexion = mysqli_connect ($servername, $username, $password,$database)
											or die ("No se puede conectar con el servidor");

									$instruccion2 = "update actividad set FECHA_FIN_AC='$fecha_f', DESC_AC='".$descripcion."', FOTO_AC='".$nombreFichero."', NOMBRE_AC='".$nombre."', PLAZAS='".$plazas."', N_PLAZAS_DIS='".$disponible."', PRECIO_AC='".$precio."', ID_MON='".$id_monitor."', ID_PISTA='".$id_pista."' where ID_AC like '".$_REQUEST['id']."'";
													
									$consulta = mysqli_query($conexion,$instruccion2) or die ("No se puede hacer la consulta");
									
									$instruccion105 = " select * from actividad, pista, monitor where actividad.ID_PISTA=pista.ID_PISTA and monitor.ID_MON=actividad.ID_MON and ID_AC like '".$_REQUEST['id']."'";
									
									$consulta105 = mysqli_query($conexion,$instruccion105)
										or die ("No se puede hacer la consulta");
									
									$resultado105 = mysqli_fetch_array ($consulta105);		
									
									print("<h1>Detalles modificados del curso</h1>");
									print("<table id='detalle'>");  
						         	print ("<tr><td><b>Nombre: </b>". $nombre ."</td></tr>");  
									print ("<tr><td><b>Descripción: </b>". $descripcion ."</td></tr>");
									print ("<tr><td><b>Precio: </b>". $precio ."</td></tr>");
									print ("<tr><td><b>Plazas: </b>". $plazas ."</td></tr>");
									print ("<tr><td><b>Monitor: </b>". $resultado105['NOMBRE_MON']."</td></tr>");
									print ("<tr><td><b>Pista: </b>". $resultado105['NOMBRE_PISTA'] ."</td></tr>");
									$fecha_i = date("d/n/Y",$resultado105['FECHA_IN_AC']); 
									print ("<tr><td><b>Fecha inicio: </b>". $fecha_i."</td></tr>");
									$fecha_fi = date("d/n/Y",$fecha_f); 
									print ("<tr><td><b>Fecha fin: </b>". $fecha_fi ."</td></tr>");
									
									if($completo!="")
										print ("<tr><td><a href=".$completo." target=\"_blank\"><center><img src=".$completo." width='150' height='150' title=\"Pinche para ver la fotografía\" alt=\"IMAGEN\"></center></a></td></tr>");
							    	print("</table>"); 
							    	
							    	echo "<META HTTP-EQUIV='refresh' CONTENT='3; URL=cursos.php'>";
							    	//cerramos la BD
										$cerrar=mysqli_close($conexion);		
								}
								else
								{
									//Nos conectamos el servidor
															
						$conexion = mysqli_connect ($servername, $username, $password,$database)
											or die ("No se puede conectar con el servidor");
										
									$instruccion = "select * from actividad where ID_AC like '".$_REQUEST['id']."'";
									
									$consulta = mysqli_query($conexion,$instruccion)
										or die ("No se puede hacer la consulta");
									
									$resultado3 = mysqli_fetch_array ($consulta);						
								?>
								<!-- Estructura de nuestro formulario y envío de los datos a las variables junto con la llamada a la comprobación de errores -->
								
								<h2>Modificar Curso.</h2>
								
								<form action="modificar_curso.php?id=<?php print $_REQUEST['id'] ?>" method="post" enctype="multipart/form-data">
									<fieldset>
										<legend>Datos de curso</legend>
										<table class="margen2">
											<tr>	
												<td>Nombre: </td>
												<td>
													<input type="text" name="nombre" size="30" maxlength="30" value="<?php print $resultado3['NOMBRE_AC'];?>">
													<?php 
														if (isset($errores["nombre"]) && trim($errores["nombre"])!= "")
														{
															print ("<span class='error'>" . $errores["nombre"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>
												<td>Precio: </td>
													<td>
														<input type="text" name="precio" size="3" maxlength="3" value="<?php print $resultado3['PRECIO_AC'];?>">
														<?php 
															if (trim($errores["precio"])!= "")
															{
																print ("<span class='error'>" . $errores["precio"] . "</span>");
															}
														?>
													</td>
												</tr>
												<tr>	
													<td>Plazas: </td>
													<td>
														<input type="text" name="plazas" size="3" maxlength="3" value="<?php PRINT $resultado3['PLAZAS'];?>">
														<?php 
															if (trim($errores["plazas"])!= "")
															{
																print ("<span class='error'>" . $errores["plazas"] . "</span>");
															}
														?>
													</td>
												</tr>
												<tr>
													<td>Monitor: </td>
													<td>
														<select name="id_monitor">
															<?php 
																// Conectar con el servidor de base de datos
																
						$conexion = mysqli_connect ($servername, $username, $password,$database)
																	or die ("No se puede conectar con el servidor");
																		
																$instruccion = "select * from monitor order by NOMBRE_MON";
																
																$consulta = mysqli_query($conexion,$instruccion) or die ("No se ha podido hacer la consulta monitor");
																
																$nfilas = mysqli_num_rows($consulta);
																
																if ($nfilas > 0)
														      	{							      		
														      		for($i=0; $i<$nfilas; $i++)
														      		{
														      			$resultado = mysqli_fetch_array ($consulta);
														      			
														      			if($resultado3['ID_MON']==$resultado['ID_MON'])
														      			{
														      				print "<option value='".$resultado['ID_MON']."' selected>".$resultado['NOMBRE_MON']." " .$resultado['APELLIDOS_MON']."</option>";
														      			}
														      			else
														      			{
														      				print "<option value='".$resultado['ID_MON']."'>".$resultado['NOMBRE_MON']."" .$resultado['APELLIDOS_MON']."</option>";
														      			}
														      		}
														      	}
														      	else
														      	{
														      		print "<option value='-1'>No existe monitores</option>";
														      		$error=true;
														      		$errores["id_pista"]="¡No existen monitores disponibles!";
														      	}
															
															//cerramos la BD
															$cerrar=mysqli_close($conexion);		
															?>
															
														</select>
														<?php 
															if (isset($errores["monitor"]) && trim($errores["monitor"])!= "")
															{
																print ("<span class='error'>" . $errores["monitor"] . "</span>");
															}
														?>
													</td>
												</tr>
												<tr>
													<td>Pista: </td>
													<td>
														<select name="id_pista">
															<?php 
																// Conectar con el servidor de base de datos
																
						$conexion = mysqli_connect ($servername, $username, $password,$database)
																	or die ("No se puede conectar con el servidor");
																		
																	$instruccion = "select * from pista order by NOMBRE_PISTA";
																						
																$consulta = mysqli_query($conexion,$instruccion) or die ("No se ha podido hacer la consulta pista");
																
																$nfilas = mysqli_num_rows($consulta);
																
																if ($nfilas > 0)
														      	{							      		
														      		for($i=0; $i<$nfilas; $i++)
														      		{
														      			$resultado = mysqli_fetch_array ($consulta);
														      			
														      			if($resultado3['ID_PISTA']==$resultado['ID_PISTA'])
														      			{
														      				print "<option value='".$resultado['ID_PISTA']."' selected>".$resultado['NOMBRE_PISTA']."</option>";
														      			}
														      			else
														      			{
														      				print "<option value='".$resultado['ID_PISTA']."'>".$resultado['NOMBRE_PISTA']."</option>";	
														      			}
														      		}
														      	}
														      	else
														      	{
														      		print "<option value='-1'>No existen pistas</option>";
														      		$error=true;
														      		$errores["id_pista"]="¡No existen pistas disponibles!";
														      	}
																
																//cerramos la BD
																$cerrar=mysqli_close($conexion);	
															?>
														</select>
														<?php 
															if (isset($errores["edad"]) && trim($errores["edad"])!= "")
															{
																print ("<span class='error'>" . $errores["edad"] . "</span>");
															}
														?>
													</td>
												</tr>
												<tr>
													<td>Fecha Inicio:</td>
													<td><?php $fecha_i = date("d/n/Y",$resultado3['FECHA_IN_AC']); echo $fecha_i;?></td>
												</tr>
												<tr>
													<td>Fecha Final:</td>
													<td>
														<select name="dia_f">
															<?php 
																$fecha_i = date("d/n/Y",$resultado3['FECHA_FIN_AC']);
																
																$_SESSION['fecha_inicio'] = $resultado3['FECHA_FIN_AC'];
																
																$fecha_i = explode ("/", $fecha_i);
																
																for ($i=1;$i<32;$i++)
																{										
																	$a = $fecha_i[0];
																	
																	if($i<10)
																	{
																		$i="0".$i;
																	}
																	
																	if ($i == $a)
																	{
																		print "<option value='".$i."' selected>".$i."";
																	}
																	else
																	{
																		print "<option value='".$i."'>".$i."";
																	}										
																}
															?>
														</select>
														<select name="mes_f">
															<?php 
																$meses="Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre";
																$num = explode(",", $meses);
																for ($i=0;$i<12;$i++)
																{
																	$b=$i+1;
																	$a = $fecha_i[1];
																	
																	if ($b==$a)
																	{
																		print "<option value='".$b."' selected>".$num[$i]."";
																	}
																	else
																	{
																		print "<option value='".$b."'>".$num[$i]."";
																	}
																	
																}
															?>
														</select>
														<select name="ano_f">
															<?php
																
																$a = $fecha_i[2];
																$b=$a+6;
																for ($i=$a;$i<$b;$i++)
																{
																	if($a==$i)
																	{
																		print "<option value='".$i."' selected>".$i."";
																	}
																	else
																	{
																		print "<option value='".$i."'>".$i."";
																	}
																	
																}
															?>
														</select>
														
													</td>
												</tr>
												
											</table>
										</fieldset>							
										
										<fieldset class="margen8">
											<legend>Adjuntar fotografía</legend>
											<table class="margen5">
												<tr>
													<td>
														<input type="hidden" name="MAX_FILE_SIZE" value="102400">
														<input type="file" name="fotografia" size="50">
														<?php 
															if (isset($errores["fotografia"]) && trim($errores["fotografia"])!= "")
															{
																print ("<span class='error'>" . $errores["fotografia"] . "</span>");
															}
														?>
													</td>
												</tr>
											</table>
										</fieldset>
										
										<fieldset class="margen8">
											<legend>Descripción</legend>
											<textarea class="margen5" cols="40" rows="4" name="descripcion"><?php print $resultado3['DESC_AC']?></textarea>
										</fieldset>												
																	
								<div class="margen8"><input type="submit" name="enviar" value="Enviar Datos"><input type="reset" name="borrar" value="Borrar Datos"></div>
							
								</form>
						<?php 
							}
						}
						?>
						
						</div>
				</td>
				</tr>
			</table>
		</div>
		<div align="center">
				<?php include('includes/footerbis.php'); ?>
			</div>
	</body>
</html>
		
