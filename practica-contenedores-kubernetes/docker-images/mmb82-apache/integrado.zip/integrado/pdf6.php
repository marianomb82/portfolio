<?php
	//@utor: Mariano Mart�n
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	


	include ('pdf/class.ezpdf.php');
	
	// Conectar con el servidor de base de datos
							//variables para la conexi�n
							$servername = getenv("DB_HOST");
							$database = getenv("DB_NAME");
							$username = getenv("DB_USER");
							$password = getenv("DB_PASSWORD");
						
							$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
	
	
	$pdf =& new Cezpdf('a4');
	$pdf->selectFont('pdf/fonts/Helvetica.afm');
	$pdf->ezSetCmMargins(1,1,1.5,1.5);
	
	$id_actividad = $_REQUEST['id_actividad'];
	$nombre_actividad = $_REQUEST['nombre_actividad'];
		
	$fecha_f = date("n - Y",$b_fecha_i);
		
	$datacreator = array (
                    'Title'=>'Alumnos que ha realizado el curso de 	'.$nombre_actividad,
                    'Author'=>'Mariano Mart�n Bugar�n',
                    'Subject'=>'Club Deportivo Sevilla',
                    
						);

	$pdf->addInfo($datacreator);
	$pdf->ezText("Alumnos que ha realizado el curso de ".$nombre_actividad, 30);
	
	$instr = "SELECT DISTINCT ID_SO FROM `historial_realiza` WHERE ID_AC LIKE '".$id_actividad."'";
		
	$cons=mysql_query($instr,$conexion)
		or die("Fallo en Consulta");
	$num=mysql_num_rows($cons);
	
	if($num>0)
	{
		for($i=0;$i<$num;$i++)
		{
			$datatmp=mysql_fetch_array($cons);
			$instruccion78 = "SELECT DISTINCT ID_SO, sum( IMPORTE_CONT ) AS IMPORTE_TOTAL FROM historial_realiza WHERE ID_AC like '".$id_actividad."' AND ID_SO like '".$datatmp['ID_SO']."'";
			$consulta78 = mysql_query($instruccion78, $conexion) or die ("No se ha podido hacer la consulta");
			$datatmp1=mysql_fetch_array($consulta78);
			
			$instruccion1 = "select * from socio where ID_SO like '".$datatmp1['ID_SO']."'";
			$consulta1=mysql_query($instruccion1,$conexion);
			$datatmp2=mysql_fetch_array($consulta1);
			
			$nombre = $datatmp2['NOMBRE_SO']." ".$datatmp2['APELLIDOS_SO']."";
			$dni = $datatmp2['DNI_SO'];
			$data[] = array_merge($datatmp1, array('num'=>$i+1), array('nombre'=>$nombre), array('dni'=>$dni));
		}
		$titles = array(  
			'num'=>'<b>Num</b>', 
			'nombre'=>'<b>Socio</b>',
			'dni'=>'<b>DNI Socio</b>', 
			'IMPORTE_TOTAL'=>'<b>Importe Total (�)</b>',  
		);
		$options = array(
	                'shadeCol'=>array(0.9,0.9,0.9),
	                'xOrientation'=>'center',
	                'width'=>500
	    );
	}
	else
	{
		$num=0;
	}
	
		$pdf->ezText("\n\n\n", 10);
		$pdf->ezTable($data,$titles,'',$options );
		$pdf->ezText("\n\n\n",10);
		$pdf->ezText("<b>Total Alumnos:</b> ".$num,10);
		$pdf->ezText("<b>Fecha:</b> ".date("d/m/Y"),10);
		$pdf->ezText("<b>Hora:</b> ".date("H:i:s")."\n\n",10);
		$pdf->ezStream();
	
?>


	
