<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
	include ("lib/funciones.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
							<?php 
								if($usuario=="")
								{
									print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
									print ("<div class='margen'>&nbsp;</div>");
									print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
								}	
							else
							{
							//Con esto llamamos al archivo donde tenemos las funciones
							
								$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
								$nombre=(isset($_REQUEST['nombre'])) ? $_REQUEST['nombre'] : false;
								$plazas=(isset($_REQUEST['plazas'])) ? $_REQUEST['plazas'] : false;
								$precio=(isset($_REQUEST['precio'])) ? $_REQUEST['precio'] : false;
								$id_monitor=(isset($_REQUEST['id_monitor'])) ? $_REQUEST['id_monitor'] : false;
								$id_pista=(isset($_REQUEST['id_pista'])) ? $_REQUEST['id_pista'] : false;
								$dia_i=(isset($_REQUEST['dia_i'])) ? $_REQUEST['dia_i'] : false;
								$mes_i=(isset($_REQUEST['mes_i'])) ? $_REQUEST['mes_i'] : false;
								$ano_i=(isset($_REQUEST['ano_i'])) ? $_REQUEST['ano_i'] : false;
								$dia_f=(isset($_REQUEST['dia_f'])) ? $_REQUEST['dia_f'] : false;
								$mes_f=(isset($_REQUEST['mes_f'])) ? $_REQUEST['mes_f'] : false;
								$ano_f=(isset($_REQUEST['ano_f'])) ? $_REQUEST['ano_f'] : false;
								$completo=(isset($_REQUEST['completo'])) ? $_REQUEST['completo'] : false;

								$descripcion=(isset($_REQUEST['descripcion'])) ? $_REQUEST['descripcion'] : false;
								$fotografia=(isset($_REQUEST['fotografia'])) ? $_REQUEST['fotografia'] : false;
								$tamaño=(isset($_REQUEST['MAX_FILE_SIZE'])) ? $_REQUEST['MAX_FILE_SIZE'] : false;
								$tipo_archivo=(isset($_FILES['fotografia']['type'])) ? $_FILES['fotografia']['type'] : false;

								$error=false;
							
								if (isset($enviar))//Comprobamos si se no se han introducido los datos en el formulario
								{
									//Comprobamos si el nombre está vacío
									if (trim($nombre)== "")
									{
										$errores["nombre"]="Introduzca el nombre";
										$error=true;
									}
									else
									{
										$errores["nombre"]="";
									}
									
									//Comprobamos si las plazas están vacías
									if (trim($plazas)== "")
									{
										$errores["plazas"]="Introduzca las plazas";
										$error=true;
									}
									else
									{
										$errores["plazas"]="";
									}
									
									//Comprobamos si el precio está vacío
									if(trim ($precio)=="")
									{
										$errores["precio"]="Introduzca el precio";
										$error=true;
									}
									else
									{
										$errores["precio"]="";
									}
									
									//Comprobamos si la descripción está vacía
									if(trim ($descripcion)=="")
									{
										$errores["descripcion"]="Introduzca la descripcion";
										$error=true;
									}
									else
									{
										$errores["descripcion"]="";
									}
									
									if($id_pista=="-1")
									{
										$error=true;
										$errores["id_pista"]="¡No existe pistas!";
									}
									
									if($id_monitor=="-1")
									{
										$error=true;
										$errores["id_monitor"]="¡No existe monitores!";
									}
								
									if(!checkdate($mes_i, $dia_i, $ano_i))
									{
										$error=true;
										$errores["fecha_i"]="¡Fecha Incorrecta!";
									}
									
									if(!checkdate($mes_f, $dia_f, $ano_f))
									{
										$error=true;
										$errores["fecha_f"]="¡Fecha Incorrecta!";
									}
									
									$fecha_inicial = gmmktime(0,0,0,$mes_i,$dia_i,$ano_i);
									$fecha_final = gmmktime(0,0,0,$mes_f,$dia_f,$ano_f);
			
									if($error==false)
									{
										comprobar_fecha_hoy ($fecha_inicial, $errores, $error, $var="fecha_i");
										comprobar_fecha($fecha_inicial, $fecha_final, $errores, $error, $var="fecha_f");// Conectar con el servidor de base de datos
											
										if($error==false)
										{
											$fech_ini="$ano_i-$mes_i-$dia_i";
											$fech_fin="$ano_f-$mes_f-$dia_f";
											
											$meses = meses($fech_ini,$fech_fin);
																			
											if ($meses==0)
											{
												$error=true;
												$errores["fecha_f"]="¡Minimo es un mes!";
											}	
										}	
										
										//Nos conectamos el servidor
										//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
											or die ("No se puede conectar con el servidor");
										
										//comprobamos si el nombre está ya registrado
										$inst_busqueda = "select * from actividad where NOMBRE_AC like '$nombre'";
										$busqueda = mysqli_query ($conexion,$inst_busqueda)
			         						or die ("Fallo en la consulta comprueba nombre");
			         					$res_busqueda = mysqli_num_rows ($busqueda);
			         					if($res_busqueda!=0)
			         					{
			         						$errores["nombre"]="Curso ya guargado.";
											$error=true;
			         					}
			         					else
										{
											$errores["nombre"]="";
										}
									
										//Subir imagen
										if(is_uploaded_file ($_FILES['fotografia']['tmp_name']))
										{
											if($_FILES['fotografia']['error'] == UPLOAD_ERR_FORM_SIZE || $_FILES['fotografia']['error'] == UPLOAD_ERR_INI_SIZE)
											{
												$errores["fotografia"]="Imagen de Tama�o erroneo, debe tener maximo 500Kb";
												$error=true;
											}
										
											//Comprobacion del tipo de imagen
											else
											{
												if(strpos($tipo_archivo, "gif") || strpos($tipo_archivo, "jpeg") || strpos($tipo_archivo, "jpg") || strpos($tipo_archivo, "png"))
												{
													if(is_uploaded_file($_FILES['fotografia']['tmp_name']))
													{
														$dir="img/";
														$fichero=$usuario."-".$_FILES['fotografia']['name'];
														$completo=$dir.$fichero;
														if(is_file($completo))
														{
															$unico=time();
															$fichero=$usuario."-".$unico."-".$_FILES['fotografia']['name'];
															$completo=$dir.$fichero;
														}
														move_uploaded_file($_FILES['fotografia']['tmp_name'], $completo);
													}
													else
													{
														$errores["fotografia"]="No se ha podido subir el fichero";
														$error=true;
													}
												}
												else
												{
													$errores["fotografia"]="Imagen de tipo erroneo, debe ser JPEG, GIF o PNG";
													$error=true;
												}
											}
										}
									}
								}
									
								//listamos el contenido de las variables en la misma p�gina
								//Si se han introducido los datos se muestran
								
								if (isset($enviar) && $error==false)
								{
									//Nos conectamos el servidor
									
						$conexion = mysqli_connect ($servername, $username, $password,$database)
											or die ("No se puede conectar con el servidor");
											
									//código para introducir el usuario en la BD
										$instruccion = "INSERT INTO `actividad` (`NOMBRE_AC`, `FECHA_IN_AC`, `FECHA_FIN_AC`, `DESC_AC`, `FOTO_AC`, `PLAZAS`, `N_PLAZAS_DIS`, `PRECIO_AC`, `ID_MON`, `ID_PISTA`) VALUES ('$nombre', '$fecha_inicial', '$fecha_final', '$descripcion', '$completo', '$plazas', '$plazas', '$precio', '$id_monitor', '$id_pista')";											
														
									//realizamos la conexión a la bd y ejecutamos la instrucción
										$consulta=mysqli_query($conexion,$instruccion)
											or die("Fallo en la instrucción");
									
									$id = mysqli_insert_id($conexion);
									
									header("Location: detalle_curso.php?id=".$id."");
											
									//cerramos la BD
										$cerrar=mysqli_close($conexion);		
								}
								else
								{
						
								?>
								<!-- Estructura de nuestro formulario y envío de los datos a las variables junto con la llamada a la comprobaci�n de errores -->
								
								<h2>Insertar curso.</h2>
								
								<form action="inserta_curso.php" method="post" enctype="multipart/form-data">
									<fieldset>
										<legend>Datos del curso</legend>
										<table class="margen2">
											<tr>	
												<td>Nombre: </td>
												<td>
													<input type="text" name="nombre" size="30" maxlength="30" value="<?php print $nombre;?>">
													<?php 
														if (trim($errores["nombre"])!= "")
														{
															print ("<span class='error'>" . $errores["nombre"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Precio: </td>
												<td>
													<input type="text" name="precio" size="3" maxlength="3" value="<?php print $precio;?>">
													<?php 
														if (trim($errores["precio"])!= "")
														{
															print ("<span class='error'>" . $errores["precio"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Plazas: </td>
												<td>
													<input type="text" name="plazas" size="3" maxlength="3" value="<?php print $plazas;?>">
													<?php 
														if (trim($errores["plazas"])!= "")
														{
															print ("<span class='error'>" . $errores["plazas"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>
												<td>Monitor: </td>
												<td>
													<select name="id_monitor">
														<?php 
															//Nos conectamos el servidor
									
						$conexion = mysqli_connect ($servername, $username, $password,$database)
									or die ("No se puede conectar con el servidor");
																	
															$instruccion = "select * from monitor order by NOMBRE_MON";
															
															$consulta = mysqli_query($conexion, $instruccion) or die ("No se ha podido hacer la consulta monitor");
															
															$nfilas = mysqli_num_rows($consulta);
															
															if($nfilas>0)
															{
																for($i=0; $i<$nfilas; $i++)
																{
																	$resultado = mysqli_fetch_array($consulta);
																	echo "<option value='".$resultado['ID_MON']."'>".$resultado['NOMBRE_MON']."</option>";
																}
															}
															else
															{
																echo "<option value='-1'>vacío</option>";
															}
														
														//cerramos la BD
														$cerrar=mysqli_close($conexion);		
														?>
														
													</select>
													<?php 
														if (isset($errores["monitor"]) && trim($errores["monitor"])!= "")
														{
															print ("<span class='error'>" . $errores["monitor"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>
												<td>Pista: </td>
												<td>
													<select name="id_pista">
														<?php 
															//Nos conectamos el servidor
															
						$conexion = mysqli_connect ($servername, $username, $password,$database)
															or die ("No se puede conectar con el servidor");

															$instruccion = "select * from pista";
															$consulta = mysqli_query($conexion, $instruccion) or die ("No se ha podido hacer la consulta pista");
															
															$nfilas = mysqli_num_rows($consulta);
															
															if($nfilas>0)
															{
																for($i=0; $i<$nfilas; $i++)
																{
																	$resultado = mysqli_fetch_array($consulta);
																	echo "<option value='".$resultado['ID_PISTA']."'>".$resultado['NOMBRE_PISTA']."</option>";
																}
															}
															else
															{
																echo "<option value='-1'>vacío</option>";
															}
															
															//cerramos la BD
															$cerrar=mysqli_close($conexion);	
														?>
													</select>
													<?php 
														if (isset($errores["edad"]) && trim($errores["edad"])!= "")
														{
															print ("<span class='error'>" . $errores["edad"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr><td>Fecha inicio: </td>
												<td>
												<select name="dia_i">
														<?php 
															for ($i=1;$i<32;$i++)
															{											
																$a = date("d");
																
																if($i<10)
																{
																	$i="0".$i;
																}
																
																if ($i == $a)
																{
																	print "<option value='".$i."' selected>".$i."";
																}
																else
																{
																	print "<option value='".$i."'>".$i."";
																}										
															}
														?>
													</select>
													<select name="mes_i">
														<?php 
															$meses="Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre";
															$num = explode(",", $meses);
															for ($i=0;$i<12;$i++)
															{
																$b=$i+1;
																$a = date("n");
																
																if ($b==$a)
																{
																	print "<option value='".$b."' selected>".$num[$i]."";
																}
																else
																{
																	print "<option value='".$b."'>".$num[$i]."";
																}
																
															}
														?>
													</select>
													<select name="ano_i">
														<?php 
															$a = date("Y");
															
															$b=$a+6;
															for ($i=$a;$i<$b;$i++)
															{
																if($a==$i)
																{
																	print "<option value='".$i."' selected>".$i."";
																}
																else
																{
																	print "<option value='".$i."'>".$i."";
																}
																
															}
														?>
													</select>
													<?php 
														if (isset($errores["fecha_i"]) && trim($errores["fecha_i"])!= "")
														{
															print ("<span class='error'>" . $errores["fecha_i"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>
										  		<td>Fecha fin: </td>
												<td>
													<select name="dia_f">
														<?php 
															for ($i=1;$i<32;$i++)
															{											
																if($i<10)
																	$i="0".$i;
																											
																print "<option value='".$i."'>".$i."";											
															}
														?>
													</select>
													<select name="mes_f">
														<?php 
															$meses="Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre";
															$num = explode(",", $meses);
															for ($i=0;$i<12;$i++)
															{
																$b=$i+1;
																print "<option value='".$b."'>".$num[$i]."";											
															}
														?>
													</select>
													<select name="ano_f">
														<?php 
															$a = date("Y");
															$b=$a+6;
															for ($i=$a;$i<$b;$i++)
															{
																print "<option value='".$i."'>".$i."";
															}
														?>
													</select>
													<?php 
														if (isset($errores["fecha_f"]) && trim($errores["fecha_f"])!= "")
														{
															print ("<span class='error'>" . $errores["fecha_f"] . "</span>");
														}
													?>
												</td>
											</tr>
											
										</table>
									</fieldset>							
									
									<fieldset class="margen8">
										<legend>Adjuntar fotografía</legend>
										<table class="margen5">
											<tr>
												<td>
													<input type="hidden" name="MAX_FILE_SIZE" value="102400">
													<input type="file" name="fotografia" size="50">
													<?php 
														if (isset($errores["fotografia"]) && trim($errores["fotografia"])!= "")
														{
															print ("<span class='error'>" . $errores["fotografia"] . "</span>");
														}
													?>
												</td>
											</tr>
										</table>
									</fieldset>
									
									<fieldset class="margen8">
										<legend>Descripción</legend>
										<textarea class="margen5" cols="40" rows="4" name="descripcion"></textarea>
										<?php print ("<span class='error'>" . $errores["descripcion"] . "</span>");?>
									</fieldset>	
									
								<div class="margen8"><input type="submit" name="enviar" value="Enviar Datos"><input type="reset" name="borrar" value="Borrar Datos"></div>
							
								</form>
						<?php 
							}
						}
						?>
						
			
			
		</div>
		<div align="center">
				<?php include('includes/footerbis.php'); ?>
			</div>
	</body>
</html>
		
