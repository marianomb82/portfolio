<?php
	//@utor: Mariano Martín
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es" xmlns="http://www.w3.org/1999/xhtml">
<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
	<title>Club Deportivo Sevilla</title>
	<link href="css/estilos.css" rel="stylesheet" type="text/css" media="screen" />
	<script language="javascript" type="text/javascript" src="js/precarga.js"></script>
</head>

<body onLoad="MM_preloadImages('imagenes/presentacion_on.png', 'imagenes/tarifa_on.png', 'imagenes/eventos_on.png','imagenes/actividades_on.png', 'imagenes/contacto_on.png', 'imagenes/login_on.png')">
	<div id="global">

		<?php include('includes/header.php'); ?>

        <div id="cuerpo">
			<div id="contenido">
            	<div id="columna1" align="center">
                	<img src="imagenes/img_inicio.jpg" border="0" alt="Imagen de Presentaci&oacute;n de la Web" style="margin-top:80px;" />
                </div>
                <div id="columna2">
                	<h2>Presentación</h2>
                    <p>Bienvenido a la página web del Club Deportivo Sevilla.</p>
					<p>Con nosotros podrás encontrar todas las alternativas para mantener tu cuerpo en forma, cambiar tu aspecto físico, aumentar o disminuir de peso, hacer rehabilitación y además podrás mejorar tu salud, en definitiva hacer lo necesario para sentirte mejor.</p>
					<p>Ponemos a tu disposición un elenco de monitores con gran experiencia.</p> 
					<p>Aprovecha y acércate a conocernos, contamos con las instalaciones para los más exigentes, ponemos a tu disposición varias salas:<br />
Sala de Aeróbic<br />
Sala de Spinning<br />
Sala de Cardio<br />
Sala de Musculación<br />
Pistas de Tenis<br />
Pistas de Fútbol<br />
Pistas de Basquet<br />
Pistas de Padel</p>

					<p>Con un horario que muy pocos pueden igualar.</p>

<p>Sin olvidar el ambiente que te encontraras con nosotros donde te sentirás como en casa.</p>

<p>¡Apúntate ahora!</p>
                </div>
            </div>
        </div>

		<?php include('includes/footer.php'); ?>

    </div>
</body>
</html>