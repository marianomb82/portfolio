CREATE DATABASE `proyecto`;

CREATE TABLE `proyecto`.`usuarios_registrados` (
`usuario` varchar(100) NOT NULL default '',
`password` varchar(100) NOT NULL default '',
PRIMARY KEY (`usuario`)
);

CREATE TABLE `proyecto`.`agenda` (
`id` SMALLINT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`usuario` VARCHAR( 100 ) NOT NULL,
`nombre` VARCHAR( 100 ) NOT NULL DEFAULT '',
`telefono` INT( 9 ) NOT NULL ,
`email` VARCHAR( 100 ) NULL DEFAULT '',
`sexo` VARCHAR( 6 ) NULL DEFAULT '',
`edad` INT( 3 ) NULL ,
`direccion` VARCHAR( 600 ) NULL DEFAULT '',
`categoria` VARCHAR( 10 ) NULL DEFAULT '',
`fotografia` VARCHAR( 800 ) NULL DEFAULT '',
`comentario` TEXT NULL DEFAULT '',
FOREIGN KEY ( `usuario` ) REFERENCES `proyecto`.`usuarios_registrados` ( `usuario` ) on delete cascade
);

CREATE TABLE `proyecto`.`encuestas` (
`id_encuesta` VARCHAR(5) NOT NULL DEFAULT '',
`pregunta` VARCHAR(150) DEFAULT NULL,
`opciones` VARCHAR(254) DEFAULT NULL,
`id_opcion` VARCHAR(5) NOT NULL DEFAULT '',
`ip` VARCHAR(15) NOT NULL DEFAULT '',
`fecha` DATE DEFAULT NULL
); 

insert into `proyecto`.`agenda`(usuario, nombre, telefono, email, sexo, edad, direccion, categoria, fotografia, comentario) values ('mariano','Juan','987654321','proyectos.asi.triana@gmail.com','hombre','16 a 30','C\Falsa 123','familia','img/Avatar-1.png','holaaaaa');
insert into `proyecto`.`agenda`(usuario, nombre, telefono, email, sexo, edad, direccion, categoria, fotografia, comentario) values ('mariano','Pepe','321654987','proyectos.asi.triana@gmail.com','hombre','31 a 45','C\Falsa 3','familia','img/Avatar-2.png','holaaaaa');
insert into `proyecto`.`agenda`(usuario, nombre, telefono, email, sexo, edad, direccion, categoria, fotografia, comentario) values ('mariano','Paco','654321987','proyectos.asi.triana@gmail.com','hombre','16 a 30','C\Falsa 1','familia','img/Avatar-3.png','holaaaaa');
insert into `proyecto`.`agenda`(usuario, nombre, telefono, email, sexo, edad, direccion, categoria, fotografia, comentario) values ('mariano','Antonio','123456789','proyectos.asi.triana@gmail.com','hombre','16 a 30','C\Falsa 2','amigos','img/Avatar-4.png','holaaaaa');
insert into `proyecto`.`agenda`(usuario, nombre, telefono, email, sexo, edad, direccion, categoria, fotografia, comentario) values ('mariano','Lorena','123456789','proyectos.asi.triana@gmail.com','mujer','16 a 30','C\Falsa 2','amigos','img/Avatar-5.png','holaaaaa');
insert into `proyecto`.`agenda`(usuario, nombre, telefono, email, sexo, edad, direccion, categoria, fotografia, comentario) values ('mariano','Maria','123456789','proyectos.asi.triana@gmail.com','mujer','16 a 30','C\Falsa 2','amigos','img/Avatar-6.png','holaaaaa');
insert into `proyecto`.`agenda`(usuario, nombre, telefono, email, sexo, edad, direccion, categoria, fotografia, comentario) values ('mariano','Pepa','123456789','proyectos.asi.triana@gmail.com','mujer','16 a 30','C\Falsa 2','trabajo','img/Avatar-7.png','holaaaaa');
insert into `proyecto`.`agenda`(usuario, nombre, telefono, email, sexo, edad, direccion, categoria, fotografia, comentario) values ('mariano','Espe','123456789','proyectos.asi.triana@gmail.com','mujer','16 a 30','C\Falsa 2','trabajo','img/Avatar-8.png','holaaaaa');
insert into `proyecto`.`agenda`(usuario, nombre, telefono, email, sexo, edad, direccion, categoria, fotografia, comentario) values ('mariano','Juani','123456789','proyectos.asi.triana@gmail.com','mujer','16 a 30','C\Falsa 2','trabajo','img/Avatar-9.png','holaaaaa');

