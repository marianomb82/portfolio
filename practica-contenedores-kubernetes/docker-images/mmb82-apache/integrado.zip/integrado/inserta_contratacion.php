<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
	include ("lib/funciones.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
							<?php 
								if($usuario=="")
								{
									print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
									print ("<div class='margen'>&nbsp;</div>");
									print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
								}	
							else
							{
							//Con esto llamamos al archivo donde tenemos las funciones
							
								$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
								$id_actividad=(isset($_REQUEST['id_actividad'])) ? $_REQUEST['id_actividad'] : false;
								$id_socio=(isset($_REQUEST['id_socio'])) ? $_REQUEST['id_socio'] : false;
								$dni=(isset($_REQUEST['dni'])) ? $_REQUEST['dni'] : false;
								$dia_i=(isset($_REQUEST['dia_i'])) ? $_REQUEST['dia_i'] : false;
								$mes_i=(isset($_REQUEST['mes_i'])) ? $_REQUEST['mes_i'] : false;
								$ano_i=(isset($_REQUEST['ano_i'])) ? $_REQUEST['ano_i'] : false;
								$dia_f=(isset($_REQUEST['dia_f'])) ? $_REQUEST['dia_f'] : false;
								$mes_f=(isset($_REQUEST['mes_f'])) ? $_REQUEST['mes_f'] : false;
								$ano_f=(isset($_REQUEST['ano_f'])) ? $_REQUEST['ano_f'] : false;
								$importe=(isset($_REQUEST['importe'])) ? $_REQUEST['importe'] : false;
								$error=false;
							
								if (isset($enviar))//Comprobamos si se no se han introducido los datos en el formulario
								{
									if(!checkdate($mes_i, $dia_i, $ano_i))
									{
										$error=true;
										$errores["fecha_i"]="¡Fecha Incorrecta!";
									}
									
									if(!checkdate($mes_f, $dia_f, $ano_f))
									{
										$error=true;
										$errores["fecha_f"]="¡Fecha Incorrecta!";
									}
					
									$fecha_i = gmmktime(0,0,0,$mes_i, $dia_i, $ano_i);
									$fecha_f = gmmktime(0,0,0,$mes_f, $dia_f, $ano_f);
									
									comprobar_fecha_hoy ($fecha_i, $errores, $error, $var="fecha_i");
									comprobar_fecha($fecha_i, $fecha_f, $errores, $error, $var="fecha_f");
									
									//Comprobamos si el DNI est� Vacío y correcto
									if(trim ($dni)=="")
									{
										$errores["dni"]="Introduzca el DNI";
										$error=true;
									}
									else if (!preg_match('/^[0-9]{8}[A-Z,a-z]{1}$/', $dni))
									{
										$errores["dni"]="Introduzca bien el DNI, XXXXXXXXA";
										$error=true;
									}
									else
									{
										$errores["dni"]="";
									}
									
									
									if($error==false)
									{
										$fech_ini="$ano_i-$mes_i-$dia_i";
										$fech_fin="$ano_f-$mes_f-$dia_f";
										
										$meses = meses($fech_ini,$fech_fin);
										
										if($meses>1)
										{
											$error=true;
											$errores['fecha_f']="�Como m�ximo es un Mes!";
										}
									}
																											
									if($error==false)
									{														
										// Conectar con el servidor de base de datos
										//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
											or die ("No se puede conectar con el servidor");
								
											
										$instruccion = "select * from socio where DNI_SO like '".$dni."'";
																				
										$consulta = mysqli_query ($conexion,$instruccion,)
											or die ("Fallo en la consulta");
											
										$nfilas = mysqli_num_rows ($consulta);
										
										if ($nfilas > 0)
										{
											$resultado = mysqli_fetch_array ($consulta);
											
											$id_socio=$resultado['ID_SO'];
										}
										else
										{
											$error=true;
								      		$errores["dni"]="¡No existe ningun socio con ese dni!";
										}
										$close = mysqli_close ($conexion);
		
										// Conectar con el servidor de base de datos
										
						$conexion = mysqli_connect ($servername, $username, $password,$database)
											or die ("No se puede conectar con el servidor");
											
										$instruccion = "select * from realiza where ID_SO like '".$id_socio."' and ID_AC like '".$id_actividad."'";
										
										$consulta = mysqli_query ($conexion,$instruccion,)
												or die ("Fallo en la consulta");
												
										$nfilas = mysqli_num_rows ($consulta);
										
										if($nfilas>0)
										{
											$error=true;
											$errores["dni"]="este socio ya tiene un contrato con est� actividad";
										}
										
									}
								}
								//listamos el contenido de las variables en la misma p�gina
								//Si se han introducido los datos se muestran
								
								if (isset($enviar) && $error==false)
								{
									// Conectar con el servidor de base de datos
									
						$conexion = mysqli_connect ($servername, $username, $password,$database)
									or die ("No se puede conectar con el servidor");
											
									//código para introducir el usuario en la BD
										$instruccion = "select * from actividad where ID_AC like '".$id_actividad."'";														
									
									//realizamos la conexión a la bd y ejecutamos la instrucción
										$consulta = mysqli_query ($conexion,$instruccion) 
											or die("Fallo en la instrucción");
										
										$resultado = mysqli_fetch_array ($consulta);
										$importe = $resultado['PRECIO_AC'];
											
									//Creamos una instrucción para introducir el evento en la base de datos. 
									$instruccion5 = "INSERT INTO `realiza` (`ID_AC`, `ID_SO`, `FECHA_INICIO_RE`, `FECHA_FIN_RE`, `IMPORTE_RE`) VALUES ('$id_actividad', '$id_socio', '$fecha_i', '$fecha_f', '$importe');";
									
									//Ejecutamos la instrucción.
									$consulta = mysqli_query ($conexion,$instruccion5)
										or die ("No se ha podido hacer la consulta de introducir el evento");
										
									$num = mysqli_insert_id($conexion);
					
									$total = $resultado['N_PLAZAS_DIS']-1;
													
									$instruccion = "update actividad set N_PLAZAS_DIS='".$total."' where ID_AC like '".$id_actividad."'";
													
									//Ejecutamos la instrucción.
									$consulta = mysqli_query ($conexion,$instruccion,) or die ("No se ha podido hacer la consulta");
									
									//cerramos la BD
										$cerrar=mysqli_close($conexion);		
																
									print("<h1>Detalles de la contratación</h1>");
									print("<table id='detalle'>");  
						         	print ("<tr><td><b>Nombre: </b>". $resultado['NOMBRE_AC'] ."</td></tr>");  
									print ("<tr><td><b>DNI: </b>". $dni ."</td></tr>");
									print ("<tr><td><b>Importe: </b>". $resultado['PRECIO_AC'] ."</td></tr>");
									$fecha_i = date("d/n/Y",$fecha_i); 
									print ("<tr><td><b>Fecha inicio: </b>". $fecha_i ."</td></tr>");
									$fecha_f = date("d/n/Y",$fecha_f);
									print ("<tr><td><b>Fecha fin: </b>". $fecha_f ."</td></tr>");
									
								}
								else
								{
						
								?>
								<!-- Estructura de nuestro formulario y env�o de los datos a las variables junto con la llamada a la comprobaci�n de errores -->
								
								<h2>Insertar contratación.</h2>
								
								<form action="inserta_contratacion.php" method="post" enctype="multipart/form-data">
									<fieldset>
										<legend>Datos de la contratación</legend>
										<table class="margen2">
											<tr>	
												<td>Nombre: </td>
												<td>
													<select name="id_actividad">
														<?php 
														
															// Conectar con el servidor de base de datos
															
						$conexion = mysqli_connect ($servername, $username, $password,$database)
																or die ("No se puede conectar con el servidor");
																
															$hoy = gmmktime(0,0,0,date("n"), date("d"), date("Y"));									
															
															$instruccion = "select * from actividad where FECHA_FIN_AC > $hoy";
															
															$consulta = mysqli_query ($conexion,$instruccion,) or die ("No se ha podido realizar la consulta");
																
															$nfilas = mysqli_num_rows ($consulta);
															
															if ($nfilas > 0)
															{
																for ($i=0; $i<$nfilas; $i++)
																{
																	$resultado = mysqli_fetch_array ($consulta);
																	
																	print "<option value='".$resultado['ID_AC']."'>".$resultado['NOMBRE_AC']."";
																}
															}
															else
															{
																print "<option value='No hay actividades'>Vacío";
																$error=true;
													      		$errores["actividad"]="¡No hay Materiales para alquilar!";
															}
						
														?>
													</select>
													<?php
														if (isset($_REQUEST['precio']) && trim($errores["precio"])!= "")
														{
															print ("<span class='error'>" . $errores["precio"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>DNI: </td>
												<td>
													<input type="text" name="dni" size="9" maxlength="9" value="<?php print $dni;?>">
													<?php 
														if (trim($errores["dni"])!= "")
														{
															print ("<span class='error'>" . $errores["dni"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>
												<td>Fecha inicio: </td>
												<td>
												<select name="dia_i">
														<?php 
															for ($i=1;$i<32;$i++)
															{											
																$a = date("d");
																
																if($i<10)
																{
																	$i="0".$i;
																}
																
																if ($i == $a)
																{
																	print "<option value='".$i."' selected>".$i."";
																}
																else
																{
																	print "<option value='".$i."'>".$i."";
																}										
															}
														?>
													</select>
													<select name="mes_i">
														<?php 
															$meses="Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre";
															$num = explode(",", $meses);
															for ($i=0;$i<12;$i++)
															{
																$b=$i+1;
																$a = date("n");
																
																if ($b==$a)
																{
																	print "<option value='".$b."' selected>".$num[$i]."";
																}
																else
																{
																	print "<option value='".$b."'>".$num[$i]."";
																}
																
															}
														?>
													</select>
													<select name="ano_i">
														<?php 
															$a = date("Y");
															
															$b=$a+6;
															for ($i=$a;$i<$b;$i++)
															{
																if($a==$i)
																{
																	print "<option value='".$i."' selected>".$i."";
																}
																else
																{
																	print "<option value='".$i."'>".$i."";
																}
																
															}
														?>
													</select>
													<?php 
														if (isset($_REQUEST['fecha_i']) && trim($errores["fecha_i"])!= "")
														{
															print ("<span class='error'>" . $errores["fecha_i"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>
										  		<td>Fecha fin: </td>
												<td>
													<select name="dia_f">
														<?php 
															for ($i=1;$i<32;$i++)
															{											
																if($i<10)
																	$i="0".$i;
																											
																print "<option value='".$i."'>".$i."";											
															}
														?>
													</select>
													<select name="mes_f">
														<?php 
															$meses="Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre";
															$num = explode(",", $meses);
															for ($i=0;$i<12;$i++)
															{
																$b=$i+1;
																print "<option value='".$b."'>".$num[$i]."";											
															}
														?>
													</select>
													<select name="ano_f">
														<?php 
															$a = date("Y");
															$b=$a+6;
															for ($i=$a;$i<$b;$i++)
															{
																print "<option value='".$i."'>".$i."";
															}
														?>
													</select>
													<?php 
														if (isset($_REQUEST['fecha_f']) && trim($errores["fecha_f"])!= "")
														{
															print ("<span class='error'>" . $errores["fecha_f"] . "</span>");
														}
													?>
												</td>
											</tr>
											
										</table>
									</fieldset>							
									
								<div class="margen8"><input type="submit" name="enviar" value="Enviar Datos"><input type="reset" name="borrar" value="Borrar Datos"></div>
							
								</form>
						<?php 
							}
						}
						?>
					</td>
				</tr>
											
			</table>
			
			
		</div>
		<div align="center">
				<?php include('includes/footerbis.php'); ?>
			</div>
	</body>
</html>
		
