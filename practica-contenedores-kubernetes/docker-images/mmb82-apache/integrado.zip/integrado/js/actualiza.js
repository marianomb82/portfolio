// JavaScript Document

function actualizaPagina ()
	   {
		
	      i = document.forms.selecciona.seleccion.selectedIndex;
	      seleccion =document.forms.selecciona.seleccion.options[i].value;
	      window.location = 'album.php?seleccion=' + seleccion;  
		}