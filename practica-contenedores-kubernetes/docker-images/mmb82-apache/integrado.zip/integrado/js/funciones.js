// JavaScript Document

function espacios(cadena){
	space = false;
	for(i=0;i<(cadena.length-1);i++){
		if(cadena.charCodeAt(i) == 32 && cadena.charCodeAt(i+1) == 32){
			space = true;	
		}
	}
	return space;
}

//Funcion que validan el formulario de consulta.
function validar_consulta(){
	if(validaNombre() && validaTelefono() && validaCorreo() && validaConsulta()){
		document.EnviarConsulta.submit();
	}
}

function validaNombre(){
	nom = document.EnviarConsulta.nombre.value;
	
	if(nom.length < 3 || espacios(nom)){
		alert("Por favor introduzca su nombre.");
		document.EnviarConsulta.nombre.focus();
		return false;
	}
	else{
		return true;
	}
}

function validaTelefono(){
	tlf = document.EnviarConsulta.telefono.value;
	
	if(tlf.length == 9 && /^([0-9])*$/.test(tlf)){
		return true;
	}
	else{
		alert("Introduce un n\u00famero de tel\u00e9fono correcto.");
		document.EnviarConsulta.telefono.focus();
		return false;
	}
}

function validaCorreo(){
	mail = document.EnviarConsulta.email.value;
	re=/^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,3})$/
    
	if(!re.exec(mail))    {
		alert("Por favor introduzca un correo valido.");
		document.EnviarConsulta.email.focus();
        return false;
    }else
        return true;
}

function validaConsulta(){
	con = document.EnviarConsulta.consulta.value;
	
	if(con.length < 3){
		alert("Por favor introduzca una consulta.");
		document.EnviarConsulta.consulta.focus();
		return false;
	}
	else{
		return true;
	}
}