<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=(isset($_REQUEST['usuario'])) ? $_REQUEST['usuario'] : false;
	
	include ('pdf/class.ezpdf.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
								<?php 
						 			// Conectar con el servidor de base de datos
									//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
									or die ("No se puede conectar con el servidor");
					
									$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
									$monitor=(isset($_REQUEST['monitor'])) ? $_REQUEST['monitor'] : false;
									$error=false;
													
						 			if(isset($enviar))
						 			{
						 				if($monitor=="-1")
						 				{
						 					$error=true;
						 					$errores['monitor']="NO EXISTE MONITORES";	 					
						 				}
						 			}
						 			
						 			if(isset($enviar) && $error==false)
						 			{	 				
										
						 				
										$instruccion3 = "select * from actividad where ID_MON='$monitor' order by NOMBRE_AC asc";
					
										$consulta3 = mysqli_query($conexion,$instruccion3) or die ("No se puede hacer la consulta");
										
										$nfilas = mysqli_num_rows ($consulta3);
															
										if ($nfilas > 0)
										{
											?>
											<center><h2>Listado de cursos que ha impartido el monitor</h2></center>
											<center>	
											<div class="correo">
							 				<form name="consulta1.php" method="post" enctype="multipart/form-data">
								 				<fieldset class="margen">
													
													<table cellpadding="4">
														<tr>												<tr>
															<th>Actividad</th>
															<th>Monitor</th>
															<th>Pista</th>
															<th>Plazas</th>
															<th>Fecha Fin</th>
														</tr>
														
												<?php 
													for ($i=0; $i<$nfilas; $i++)
													{
														$resultado3 = mysqli_fetch_array ($consulta3);
												?>
													<tr>
														<td><?php print $resultado3['NOMBRE_AC']?></td>
														<td>
															<?php
															
																$instruccion4 = "select * from monitor where ID_MON like '".$resultado3['ID_MON']."'";
																								
																$consulta4 = mysqli_query($conexion,$instruccion4)
																	or die ("No se puede hacer la consulta");
																	
																$resultado4 = mysqli_fetch_array ($consulta4);
																
																print "".$resultado4['NOMBRE_MON']." ".$resultado4['APELLIDOS_MON']."";
															?>
														</td>
														<td>
															<?php 
															
																$instruccion4 = "select * from pista where ID_PISTA like '".$resultado3['ID_PISTA']."'";
																								
																$consulta4 = mysqli_query($conexion,$instruccion4)
																	or die ("No se puede hacer la consulta");
																	
																$resultado4 = mysqli_fetch_array ($consulta4);
																
																print $resultado4['NOMBRE_PISTA'];
																
															?>
														</td>
														<td><?php print $resultado3['PLAZAS']?></td>
														<td><?php $fecha_f = date("d/n/Y",$resultado3['FECHA_FIN_AC']); echo $fecha_f;?></td>
													</tr>
																									<?php 
													}
													
										print "<tr>";
										print "<tr><td>&nbsp;</td></tr>";
										print "	<td><b>Total Cursos: " .$nfilas. "</b></td>";
										print "	</tr>";
										
										print "</table>";
										print "</fieldset>";
							 		print "</form>";
																							
									echo "</div>";
									echo "</center>";	
												echo "<center>";
												print "<div id='insertar'>";
												print "<table><tr><td><a href='pdf1.php?monitor=".$monitor."' target='_new'><img src='imagenes/pdf.png' title='Crear PDF'></img></a></td></tr></table>";
												print "<p class='necesario'><i>Pinche en el icono para crear el pdf.</i></p>";
												echo "</div>";
												echo "<center>";
											
												
											}
											else
											{
												print "No hay actividades";
											}
										?>
											
							<?php 	
						 			}
						 			else
						 			{
						 ?>			
						 			<h2>Listado de cursos que ha impartido un monitor determinado</h2>
						 			<div class="correo">
						 				<form name="consulta1.php" method="post" enctype="multipart/form-data">
							 				<fieldset>
												<legend>Seleccione un Monitor</legend>
												<table class="margen2">
													<tr><td>&nbsp;</td></tr>
													<tr>	
														<td>Nombre: </td>
														<td>
															<select name="monitor">
										 						<?php 
										 						$instruccion = "select * from monitor";
										 						
										 						//Ejecutamos la consulta						
																$consulta=mysqli_query ($conexion,$instruccion)
																	or die ("No se ha podido hacer la consulta");
																	
																$nfilas = mysqli_num_rows ($consulta);
													
																if ($nfilas > 0)
													      		{
													      			for ($i=0;$i<$nfilas;$i++)
													      			{
													      				$resultado = mysqli_fetch_array ($consulta);
													      				print "<option value='".$resultado['ID_MON']."'>".$resultado['NOMBRE_MON']." ".$resultado['APELLIDOS_MON']."</option>";
													      				
													      			}
													      			
													      		}
													      		else
													      		{
													      			print "<option value='-1'>No existen monitores</option>";
													      		}
									
										 						?>
								 							</select>
														</td>
								 						<td>
								 							<?php 
																if (trim($errores["monitor"])!= "")
																{
																	print ("<span class='error'>" . $errores["monitor"] . "</span>");
																}
															?>
														</td>
								 						<td><input type="submit" name="enviar" value="Crear Consulta"></input></td>											</tr>	
													</tr>
													<tr><td>&nbsp;</td></tr>
												</table>
											</fieldset>
						 				</form>	
						 			</div>
						 		<?php 
	 								}
								?>
							</div>	
				       </td>
				  	</tr>
	           </table>
	         </div>  
	        <div align="center">
					<?php include('includes/footerbis.php'); ?>
			</div>
		</div>
	</body>
</html>