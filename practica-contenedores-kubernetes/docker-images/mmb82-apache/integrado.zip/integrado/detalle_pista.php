<?php
	//@utor: Mariano Mart�n
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
								<?php 
									if($usuario=="")
									{
										print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
										print ("<div class='margen'>&nbsp;</div>");
										print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
									}	
								else
								{
								
									$usuario=(isset($_REQUEST['usuario'])) ? $_REQUEST['usuario'] : false;
									$password=(isset($_REQUEST['password'])) ? $_REQUEST['password'] : false;
									$id=(isset($_REQUEST['id'])) ? $_REQUEST['id'] : false;
									$volver=(isset($_REQUEST['volver'])) ? $_REQUEST['volver'] : false;			
								
									// Conectar con el servidor de base de datos
									//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
										or die ("No se puede conectar con el servidor");
								
									$instruccion = "select * from pista where ID_PISTA='$id'";
										
									// Enviar consulta
									      
									      $consul = mysqli_query ($conexion,$instruccion)
									         or die ("Fallo en la consulta");
								
								   // Mostrar resultados de la consulta
								      $nfilas = mysqli_num_rows ($consul);
						      
								if ($nfilas > 0)
						      	{
						        	$resul = mysqli_fetch_array ($consul);
						                      		
						         	print("<h1>Detalles de la pista</h1>");
									print("<table id='detalle'>");  
						         	print ("<tr><td><b>Nombre: </b>". $resul['NOMBRE_PISTA'] ."</td></tr>");  
									print ("<tr><td><b>Ancho: </b>". $resul['ANCHO'] ."</td></tr>");
									print ("<tr><td><b>Largo: </b>". $resul['LARGO'] ."</td></tr>");
									print("</table>");
						      	}
							
								// Cerrar conexi�n
									mysqli_close ($conexion);
								}
								?>
										
							</div>
				       </td>
				  	</tr>
	           </table>
	           <div align="center">
					<?php include('includes/footerbis.php'); ?>
				</div>
		</div>
	</body>
</html>
		</div>
	</body>
</html>