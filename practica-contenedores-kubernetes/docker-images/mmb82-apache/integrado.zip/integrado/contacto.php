<?php
	//@utor: Mariano Martín
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es" xmlns="http://www.w3.org/1999/xhtml">
<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
	<title>Club Deportivo Sevilla</title>
	<link href="css/estilos.css" rel="stylesheet" type="text/css" media="screen" />
	<script language="javascript" type="text/javascript" src="js/precarga.js"></script>
</head>

<body onLoad="MM_preloadImages('imagenes/presentacion_on.png', 'imagenes/tarifa_on.png', 'imagenes/eventos_on.png','imagenes/actividades_on.png', 'imagenes/contacto_on.png', 'imagenes/login_on.png')">
	<div id="global">

		<?php include('includes/header.php'); ?>

        <div id="cuerpo">
			<div id="contenido">
            	<div id="columna1" align="center">
                	<img src="imagenes/correo.png" border="0" alt="" style="margin-top:70px;" />
                </div>
                <div id="columna2">
                	<h2>Contacto</h2>
                    <p>Envianos t&uacute; consulta y te contestaremos lo antes posible.</p>
                		<?php 
	
	$asunto=(isset($_REQUEST['asunto'])) ? $_REQUEST['asunto'] : false;
	$email=(isset($_REQUEST['email'])) ? $_REQUEST['email'] : false;
	$contenido=(isset($_REQUEST['contenido'])) ? $_REQUEST['contenido'] : false;
	$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
	$borrar=(isset($_REQUEST['borrar'])) ? $_REQUEST['borrar'] : false;
	$error=false;
	
	if(isset($enviar))
	{
		if(trim($asunto)=="")
		{
			$error=true;
			$errores['asunto']="Introduzca un asunto.\n";
		}
		
		if(trim($email)=="")
		{
			$error=true;
			$errores['email']="Debe introducir un correo de contacto.\n";
		}
		else
			if(!preg_match('/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i', $email))
				{
					$error=true;
					$errores['email']="El email introducido no es válido.\n";
				}

		if(trim($contenido)=="")
		{
			$error=true;
			$errores['contenido']="Debe introducir un mensaje.\n";
		}
		
	}
	
	if(isset($enviar) && $error==false)
	{
		$header="From: $email <$email>";
		
		$para="proyectos.asi.triana@gmail.com ";
		
		//$contenido=$contenido . "Enviado por: $email";
		
		$enviado=mail($para,$asunto,$contenido,$header);
	
		if($enviado)
			print "Mail enviado\n";
		else
			print "No se ha podido enviar el email.\n";
	}
	else 
	{
	?>
		<div id="contacto">
			<table>
				<tr>
					<td>
						<form action="contacto.php" method="post">
						
							<label class="letra_contacto">Asunto:</label><br />
							<input type="text" name="asunto">
							<?php 
								if($errores['asunto']!="") 
									print "<span class='error'>".$errores['asunto']."</span>"
							?>
							<br /><br />
							<label class="letra_contacto">Su email:</label><br>
							<input type="text" name="email">
							<?php 
								if($errores['email']!="") 
									print "<span class='error'>".$errores['email']."</span>"
							?>
							<br /><br />
							<label class="letra_contacto">Mensaje:</label><br />
							<textarea rows="5" cols="20" name="contenido"></textarea>
							<?php 
								if($errores['contenido']!="") 
									print "<span class='error'>".$errores['contenido']."</span>"
							?>
							
							<br /><br />
							<input type="submit" name="enviar" value="Enviar">   <input type="reset" name="borrar" value="Borrar Datos">
						</form>
					</td>
				</tr>
			</table>
		</div>
	<?php 
		}
	?>
                </div>
            </div>
        </div>

		<?php include('includes/footer.php'); ?>

    </div>
</body>
</html>