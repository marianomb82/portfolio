<?php
	//@utor: Mariano Mart�n
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	


	include ('pdf/class.ezpdf.php');
	
	// Conectar con el servidor de base de datos
							//variables para la conexi�n
							$servername = getenv("DB_HOST");
							$database = getenv("DB_NAME");
							$username = getenv("DB_USER");
							$password = getenv("DB_PASSWORD");
						
							$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
	
	
	$pdf =& new Cezpdf('a4');
	$pdf->selectFont('pdf/fonts/Helvetica.afm');
	$pdf->ezSetCmMargins(1,1,1.5,1.5);
	
	$b_fecha_i = $_REQUEST['b_fecha_i'];
	$b_fecha_f = $_REQUEST['b_fecha_f'];
	$id_material = $_REQUEST['id_material'];
	
	
	$fecha_f = date("n - Y",$b_fecha_i);
		
	$datacreator = array (
                    'Title'=>'Listado de cursos que ha impartido el monitor '.$nombre_monitor,
                    'Author'=>'Mariano Mart�n Bugar�n',
                    'Subject'=>'Club Deportivo Sevilla',
                    
						);

	$pdf->addInfo($datacreator);
	$pdf->ezText("Listado de los ingresos obtenidos por alquiler del producto ".$nombre_material."durante la fecha ".$fecha_f, 30);
	
	$instruccion = "select * from material where ID_MAT like '".$id_material."'";
	
	$consulta = mysql_query($instruccion, $conexion);
	
	$resul = mysql_fetch_array($consulta);
	
	$nombre_material = $resul['NOMBRE_MAT'];
			
	$instruccion1="SELECT * FROM socio,material,historial WHERE socio.ID_SO=historial.id_so and material.ID_MAT=historial.id_mat and historial.id_mat=$id_material and ((fecha_inicio BETWEEN '$b_fecha_i' and '$b_fecha_f') or (fecha_fin  BETWEEN '$b_fecha_i' and '$b_fecha_f'))";
		
	$cons=mysql_query($instruccion1,$conexion)
		or die("Fallo en Consulta");
	$num=mysql_num_rows($cons);
	for($i=0;$i<$num;$i++)
	{
		$datatmp=mysql_fetch_array($cons); 
		$socio = "".$datatmp['NOMBRE_SO']." ".$datatmp['APELLIDOS_SO']."";
		$fecha_i = date("d/n/Y",$datatmp['fecha_inicio']);
		$fecha_f = date("d/n/Y",$datatmp['fecha_fin']);
		$data[] = array_merge($datatmp, array('num'=>$i+1), array('fecha_inicio'=>$fecha_i), array('fecha_fin'=>$fecha_f), array('socio'=>$socio));
		
		//$data[] = mysql_fetch_array($cons);
	}
	$titles = array(  
		'num'=>'<b>Num</b>', 
		'socio'=>'<b>Cliente</b>', 
		'DNI_SO'=>'<b>DNI Cliente</b>',
		'fecha_inicio'=>'<b>Fecha Inicio</b>', 
		'fecha_fin'=>'<b>Fecha Final</b>', 
		'cantidad'=>'<b>Cantidad</b>', 
		'importe'=>'<b>Importe(�)</b>',   
	);
	$options = array(
                'shadeCol'=>array(0.9,0.9,0.9),
                'xOrientation'=>'center',
                'width'=>500
    );
	$pdf->ezText("\n\n\n", 10);
	$pdf->ezTable($data,$titles,'',$options );
	$pdf->ezText("\n\n\n",10);
	$pdf->ezText("<b>Total Alquileres:</b> ".$num,10);
	$pdf->ezText("<b>Fecha:</b> ".date("d/m/Y"),10);
	$pdf->ezText("<b>Hora:</b> ".date("H:i:s")."\n\n",10);
	$pdf->ezStream();
?>


	
