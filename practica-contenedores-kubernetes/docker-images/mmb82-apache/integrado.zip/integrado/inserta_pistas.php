<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
							<?php 
								if($usuario=="")
								{
									print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
									print ("<div class='margen'>&nbsp;</div>");
									print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
								}	
							else
							{
							//Con esto llamamos al archivo donde tenemos las funciones
							
								$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
								$borrar=(isset($_REQUEST['borrar'])) ? $_REQUEST['borrar'] : false;
								$nombre=(isset($_REQUEST['nombre'])) ? $_REQUEST['nombre'] : false;
								$ancho=(isset($_REQUEST['ancho'])) ? $_REQUEST['ancho'] : false;
								$largo=(isset($_REQUEST['largo'])) ? $_REQUEST['largo'] : false;
								$error=false;
							
								if (isset($enviar))//Comprobamos si se no se han introducido los datos en el formulario
								{
									//Comprobamos si el nombre está vacío
									if (trim($nombre)== "")
									{
										$errores["nombre"]="Introduzca el nombre de la pista";
										$error=true;
									}
									else
									{
										$errores["nombre"]="";
									}
									
									//Comprobamos si los ancho está vacíos y correcto
									if (trim($ancho)== "")
									{
										$errores["ancho"]="Introduzca el ancho de la pista";
										$error=true;
									}
									else if (!preg_match('/^[0-9]{2}$/', $ancho))
									{
										$errores["ancho"]="Introduzcar bien el largo de la pista";
										$error=true;
									}else
									{
										$errores["ancho"]="";
									}
									
									//Comprobamos si el largo vacío y correcto
									if(trim ($largo)=="")
									{
										$errores["largo"]="Introduzca el largo de la pisa";
										$error=true;
									}
									else if (!preg_match('/^[0-9]{2}$/', $largo))
									{
										$errores["largo"]="Introduzcar bien el largo de la pista";
										$error=true;
									}
									else
									{
										$errores["largo"]="";
									}
							
								}
											
								if($error==false)
								{
									// Conectar con el servidor de base de datos
									//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
										or die ("No se puede conectar con el servidor");
									
									//comprobamos si el nombre está ya registrado
										$inst_busqueda = "select * from pista where NOMBRE_PISTA='$nombre'";
										$busqueda = mysqli_query ($conexion,$inst_busqueda)
			         						or die ("Fallo en la consulta");
			         					$res_busqueda = mysqli_num_rows ($busqueda);
			         					if($res_busqueda!=0)
			         					{
			         						$errores["nombre"]="Pista guardada.";
											$error=true;
			         					}
			         					else
										{
											$errores["nombre"]="";
										}
																				
									//cerramos la BD
										$cerrar=mysqli_close($conexion);
								}
							}
									
								//listamos el contenido de las variables en la misma página
								//Si se han introducido los datos se muestran
								
								if (isset($enviar) && $error==false)
								{
									// Conectar con el servidor de base de datos
									
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
										or die ("No se puede conectar con el servidor");
											
																		
									//código para introducir el usuario en la BD
										$instruccion = "insert into `pista`(`NOMBRE_PISTA`,`ANCHO`,`LARGO`) values ('$nombre','$ancho','$largo');";
											
															
									//realizamos la conexión a la bd y ejecutamos la instrucción
										$consulta=mysqli_query($conexion,$instruccion)
											or die("Fallo en la instrucción");
											
									//cerramos la BD
										$cerrar=mysqli_close($conexion);
									
									print("<h1>Detalles de la pista</h1>");
									print("<table id='detalle'>");  
						         	print ("<tr><td><b>Nombre: </b>". $nombre ."</td></tr>");  
									print ("<tr><td><b>Ancho: </b>". $ancho ."</td></tr>");
									print ("<tr><td><b>Largo: </b>". $largo ."</td></tr>");
									print("</table>"); 
								}
								else
								{
						
								?>
								<!-- Estructura de nuestro formulario y envío de los datos a las variables junto con la llamada a la comprobaci�n de errores -->
								
								<h2>Insertar Pista.</h2>
								
								<form action="inserta_pistas.php" method="post" enctype="multipart/form-data">
									<fieldset>
										<legend>Datos de pista</legend>
										<table class="margen2">
											<tr>	
												<td>Nombre: </td>
												<td>
													<input type="text" name="nombre" size="30" maxlength="30" value="<?php print $nombre;?>">
													<?php 
														if (trim($errores["nombre"])!= "")
														{
															print ("<span class='error'>" . $errores["nombre"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Ancho: </td>
												<td>
													<input type="text" name="ancho" size="2" maxlength="2" value="<?php print $ancho;?>">
													<?php 
														if (trim($errores["ancho"])!= "")
														{
															print ("<span class='error'>" . $errores["ancho"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Largo: </td>
												<td>
													<input type="text" name="largo" size="2" maxlength="2" value="<?php print $largo;?>">
													<?php 
														if (trim($errores["largo"])!= "")
														{
															print ("<span class='error'>" . $errores["largo"] . "</span>");
														}
													?>
												</td>
											</tr>
										</table>
									</fieldset>
																						
																	
								<div class="margen8"><input type="submit" name="enviar" value="Enviar Datos"><input type="reset" name="borrar" value="Borrar Datos"></div>
							
								</form>
						<?php 
							
						}
						?>
						
			
			
		</div>
		<div align="center">
				<?php include('includes/footerbis.php'); ?>
			</div>
	</body>
</html>
		
