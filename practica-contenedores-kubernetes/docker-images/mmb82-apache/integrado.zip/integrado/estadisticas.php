<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=(isset($_REQUEST['usuario'])) ? $_REQUEST['usuario'] : false;
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
				                	<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
			
							
								
								<h2>Estadísticas</h2>
	
									<form>
										<fieldset>
											<ul type="circle">
												<li><a href="estad1.php">Ingresos obtenidos a partir de actividades y de materiales</a></li>
												<li><a href="estad2.php">Número de monitores y socios</a></li>					
											</ul>
										</fieldset>
									</form>
									
								<h2>Consultas</h2>
	
									<form>
										<fieldset>
											<ul type="circle" >
												<li><a href="consulta1.php">Cursos que ha impartido un monitor.</a></li>	
												<li><a href="consulta2.php">Cursos impartidos durante un mes y año determinado.</a></li>	
											<!--<li><a href="consulta3.php">Número de cursos impartidos por cada monitor.</a></li>-->
											<!--<li><a href="consulta4.php">Número de cursos impartidos por un monitor determinado.</a></li>-->
												<li><a href="consulta5.php">Ingresos obtenidos por alquiler de cada tipo de producto durante
												un determinado mes.</a></li>
												<li><a href="consulta6.php">Misma consulta anterior pero desglosada por modelos.</a></li>
												<li><a href="consulta7.php">Número de alumnos que ha realizado cada curso por fechas: tanto por
												días como por meses.</a></li>
											<!--<li><a href="consulta8.php">Nombre de los monitores que han impartido cursos de p�del a gente que
												ha alquilado pala de pádel.</a></li>-->
											<!--<li><a href="consulta9.php">Número de cursos que ha impartido la escuela en cada pista,
												mostrando el nombre de la pista y su longitud.</a></li>	>-->		

											</ul>
										</fieldset>
									</form>
								
							
							</div>
				        </td>
				  	</tr>
	           </table>
	           <div align="center">
					<?php include('includes/footerbis.php'); ?>
				</div>
		</div>
	</body>
</html>