<?php
	//@utor: Mariano Mart�n
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	$usuario=$_SESSION['usuario'];
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<title>Proyecto 11M</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo.jpg" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulo.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
				                	<?php if($login){ 
										print("<tr><td id='bienvenida'><p>Bienvenid@ " . $_SESSION['usuario'] . "</p></td></tr>");
				                	} ?>
									
				                	<tr><td><a href="index.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Presentacion','','imagenes/presentacion_over.png',1)"><img src="imagenes/presentacion.png" alt="Presentacion" name="Presentacion"/></a></td></tr>
				                    <?php if(!$login){ ?>
									<tr><td><a href="login.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Login','','imagenes/login_over.png',1)"><img src="imagenes/login.png" alt="Login" name="Login"  /></a></td></tr>
				   					<tr><td><a href="mostrar_encuesta.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Encuesta','','imagenes/encuesta_over.png',1)"><img src="imagenes/encuesta.png" alt="Encuesta" name="Encuesta" /></a></td></tr>
				   					<tr><td><a href="registro.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Alta','','imagenes/alta_over.png',1)"><img src="imagenes/alta.png" alt="Alta" name="Alta" /></a></td></tr>
									<?php } else { ?>
				                    <tr><td><a href="album.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Album','','imagenes/album_over.png',1)"><img src="imagenes/album.png" alt="Album" name="Album" /></a></td></tr>
				                    <tr><td><a href="agenda.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Agregar','','imagenes/agregar_over.png',1)"><img src="imagenes/agregar.png" alt="Agregar" name="Agregar" /></a></td></tr>
				                    <tr><td><a href="listar.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Listar','','imagenes/listar_over.png',1)"><img src="imagenes/listar.png" alt="Listar" name="Listar" /></a></td></tr>
				                    <tr><td><a href="salir.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Salir','','imagenes/salir_over.png',1)"><img src="imagenes/salir.png" alt="Salir" name="Salir" /></a></td></tr>
				                    <?php } ?>
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
				
					<?PHP
					   $enviar = $_REQUEST['enviar'];
					   if (isset($enviar))
					   {
					
					   /// Conectar con el servidor de base de datos
							//variables para la conexi�n
							$servername = getenv("DB_HOST");
							$database = getenv("DB_NAME");
							$username = getenv("DB_USER");
							$password = getenv("DB_PASSWORD");
						
							$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
					
					   // Obtener votos actuales
					      $instruccion = "select votos1, votos2 from votos";
					      $consulta = mysql_query ($instruccion, $connection)
					         or die ("Fallo en la selecci�n");
					      $resultado = mysql_fetch_array ($consulta);
					
					   // Actualizar votos
					      $votos1 = $resultado["votos1"];
					      $votos2 = $resultado["votos2"];
					      $voto = $_REQUEST['voto'];
					      if ($voto == "si")
					         $votos1 = $votos1 + 1;
					      else if ($voto == "no")
					         $votos2 = $votos2 + 1;
					      $instruccion = "update votos set votos1='$votos1', votos2='$votos2'";
					      $actualizacion = mysql_query ($instruccion, $connection)
					         or die ("Fallo en la modificaci�n");
					
					   // Desconectar
					      mysql_close ($connection);
					
					   // Mostrar mensaje de agradecimiento
					     	print ("<h1>Gracias por participar.</h1>");
							print ("<div class='margen'>&nbsp;</div>");
							print ("<div align='center'><img src='imagenes/estadistica.png' /></div>");
					     	echo "<META HTTP-EQUIV='refresh' CONTENT='3; URL=encuesta-resultados.php'>";
					   }
					   else
					   {
					?>
					
						<center><h1><img src="img/pregunta_encuesta.png"></img></h1></center>
						
						<div class="encuesta">
							<FORM ACTION="mostrar_encuesta.php" METHOD="POST">
							<center>
							<table>
								<tr>
								   <td colspan="2"><h1>� Le ha gustado la web ?</h1></td>
								<tr>
								   <td class="centrar" colspan="2"><img src='imagenes/estadistica2.png' /></td>
								</tr>  
								<tr>
								   <td class="centrar"><INPUT TYPE="RADIO" NAME="voto" VALUE="si" CHECKED>Si</td>
								   <td class="centrar"><INPUT TYPE="RADIO" NAME="voto" VALUE="no">No</td>
								</tr>
								
							</table>
							<center><h1><INPUT TYPE="SUBMIT" NAME="enviar" VALUE="Votar"></h1></center>
							</FORM>
						</div>
						
						
						<center><div class="margen">Para ver los resultado de la encuesta pincha <a href="encuesta-resultados.php"><b>aqu�</b></a></div></center>
								
						
					
					<?PHP
					   }
					?>
				</div>
				            <div id="firma">
				        		<p align="center">&nbsp;<br />Realizado por Mariano Mart�n Bugar�n</p>
				        	</div>
				        </td>
				  	</tr>
	           </table>
		</div>
	</body>
</html>
