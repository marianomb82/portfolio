<?php
	//@utor: Mariano Martín
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es" xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
	<title>Club Deportivo Sevilla</title>
	<link href="css/estilos.css" rel="stylesheet" type="text/css" media="screen" />
	<script language="javascript" type="text/javascript" src="js/precarga.js"></script>
</head>

<body onLoad="MM_preloadImages('imagenes/presentacion_on.png', 'imagenes/tarifa_on.png', 'imagenes/eventos_on.png','imagenes/actividades_on.png', 'imagenes/contacto_on.png', 'imagenes/login_on.png')">
	<div id="global">

		<?php include('includes/header.php'); ?>

        <div id="cuerpo">
			<div id="contenido">
       			<iframe src="https://www.google.com/calendar/embed?src=proyectos.asi.triana%40gmail.com&ctz=Europe/Madrid" style="border: 0" width="650" height="450" frameborder="0" scrolling="no"></iframe>
            </div>
        </div>

		<?php include('includes/footer.php'); ?>

    </div>
</body>
</html>