<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
								<?php 
									if($usuario=="")
									{
										print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
										print ("<div class='margen'>&nbsp;</div>");
										print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
									}	
								else
								{
								
									$id=$_REQUEST['id'];		
									$volver=(isset($_REQUEST['volver'])) ? $_REQUEST['volver'] : false;			
								
									//Nos conectamos el servidor
									//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
											or die ("No se puede conectar con el servidor"); 
										
																	
									$instruccion = "select * from actividad where ID_AC like '".$_REQUEST['id']."'";
									
									//Ejecutamos la instrucción.
									$consulta = mysqli_query ($conexion,$instruccion) or die ("No se ha podido hacer la consulta");
										
									$nfilas = mysqli_num_rows ($consulta);
						      
								if ($nfilas > 0)
						      	{
						        	$resul = mysqli_fetch_array ($consulta);
						        	
						        	// Buscar nombre monitor
						        	$instruccion4 = "select * from monitor where ID_MON like '".$resul['ID_MON']."'";
																
									$consulta4 = mysqli_query($conexion,$instruccion4)
										or die ("No se puede hacer la consulta1");
										
									$resultado4 = mysqli_fetch_array ($consulta4);
									
									//Buscar nombre pista
									$instruccion5 = "select * from pista where ID_PISTA like '".$resul['ID_PISTA']."'";
																
											$consulta5 = mysqli_query($conexion,$instruccion5)
												or die ("No se puede hacer la consulta1");
										
											$resultado5 = mysqli_fetch_array ($consulta5);
									
									
						                      		
						         	print("<h1>Detalles del curso</h1>");
									print("<table id='detalle'>");  
						         	print ("<tr><td><b>Nombre: </b>". $resul['NOMBRE_AC'] ."</td></tr>");  
									print ("<tr><td><b>Descripción: </b>". $resul['DESC_AC'] ."</td></tr>");
									print ("<tr><td><b>Plazas: </b>". $resul['PLAZAS'] ."</td></tr>");
									print ("<tr><td><b>Plazas disp: </b>". $resul['N_PLAZAS_DIS'] ."</td></tr>");
									print ("<tr><td><b>Precio: </b>". $resul['PRECIO_AC'] ."</td></tr>");
									$fecha_i = date("d/n/Y",$resul['FECHA_IN_AC']); 
									print ("<tr><td><b>Fecha Inicio: </b>".$fecha_i."</td></tr>");
									$fecha_f = date("d/n/Y",$resul['FECHA_FIN_AC']); 
									print ("<tr><td><b>Fecha Inicio: </b>".$fecha_f."</td></tr>"); 
									print ("<tr><td><b>Monitor: </b>".$resultado4['NOMBRE_MON']."</td></tr>");
									print ("<tr><td><b>Pista: </b>". $resultado5['NOMBRE_PISTA'] ."</td></tr>");
									if($resul['FOTO_AC']!="")
										print ("<tr><td><a href=".$resul['FOTO_AC']." target=\"_blank\"><center><img src=".$resul['FOTO_AC']." width='150' height='150' title=\"Pinche para ver la fotograf�a\" alt=\"IMAGEN\"></center></a></td></tr>");
							    	print("</table>");
						      	}
							
								// Cerrar conexión
									mysqli_close ($conexion);
								}
								?>
										
							</div>
				       </td>
				  	</tr>
	           </table>
	           <div align="center">
					<?php include('includes/footerbis.php'); ?>
				</div>
		</div>
	</body>
</html>
		