<?php
	//@utor: Mariano Martín
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es" xmlns="http://www.w3.org/1999/xhtml">
<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
	<title>Club Deportivo Sevilla</title>
	<link href="css/estilos.css" rel="stylesheet" type="text/css" media="screen" />
	<script language="javascript" type="text/javascript" src="js/precarga.js"></script>
</head>

<body onLoad="MM_preloadImages('imagenes/presentacion_on.png', 'imagenes/tarifa_on.png', 'imagenes/eventos_on.png','imagenes/actividades_on.png', 'imagenes/contacto_on.png', 'imagenes/login_on.png')">
	<div id="global">

		<?php include('includes/header.php'); ?>

        <div id="cuerpo">
			<div id="contenido">
            	<div id="columna1" align="center">
                	<img src="imagenes/img_servicios.jpg" border="0" alt="" style="margin-top:40px;" />
                </div>
                <div id="columna2">
                	<h2>Actividades</h2>
                	<p>Porque todos somos diferentes y tenemos diferentes objetivos elige el que más se adapte a ti.</p>
                    <ul>
						<li><a href="http://es.wikipedia.org/wiki/Spinning" target="_blank">Spinning</a></li>
						<li><a href="http://es.wikipedia.org/wiki/Aerobic" target="_blank">Aeróbic</a></li>
						<li><a href="http://www.dietas.net/ejercicio/fitness/steps.html" target="_blank">Step</a></li>
						<li><a href="http://www.kempo-contact.es/" target="_blank">Kempo Contact</a></li>
						<li><a href="#" target="_blank">Cardio Kick Box</a></li>
						<li><a href="http://www.dietas.net/ejercicio/fitness/body-pump.html" target="_blank">Body Pump</a></li>
						<li><a href="http://es.wikipedia.org/wiki/Pilates" target="_blank">Pilates</a></li>
						<li><a href="http://es.wikipedia.org/wiki/Salsa_(baile)" target="_blank">Salsa</a></li>
                    </ul>
					<p>Nuestro horario es:<br />
						Lunes a Viernes de 06:30 h. a 23:00 h. ininterrumpidamente. <br />
						Sábados de 10:00 h. a 14:00 h. y de 17:00 h. a 19:00 h. <br />
						Domingos de 10:00 h. a 14:00 h.</p> 
                </div>
            </div>
        </div>

		<?php include('includes/footer.php'); ?>

    </div>
</body>
</html>