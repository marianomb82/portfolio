<?php
	//@utor: Mariano Mart�n
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
	include ("lib/funciones.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
							<?php 
								if($usuario=="")
								{
									print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
									print ("<div class='margen'>&nbsp;</div>");
									print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
								}	
							else
							{
														
								$enviar=$_REQUEST['enviar'];
								$multa=0;
								$id_material=$_REQUEST['id_material'];
								$cantidad=$_REQUEST['cantidad'];
								$dni=$_REQUEST['dni'];
								$dia_i =$_REQUEST['dia_i'];
								$mes_i =$_REQUEST['mes_i'];
								$ano_i =$_REQUEST['ano_i'];
								$dia_f =$_REQUEST['dia_f'];
								$mes_f =$_REQUEST['mes_f'];
								$ano_f =$_REQUEST['ano_f'];
								$devuelto=$_REQUEST['devuelto'];
												
								if (isset($enviar))//Comprobamos si se no se han introducido los datos en el formulario
								{
									//Comprobamos si el dni est� vac�o
									if (trim($dni)== "")
									{
										$errores["dni"]="Introduzca el dni";
										$error=true;
									}
									else
									{
										$errores["dni"]="";
									}
									
									//Conprobamos el cantidad
									if(is_numeric($cantidad))
									{
										if($cantidad>0)
										{
											if(!ctype_digit($cantidad))
											{
												$error=true;
							      				$errores["cantidad"]="�Debe de introducir un n�mero entero!";
											}
															
										}
										else
										{
											$error=true;
							      			$errores["cantidad"]="�Debe de introducir un n�mero positivo!";
										}
									}
									else
									{
										$error=true;
							      		$errores["cantidad"]="�Debe de introducir un n�mero!";
									}
									
									//Comprobamos si el DNI est� vac�o y correcto
									if(trim ($dni)=="")
									{
										$errores["dni"]="Introduzca el DNI";
										$error=true;
									}
									else if (!preg_match('/^[0-9]{8}[A-Z,a-z]{1}$/', $dni))
									{
										$errores["dni"]="Introduzca bien el DNI, XXXXXXXXA";
										$error=true;
									}
									else
									{
										$errores["dni"]="";
									}
									
									if(!checkdate($mes_i, $dia_i, $ano_i))
									{
										$error=true;
										$errores["fecha_i"]="�Fecha Incorrecta!";
									}
									
									if(!checkdate($mes_f, $dia_f, $ano_f))
									{
										$error=true;
										$errores["fecha_f"]="�Fecha Incorrecta!";
									}
								
											
								if($error==false)
								{
									$fecha_inicial = gmmktime(0,0,0,$mes_i,$dia_i,$ano_i);
									$fecha_final = gmmktime(0,0,0,$mes_f,$dia_f,$ano_f);
										
									$anio = date("Y");
									$dia = date("d");
									$mes = date("n");
		
									$fecha_hoy = gmmktime(0,0,0,$mes,$dia,$anio);
		
									if($fecha_inicial < $fecha_hoy)
									{
										$error = true;
										$errores["fecha_i"] = "�No puedes elegir una fecha inferior a hoy!";
									}
										if($error==false)
										{
											if($fecha_i>$fecha_f)
											{
												$error=true;
									      		$errores["fecha_f"]="�La fecha final debe ser superior!";
											}
										}
										$dias_importe = calculo_dia($dia_i, $mes_i, $ano_i, $dia_f, $mes_f, $ano_f);
										comprobar_dni($dni, $errores, $error, $var="dni", $id_socio);
										comprobar_cantidad($cantidad, $errores, $error, $var="cantidad", $id_material);
									}
																	
								}
							}
								if(isset($enviar)  && $error==false)
								{
									
									// Conectar con el servidor de base de datos
							//variables para la conexi�n
							$servername = getenv("DB_HOST");
							$database = getenv("DB_NAME");
							$username = getenv("DB_USER");
							$password = getenv("DB_PASSWORD");
						
							$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
									
									$instruccion3 = "select * from material where ID_MAT like '".$id_material."'";
															
									$consulta3 = mysql_query ($instruccion3, $conexion) or die ("No se ha podido hacer la consulta1");
									
									$resultado3 = mysql_fetch_array ($consulta3);
									
									$importe = $dias_importe * $resultado3['PRECIO_MAT'] * $cantidad;
																	
										
									//Creamos una instrucci�n para introducir el evento en la base de datos. 
									$instruccion = "INSERT INTO `alquila` (`ID_MAT`, `ID_SO`, `FECHA_IN`, `CANTIDAD`, `FECHA_FIN`, `IMPORTE`, `DEVUELTO`, `MULTA`) VALUES ('$id_material', '$id_socio', '$fecha_inicial', '$cantidad', '$fecha_final', '$importe', '$devuelto', '$multa');";
									
									//Ejecutamos la instrucci�n.
									$consulta = mysql_query ($instruccion, $conexion) or die ("No se ha podido hacer la consulta2");
										
									$num = mysql_insert_id($conexion);
									
									$disponible = $resultado3['EN_ALMACEN'] - $cantidad;
									
									$instruccion2 = "update material set EN_ALMACEN='".$disponible."' where ID_MAT like '".$id_material."'";
									
									$consulta = mysql_query ($instruccion2, $conexion) or die ("No se ha podido hacer la consulta3");
									
									//Cerramos la Base de datos
									$close = mysql_close ($conexion);
								
									print("<h1>Detalles del alquiler</h1>");
									print("<table id='detalle'>");  
						         	print ("<tr><td><b>Nombre material: </b>". $nombre ."</td></tr>");  
									print ("<tr><td><b>DNI: </b>". $dni ."</td></tr>");
									print ("<tr><td><b>Cantidad: </b>". $cantidad ."</td></tr>");
									print ("<tr><td><b>Fecha inicio: </b>".$dia_i."/".$mes_i."/".$ano_i."</td></tr>");
									$fecha_f = date("d/n/Y",$fecha_final); 
									print ("<tr><td><b>Fecha fin: </b>".$fecha_f."</td></tr>");
									print ("<tr><td><b>Importe: </b>". $importe ."</td></tr>");
									if($completo!="")
										print ("<tr><td><a href=".$completo." target=\"_blank\"><center><img src=".$completo." width='150' height='150' title=\"Pinche para ver la fotograf�a\" alt=\"IMAGEN\"></center></a></td></tr>");
							    	print("</table>"); 
							    	
							    	echo "<META HTTP-EQUIV='refresh' CONTENT='4; URL=alquiler.php'>";
								}
								else
								{
						
								?>
								<!-- Estructura de nuestro formulario y env�o de los datos a las variables junto con la llamada a la comprobaci�n de errores -->
								
								<h2>Insertar Alquiler.</h2>
								
								<form action="inserta_alquiler.php" method="post" enctype="multipart/form-data">
									<fieldset>
										<legend>Datos de alquiler</legend>
										<table class="margen2">
											<tr>	
												<td>Nombre material: </td>
												<td>
													<select name="id_material">
														<?php 
															$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
															$nfilas = mysql_num_rows ($consulta);
																													
															if ($nfilas > 0)
															{
																for ($i=0; $i<$nfilas; $i++)
																{
																	$resultado = mysql_fetch_array ($consulta);
																	print "<option value='".$resultado['ID_MAT']."'>".$resultado['NOMBRE_MAT']."";
																}
															}
															else
															{
																print "<option value='Vacio'>No hay Materiales para alquilar";
																$error=true;
													      		$errores["material"]="�No hay Materiales para alquilar!";
															}
														?>
													</select>
												</td>
											</tr>
											<tr>	
												<td>DNI: </td>
												<td>
													<input type="text" name="dni" size="9" maxlength="9" value="<?php print $dni;?>">
													<?php 
														if (trim($errores["dni"])!= "")
														{
															print ("<span class='error'>" . $errores["dni"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Cantidad: </td>
												<td>
													<input type="text" name="cantidad" size="2" maxlength="2" value="<?php print $cantidad;?>">
													<?php 
														if (trim($errores["cantidad"])!= "")
														{
															print ("<span class='error'>" . $errores["cantidad"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Fecha Inicio: </td>
												<td>
													<select name="dia_i">
														<?php 
															for ($i=1;$i<32;$i++)
															{											
																$a = date("d");
																
																if($i<10)
																{
																	$i="0".$i;
																}
																
																if ($i == $a)
																{
																	print "<option value='".$i."' selected>".$i."";
																}
																else
																{
																	print "<option value='".$i."'>".$i."";
																}										
															}
														?>
													</select>
													<select name="mes_i">
														<?php 
															$meses="Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre";
															$num = explode(",", $meses);
															for ($i=0;$i<12;$i++)
															{
																$b=$i+1;
																$a = date("n");
																
																if ($b==$a)
																{
																	print "<option value='".$b."' selected>".$num[$i]."";
																}
																else
																{
																	print "<option value='".$b."'>".$num[$i]."";
																}
																
															}
														?>
													</select>
													<select name="ano_i">
														<?php 
															$a = date("Y");
															
															$b=$a+6;
															for ($i=$a;$i<$b;$i++)
															{
																if($a==$i)
																{
																	print "<option value='".$i."' selected>".$i."";
																}
																else
																{
																	print "<option value='".$i."'>".$i."";
																}
																
															}
														?>
													</select>
													<?php 
														if (trim($errores["fecha_i"])!= "")
														{
															print ("<span class='error'>" . $errores["fecha_i"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Fecha Fin: </td>
												<td>
													<select name="dia_f">
														<?php 
															for ($i=1;$i<32;$i++)
															{											
																$a = date("d");
																
																if($i<10)
																{
																	$i="0".$i;
																}
																
																if ($i == $a)
																{
																	print "<option value='".$i."' selected>".$i."";
																}
																else
																{
																	print "<option value='".$i."'>".$i."";
																}										
															}
														?>
													</select>
													<select name="mes_f">
														<?php 
															$meses="Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre";
															$num = explode(",", $meses);
															for ($i=0;$i<12;$i++)
															{
																$b=$i+1;
																$a = date("n");
																
																if ($b==$a)
																{
																	print "<option value='".$b."' selected>".$num[$i]."";
																}
																else
																{
																	print "<option value='".$b."'>".$num[$i]."";
																}
															}
														?>
													</select>
													<select name="ano_f">
														<?php 
															$a = date("Y");
															
															$b=$a+6;
															for ($i=$a;$i<$b;$i++)
															{
																if($a==$i)
																{
																	print "<option value='".$i."' selected>".$i."";
																}
																else
																{
																	print "<option value='".$i."'>".$i."";
																}
															}
														?>
													</select>
													<?php 
														if (trim($errores["fecha_f"])!= "")
														{
															print ("<span class='error'>" . $errores["fecha_f"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Devuelto: </td>
												<td>
													<select name="devuelto">
														<option value="No" selected>No</option>
														<option value="Si">Si</option>
													</select>
												</td>
											</tr>
										</table>
									</fieldset>
								<div class="margen8"><input type="submit" name="enviar" value="Enviar Datos"><input type="reset" name="borrar" value="Borrar Datos"></div>
							</form>
						<?php 
							
						}
					?>
			</div>
		<div align="center">
			<?php include('includes/footerbis.php'); ?>
		</div>
	</body>
</html>
		
