<?php
	//@utor: Mariano Mart�n
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	    
	    
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
					<?php 
						if($usuario=="")
						{
							print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
							print ("<div class='margen'>&nbsp;</div>");
							print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
						}
						else
						{
							$si=$_REQUEST['si'];
							$no=$_REQUEST['no'];
							
							// Conectar con el servidor de base de datos
							//variables para la conexi�n
							$servername = getenv("DB_HOST");
							$database = getenv("DB_NAME");
							$username = getenv("DB_USER");
							$password = getenv("DB_PASSWORD");
						
							$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
							
					         if(isset($si))
					         {
								
					         	//Nos conectamos el servidor
									$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
										
									$instruccion = "select * from alquila where ID_AL like '".$_REQUEST['id']."'";
									
									//Ejecutamos la instrucci�n.
									$consulta = mysql_query ($instruccion, $conexion) or die ("No se ha podido hacer la consulta");
										
									$nfilas = mysql_num_rows ($consulta);

						        	$resul = mysql_fetch_array ($consulta);
						        	
						        	$id_material = $resul['ID_MAT'];
									$cantidad = $resul['CANTIDAD'];
					         	
					         		$instruccion2 = "update material set EN_ALMACEN=EN_ALMACEN+$cantidad where ID_MAT like '".$id_material."'";
					         	
					         		$consulta = mysql_query ($instruccion2, $conexion) or die ("No se ha podido hacer la consulta");
					         	
						         	$fot=$_REQUEST['fot'];
									$inst="delete from alquila where ID_AL='".$_REQUEST['id']."'";
									$cons=mysql_query($inst,$conexion)
										or die("<p class='error' align='center'><span class='error'>Fallo al borrar el alquiler</span></p>");
						         	if($fot!="")
									{
									  unlink($fot);
									}
									mysql_close($conexion);
									
									print ("<h1>Borrando alquiler ...</h1>");
									print ("<div class='margen'>&nbsp;</div>");
									print ("<div align='center'><img src='imagenes/borrado.png' /></div>");
									
									echo "<META HTTP-EQUIV='refresh' CONTENT='4; URL=contratar.php'>";
							}
							else
							{		
									$instruccion9 = "select * from alquila, material, socio where alquila.ID_MAT=material.ID_MAT and alquila.ID_SO=socio.ID_SO and ID_AL like '".$_REQUEST['id']."'";
									
									$consulta9 = mysql_query($instruccion9, $conexion) or die ("No se puede hacer la consulta9");
									
									$resultado9 = mysql_fetch_array ($consulta9);
														
									print("<h1>Detalles del alquiler</h1>");
									print("<table id='detalle'>");  
						         	
						         	print ("<tr><td><b>Nombre: </b>". $resultado9['NOMBRE_MAT'] ."</td></tr>");  
									print ("<tr><td><b>DNI: </b>". $resultado9['DNI_SO'] ."</td></tr>");
									print ("<tr><td><b>Cantidad: </b>". $resultado9['CANTIDAD'] ."</td></tr>");
									print ("<tr><td><b>Importe: </b>". $resultado9['IMPORTE'] ."</td></tr>");
									$fecha_i = date("d/n/Y",$resultado9['FECHA_IN']); 
									print ("<tr><td><b>Fecha Inicio: </b>".$fecha_i."</td></tr>");
									$fecha_f = date("d/n/Y",$resultado9['FECHA_FIN']); 
									print ("<tr><td><b>Fecha Fin: </b>".$fecha_f."</td></tr>"); 
									if($resultado9['MULTA']!=0)
										print ("<tr><td><b>Multa: </b>".$resultado9['MULTA']."</td></tr>");
							    	print("</table>");
							
									print ("<h3 align='center'>�Desea eliminar este alquiler?</h3>");
									mysql_close($conexion);
							
						     
						?>
						<center><table>
							<tr><td>
									<form action="borrar_contratar.php?id=<?php print $_REQUEST['id'];?>" method="post">
										<input type="submit" name="si" value="SI">
									</form>
									</td><td>
									<form action="contratar.php" method="post">
										<input type="submit" name="no" value="NO, volver al listado">
									</form>
							</td></tr>		
						</table></center>
					<?php 
							}
						}
					?>
				</div>
				           
				        </td>
				  	</tr>
	           </table>
	           <div align="center">
					<?php include('includes/footerbis.php'); ?>
				</div>
		</div>
	</body>
</html>
		</div>
	</body>
</html>
