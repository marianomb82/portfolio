            <img src="imagenes/cuerpo_down.png" alt="" />
        <div id="pie">
        	<script type="text/javascript" src="js/jquery.min.js"></script>
			<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
		  	<script type="text/javascript" src="js/sexylightbox.v2.3.jquery.min.js"></script>
           	<script type="text/javascript">$(document).ready(function(){ SexyLightbox.initialize({color:'white', dir: 'imagenes/lightbox'}); });</script>

          	<div id="firma">
				<p align="center">&nbsp;<br />Realizado por Mariano Martín Bugarín</p>
			</div>
            <p><img src="imagenes/valid-xhtml10.png" alt="Valid XHTML 1.0 Transitional" />&nbsp;<img src="imagenes/vcss.gif" alt="Valid CSS" /></p>
            <div class="margen">Si quiere ponerse en contacto con nosotros pulse <a href="contacto.php"><b>aquí</b></a>.</div>
        </div>


					      
				            