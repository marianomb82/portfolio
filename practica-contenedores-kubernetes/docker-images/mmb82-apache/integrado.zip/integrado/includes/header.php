    	<div id="cabecera">
        	<p style="font-weight:bold;">
        		<img src="imagenes/logo.png" width="150px" height="120px" alt="Logo Club Deportivo Sevilla"/><img src="imagenes/titulo.png" width="400px" height="20px" alt="Logo Club Deportivo Sevilla"/>
        	</p>
        	<table cellpadding="0" cellspacing="0" border="0" align="center">
	               
				<tr>
					<td><a href="index.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Presentacion','','imagenes/presentacion_on.png',1)"><img src="imagenes/presentacion_off.png" alt="Presentacion" name="Presentacion"/></a></td>
					<td><a href="tarifas.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Precios','','imagenes/tarifa_on.png',1)"><img src="imagenes/tarifa_off.png" alt="Precios" name="Precios"  /></a></td>
				   	<td><a href="eventos.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Eventos','','imagenes/eventos_on.png',1)"><img src="imagenes/eventos_off.png" alt="Eventos" name="Eventos"  /></a></td>
				   	<td><a href="actividades.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Actividades','','imagenes/actividades_on.png',1)"><img src="imagenes/actividades_off.png" alt="Actividades" name="Actividades"  /></a></td>
				   	<td><a href="contacto.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Contacto','','imagenes/contacto_on.png',1)"><img src="imagenes/contacto_off.png" alt="Contacto" name="Contacto"  /></a></td>
				   	<td><a href="login.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Login','','imagenes/login_on.png',1)"><img src="imagenes/login_off.png" alt="Login" name="Login"  /></a></td>
				</tr>
				   	
			</table>
        </div>
        <img src="imagenes/cuerpo_up.png" alt="" />
