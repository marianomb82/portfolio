<?php if($login){ 
	print("<tr><td id='bienvenida'><p>Bienvenid@ " . $_SESSION['usuario'] . "</p></td></tr>");
                } ?>
<?php if($login){?>
	<?php if($_SESSION['tipo']=="admin")
	{
		print("<tr><td><a href=\"gestor.php\" onMouseOut=\"MM_swapImgRestore()\" onMouseOver=\"MM_swapImage('Gestores','','imagenes/gestores_over.png',1)\" /><img src=\"imagenes/gestores.png\" alt=\"Gestores\" name=\"Gestores\" /></a></td></tr>");
	}
	?>
	<tr><td><a href="monitores.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Monitores','','imagenes/monitores_over.png',1)"><img src="imagenes/monitores.png" alt="Monitores" name="Monitores" /></a></td></tr>
	<tr><td><a href="pistas.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Pistas','','imagenes/pista_over.png',1)"><img src="imagenes/pista.png" alt="Pistas" name="Pistas" /></a></td></tr>
	<tr><td><a href="clientes.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Clientes','','imagenes/clientes_over.png',1)"><img src="imagenes/clientes.png" alt="Clientes" name="Clientes" /></a></td></tr>
	<tr><td><a href="material.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Material','','imagenes/material_over.png',1)"><img src="imagenes/material.png" alt="Material" name="Material" /></a></td></tr>
	<tr><td><a href="cursos.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Cursos','','imagenes/cursos_over.png',1)"><img src="imagenes/cursos.png" alt="Cursos" name="Cursos" /></a></td></tr>
	<tr><td><a href="estadisticas.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Estadisticas','','imagenes/estad_over.png',1)"><img src="imagenes/estad.png" alt="Estadisticas" name="Estadisticas" /></a></td></tr>
	<tr><td><a href="alquiler.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Alquiler','','imagenes/alquiler_over.png',1)"><img src="imagenes/alquiler.png" alt="Alquiler" name="Alquiler" /></a></td></tr>
	<tr><td><a href="contratar.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Contratar','','imagenes/contratacion_over.png',1)"><img src="imagenes/contratacion.png" alt="Contratar" name="Contratar" /></a></td></tr>
	<tr><td><a href="salir.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Salir','','imagenes/salir_over.png',1)"><img src="imagenes/salir.png" alt="Salir" name="Salir" /></a></td></tr>
<?php } ?>