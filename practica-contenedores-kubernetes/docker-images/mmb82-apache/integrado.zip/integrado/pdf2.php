<?php
	//@utor: Mariano Mart�n
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	


	include ('pdf/class.ezpdf.php');
	
	// Conectar con el servidor de base de datos
							//variables para la conexi�n
							$servername = getenv("DB_HOST");
							$database = getenv("DB_NAME");
							$username = getenv("DB_USER");
							$password = getenv("DB_PASSWORD");
						
							$conexion = mysqli_connect ($servername, $username, $password,$database)
							or die ("No se puede conectar con el servidor");
	
	
	$pdf =& new Cezpdf('a4');
	$pdf->selectFont('pdf/fonts/Helvetica.afm');
	$pdf->ezSetCmMargins(1,1,1.5,1.5);
	
	$b_fecha_i = $_REQUEST['b_fecha_i'];
	$b_fecha_f = $_REQUEST['b_fecha_f'];
	
	$fecha_f = date("n - Y",$b_fecha_i);
		
	$datacreator = array (
                    'Title'=>'Listado de cursos que ha impartido el monitor '.$nombre_monitor,
                    'Author'=>'Mariano Mart�n Bugar�n',
                    'Subject'=>'Club Deportivo Sevilla',
                    
						);

	$pdf->addInfo($datacreator);
	$pdf->ezText("Cursos impartidos durante el".$fecha_f, 30);
	
	$instruccion1 = "select * from actividad where ";
					
	$a ="(actividad.FECHA_IN_AC<=$b_fecha_f && (actividad.FECHA_FIN_AC>=$b_fecha_i && actividad.FECHA_FIN_AC<=$b_fecha_f))";
	
	$b = " || ((actividad.FECHA_IN_AC>=$b_fecha_i && actividad.FECHA_IN_AC<=$b_fecha_f) && actividad.FECHA_FIN_AC>=$b_fecha_f)";
	
	$c = " || (actividad.FECHA_IN_AC<=$b_fecha_i and actividad.FECHA_FIN_AC>=$b_fecha_f) order by FECHA_FIN_AC ASC, FECHA_IN_AC ASC";
		
	$instr=$instruccion1.$a.$b.$c;
		
	$cons=mysql_query($instr,$conexion)
		or die("Fallo en Consulta");
	$num=mysql_num_rows($cons);
	for($i=0;$i<$num;$i++)
	{
		$datatmp=mysql_fetch_array($cons);
		
		$instruccion2 = "select * from monitor where ID_MON like '".$datatmp['ID_MON']."'";
		$consulta2 = mysql_query($instruccion2, $conexion);
		$resultado2 = mysql_fetch_array($consulta2);
		$nombre = $resultado2['NOMBRE_MON']." ".$resultado2['APELLIDOS_MON']."";
		
		$instruccion2 = "select * from pista where ID_PISTA like '".$datatmp['ID_PISTA']."'";
		$consulta2 = mysql_query($instruccion2, $conexion);
		$resultado2 = mysql_fetch_array($consulta2);
		$pista = $resultado2['NOMBRE_PISTA'];
		
		$fecha_i = date("d/n/Y",$datatmp['FECHA_IN_AC']);
		$fecha_f = date("d/n/Y",$datatmp['FECHA_FIN_AC']);
		$data[] = array_merge($datatmp, array('num'=>$i+1), array('nombre'=>$nombre), array('pista'=>$pista), array('FECHA_IN_AC'=>$fecha_i), array('FECHA_FIN_AC'=>$fecha_f));
		
		//$data[] = mysql_fetch_array($cons);
	}
	$titles = array(  
		'num'=>'<b>Num</b>', 
		'NOMBRE_AC'=>'<b>Actividad</b>', 
		'FECHA_IN_AC'=>'<b>Fecha Inicio</b>', 
		'FECHA_FIN_AC'=>'<b>Fecha Final</b>', 
		'PLAZAS'=>'<b>Plazas</b>',
		'PRECIO_AC'=>'<b>Precio (�)</b>', 
		'nombre'=>'<b>Monitor</b>', 
		'pista'=>'<b>Pista</b>',   
	);
	$options = array(
                'shadeCol'=>array(0.9,0.9,0.9),
                'xOrientation'=>'center',
                'width'=>500
    );
	$pdf->ezText("\n\n\n", 10);
	$pdf->ezTable($data,$titles,'',$options );
	$pdf->ezText("\n\n\n",10);
	$pdf->ezText("<b>Total Actividad:</b> ".$num,10);
	$pdf->ezText("<b>Fecha:</b> ".date("d/m/Y"),10);
	$pdf->ezText("<b>Hora:</b> ".date("H:i:s")."\n\n",10);
	$pdf->ezStream();
?>


		
