<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 		
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
							<?php 
								if($usuario=="")
								{
									print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
									print ("<div class='margen'>&nbsp;</div>");
									print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
								}	
							else
							{
							//Con esto llamamos al archivo donde tenemos las funciones
							
								$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
								$borrar=(isset($_REQUEST['borrar'])) ? $_REQUEST['borrar'] : false;
								$nombre=(isset($_REQUEST['nombre'])) ? $_REQUEST['nombre'] : false;
								$marca=(isset($_REQUEST['marca'])) ? $_REQUEST['marca'] : false;
								$modelo=(isset($_REQUEST['modelo'])) ? $_REQUEST['modelo'] : false;
								$stock=(isset($_REQUEST['stock'])) ? $_REQUEST['stock'] : false;
								$precio=(isset($_REQUEST['precio'])) ? $_REQUEST['precio'] : false;
								$completo=(isset($_REQUEST['completo'])) ? $_REQUEST['completo'] : false;
								$fotografia=(isset($_REQUEST['fotografia'])) ? $_REQUEST['fotografia'] : false;
								$tamaño=(isset($_REQUEST['MAX_FILE_SIZE'])) ? $_REQUEST['MAX_FILE_SIZE'] : false;
								$tipo_archivo=(isset($_FILES['fotografia']['type'])) ? $_FILES['fotografia']['type'] : false;
								$error=false;
							
							if (isset($enviar))//Comprobamos si se no se han introducido los datos en el formulario
								{
									//Comprobamos si el nombre está vacío
									if (trim($nombre)== "")
									{
										$errores["nombre"]="Introduzca el nombre del material";
										$error=true;
									}
									else
									{
										$errores["nombre"]="";
									}
									
								//Comprobamos si marca está vacío
									if (trim($marca)== "")
									{
										$errores["marca"]="Introduzca la marca";
										$error=true;
									}
									else
									{
										$errores["marca"]="";
									}
									
								//Comprobamos si modelo está vací0o
									if (trim($modelo)== "")
									{
										$errores["modelo"]="Introduzca el modelo";
										$error=true;
									}
									else
									{
										$errores["modelo"]="";
									}
									
								//Comprobamos el stock
									if (is_numeric($stock))
									{
									    if(ctype_digit($stock))
										{	
											if($stock>1)
											{
												if($stock>20)
												{
													$errores["stock"]="Introduce stock menor de 20";
													$error=true;
												}
											}
											else
											{
												$errores["stock"]="Introduce stock mayor de 0";
												$error=true;
											}
										}
										else
										{
											$errores["stock"]="Introduce un número";
											$error=true;
										}
									}
									else
									{
										$errores["stock"]="Introduce un número";
										$error=true;
									}
									
								//Comprobamos el precio
									if (is_numeric($precio))
									{
									    if(ctype_digit($precio))
										{	
											if($precio>1)
											{
												if($precio>20)
												{
													$errores["precio"]="Introduce precio menor de 20";
													$error=true;
												}
											}
											else
											{
												$errores["precio"]="Introduce precio mayor de 0";
												$error=true;
											}
										}
										else
										{
											$errores["precio"]="Introduce un número";
											$error=true;
										}
									}
									else
									{
										$errores["precio"]="Introduce un número";
										$error=true;
									}
								}
											
								if($error==false)
								{
									// Conectar con el servidor de base de datos
									//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
											or die ("No se puede conectar con el servidor");
									
									//comprobamos si el nombre está ya registrado
										
										$inst_busqueda = "select * from material where MODELO_MAT like '" . $modelo ."' and ID_MAT not like '".$_REQUEST['id']."'";
										$busqueda = mysqli_query ($conexion, $inst_busqueda)
			         						or die ("Fallo en la consulta");
			         					$res_busqueda = mysqli_num_rows ($busqueda);
			         					if($res_busqueda!=0)
			         					{
			         						$errores["modelo"]="Modelo y marca ya introducido.";
											$error=true;
			         					}
			         					else
										{
											$errores["modelo"]="";
										}
																																		
									//cerramos la BD
										$cerrar=mysqli_close($conexion);
								}	
								
								if($error==false)
								{
									//Subir imagen
									if(is_uploaded_file ($_FILES['fotografia']['tmp_name']))
									{
										if($_FILES['fotografia']['error'] == UPLOAD_ERR_FORM_SIZE || $_FILES['fotografia']['error'] == UPLOAD_ERR_INI_SIZE)
										{
											$errores["fotografia"]="Imagen de Tamaño erroneo, debe tener maximo 500Kb";
											$error=true;
										}
										//Comprobacion del tipo de imagen
										else
										{
										if(strpos($tipo_archivo, "gif") || strpos($tipo_archivo, "jpeg") || strpos($tipo_archivo, "jpg") || strpos($tipo_archivo, "png"))
											{
												if(is_uploaded_file($_FILES['fotografia']['tmp_name']))
												{
													$dir="img/";
													$fichero=$usuario."-".$_FILES['fotografia']['name'];
													$completo=$dir.$fichero;
													if(is_file($completo))
													{
														$unico=time();
														$fichero=$usuario."-".$unico."-".$_FILES['fotografia']['name'];
														$completo=$dir.$fichero;
													}
													move_uploaded_file($_FILES['fotografia']['tmp_name'], $completo);
												}
												else
												{
													$errores["fotografia"]="No se ha podido subir el fichero";
													$error=true;
												}
											}
											else
											{
												$errores["fotografia"]="Imagen de tipo erroneo, debe ser JPEG, GIF o PNG";
												$error=true;
											}
										}
									}
								}
									
								//listamos el contenido de las variables en la misma página
								//Si se han introducido los datos se muestran
								
								if (isset($enviar) && $error==false)
								{
									// Conectar con el servidor de base de datos
														
						$conexion = mysqli_connect ($servername, $username, $password,$database)
											or die ("No se puede conectar con el servidor");
									
									$instruccion2 = "update material set NOMBRE_MAT='".$nombre."', MARCA_MAT='".$marca."', MODELO_MAT='".$modelo."', STOCK_MAT='".$stock."', PRECIO_MAT='".$precio."', FOTO_MAT='".$completo."' where ID_MAT like '".$_REQUEST['id']."'";
									
									$consulta = mysqli_query($conexion,$instruccion2) or die ("No se puede hacer la consulta");
										
									print("<h1>Detalles modificados del material</h1>");
									print("<table id='detalle'>");  
						         	print ("<tr><td><b>Nombre: </b>". $nombre ."</td></tr>");  
									print ("<tr><td><b>Marca: </b>". $marca ."</td></tr>");
									print ("<tr><td><b>Modelo: </b>". $modelo ."</td></tr>");
									print ("<tr><td><b>Stock: </b>". $stock ."</td></tr>");
									print ("<tr><td><b>Precio: </b>". $precio ."</td></tr>");
									
									if($completo!="")
										print ("<tr><td><a href=".$completo." target=\"_blank\"><center><img src=".$completo." width='150' height='150' title=\"Pinche para ver la fotograf�a\" alt=\"IMAGEN\"></center></a></td></tr>");
							    	print("</table>"); 
										
										
									echo "<META HTTP-EQUIV='refresh' CONTENT='3; URL=material.php'>";
									
									$close = mysqli_close ($conexion);
									
								}
								else
								{
								// Conectar con el servidor de base de datos
								
						$conexion = mysqli_connect ($servername, $username, $password,$database)
								or die ("No se puede conectar con el servidor");	
									
								$instruccion = "select * from material where ID_MAT like '".$_REQUEST['id']."'";
								
								$consulta = mysqli_query($conexion,$instruccion) or die ("No se puede hacer la consulta");
								
								$resultado = mysqli_fetch_array ($consulta);
												
														
								?>
								<!-- Estructura de nuestro formulario y envío de los datos a las variables junto con la llamada a la comprobaci�n de errores -->
								
								<h2>Modificar Material.</h2>
								
								<form action="modificar_material.php?id=<?php print $_REQUEST['id'] ?>" method="post" enctype="multipart/form-data">
									<fieldset>
										<legend>Datos de material</legend>
										<table class="margen2">
											<tr>	
												<td>Nombre: </td>
												<td>
													<input type="text" name="nombre" size="30" maxlength="30" value="<?php print $resultado['NOMBRE_MAT'];?>">
													<?php 
														if (trim($errores["nombre"])!= "")
														{
															print ("<span class='error'>" . $errores["nombre"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Marca: </td>
												<td>
													<input type="text" name="marca" size="30" maxlength="30" value="<?php print $resultado['MARCA_MAT'];?>">
													<?php 
														if (trim($errores["marca"])!= "")
														{
															print ("<span class='error'>" . $errores["marca"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Modelo: </td>
												<td>
													<input type="text" name="modelo" size="30" maxlength="30" value="<?php print $resultado['MODELO_MAT'];?>">
													<?php 
														if (trim($errores["modelo"])!= "")
														{
															print ("<span class='error'>" . $errores["modelo"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Stock: </td>
												<td>
													<input type="text" name="stock" size="2" maxlength="2" value="<?php print $resultado['STOCK_MAT'];?>">
													<?php 
														if (isset($errores["stock"]) && trim($errores["stock"])!= "")
														{
															print ("<span class='error'>" . $errores["stock"] . "</span>");
														}
													?>
												</td>
											</tr>
											<tr>	
												<td>Precio: </td>
												<td>
													<input type="text" name="precio" size="2" maxlength="2" value="<?php print $resultado['PRECIO_MAT'];?>">
													<?php 
														if (isset($errores["precio"]) && trim($errores["precio"])!= "")
														{
															print ("<span class='error'>" . $errores["precio"] . "</span>");
														}
													?>
												</td>
											</tr>
											
										</table>
									</fieldset>
									
									<fieldset class="margen8">
										<legend>Adjuntar fotografía</legend>
										<table class="margen5">
											<tr>
												<td>
													<input type="hidden" name="MAX_FILE_SIZE" value="102400">
													<input type="file" name="fotografia" size="50">
													<?php 
														if (isset($errores["fotografia"]) && trim($errores["fotografia"])!= "")
														{
															print ("<span class='error'>" . $errores["fotografia"] . "</span>");
														}
													?>
												</td>
											</tr>
										</table>
									</fieldset>													
																	
								<div class="margen8"><input type="submit" name="enviar" value="Enviar Datos"><input type="reset" name="borrar" value="Borrar Datos"></div>
							
								</form>
						<?php 
							}
						}
						?>
						
			
			
		</div>
		<div align="center">
				<?php include('includes/footerbis.php'); ?>
			</div>
	</body>
</html>
		
