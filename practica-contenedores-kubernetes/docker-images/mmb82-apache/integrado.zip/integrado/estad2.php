<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=(isset($_REQUEST['usuario'])) ? $_REQUEST['usuario'] : false;
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
								<?php
								// Conectar con el servidor de base de datos
								//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
								or die ("No se puede conectar con el servidor");
								
								$instruccion = "select * from socio";
								
								$consulta = mysqli_query($conexion,$instruccion) or die ("fallo en consulta");
								
								$nfilas = mysqli_num_rows ($consulta);
								
								$instruccion = "select * from monitor";
								
								$consulta = mysqli_query($conexion,$instruccion) or die ("fallo en consulta");
								
								$nfilas1 = mysqli_num_rows ($consulta);
								
								$sumatorioing=0;
								
								$sumatorioing=$nfilas+$nfilas1;
								
								if($sumatorioing!=0)
								{
					?>
									<center><h2>Número de Monitores y Clientes</h2></center>
									
										<table cellpadding='5'>
				 
												<?php $porcentaje = round(($nfilas/$sumatorioing)*100,2);	?>				
					
												<tr>
													<td><b>Clientes</b></td>
													<td><div><?php for($j=0;$j<=$porcentaje;$j++) echo "<img src='imagenes/raya.png'>";?></div></td>
													<td><?php echo $porcentaje."%"?></td>
												</tr>
												
												<?php $porcentaje = round(($nfilas1/$sumatorioing)*100,2);	?>					
					
												<tr>
													<td><b>Monitores</b></td>
													<td><div><?php for($j=0;$j<=$porcentaje;$j++) echo "<img src='imagenes/raya.png'>";?></div></td>
													<td><?php echo $porcentaje."%"?></td>
												</tr>
												<tr>
													<td>Número de Personas: <?php echo $sumatorioing?></td>
												</tr>
										</table>
									
									
									
					<?php 
									
								}
								else
								{
									print "<center><p>No existen clientes ni monitores></p></center>";
								}
					?>
							</div>
						</td>
					<tr>
				</table>
	        <div align="center">
				<?php include('includes/footerbis.php'); ?>
			</div>
		</div>
	</body>
</html>
							