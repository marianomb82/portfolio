<?php 

		
function show_encuesta($id_ENCUESTA,$proteccion_IP,$pregunta,$opciones)
{ 
	// Colocamos las preguntas y opciones 
	$opciones_para_grabar='';
	foreach($opciones as $key => $value)
	{
		$opciones_para_grabar.=" ".$key ."=". $value .", ";  
	} 

	$encuesta[$id_ENCUESTA]=array($pregunta,$opciones);
	//
	if (!array_key_exists($id_ENCUESTA,$encuesta)) 
		return ('El id de la encuesta no se encuentra disponible'); 
	else 
		$pregunta_de_la_encuesta = array_shift($encuesta[$id_ENCUESTA]); 
		$opciones_de_la_encuesta = array_pop ($encuesta[$id_ENCUESTA]); 
	if(isset($_POST[opcion]))
	{ 
		$ip=$_SERVER['REMOTE_ADDR'];
		$fecha_votacion = date('Y-m-d'); //2006-05-31
		
		/*
		Validamos el voto por ip y fecha de hoy.
		Aqu� se puede hacer la modificaci�n en caso 
		de que el participante no pueda votar mas de una vez por dia.
		*/
		$ssqls=mysql_query('SELECT * FROM encuestas WHERE ip="'.$ip.'"')or die(mysql_error()); 

		if($proteccion_IP && mysql_num_rows($ssqls)>=1)
		{ 
			$html_encuesta='Usted ya hab&iacute;a votado. Gracias';
		}
		else
		{
			$ip=$_SERVER['REMOTE_ADDR'];
			$html_encuesta='Gracias por su voto';
			mysql_query('INSERT INTO encuestas VALUES
			('.$id_ENCUESTA.',"'.$pregunta.'","'.$opciones_para_grabar.'",'.$_POST[opcion].',"'.$ip.'","'.$fecha_votacion.'")')or die(mysql_error()); 
		}		
	} 
	
	$ssql=mysql_query('SELECT * FROM encuestas WHERE id_encuesta="'.$id_ENCUESTA.'"')or die(mysql_error()); 
	$total_votos=mysql_num_rows($ssql); 
	
	// mostramos los resultados. 
	$html_encuesta.='<a name="encuesta" id="encuesta"></a><form action="'.$_SERVER[REQUEST_URI].'#encuesta" method="POST">'; 
	$html_encuesta.= '<b style="color:#055A91">'.$pregunta_de_la_encuesta.'</b>'; 
	///
	$html_encuesta.='<br /><br />';
	$votos_total=0;
	foreach($opciones_de_la_encuesta as $KEY => $OPCION)
	{ 
		$ssql=mysql_query('SELECT * FROM encuestas WHERE id_encuesta="'.$id_ENCUESTA.'" and id_opcion="'.$KEY.'"')or die(mysql_error()); 
		$votos_x_opcion=mysql_num_rows($ssql);
		$votos_total+=$votos_x_opcion;
		$estimar_porcentaje= @round($votos_x_opcion*100/$total_votos,1);	
		$html_encuesta.= '<input name="opcion" type="radio" value="'.$KEY.'"'; 
		if($_POST[opcion]==$KEY && 
			isset($_POST[opcion])){$html_encuesta.='checked'; 
	} 
	$html_encuesta.= '>'.$OPCION.' '.$estimar_porcentaje.'% <br /><strong>Votos: '.$votos_x_opcion.'</strong>
	<hr align="left" color="#055A91" align="left" size=2 width='. $estimar_porcentaje . '>';
	}
	$html_encuesta.='<br /><input type="submit" value="Votar">'; 
	$html_encuesta.='</form>'; 
	return '<b>'.$votos_total.'</b>&nbsp;votos hasta hoy<br />'.$html_encuesta;
	} 
?> 