<?php
	
	
function si_vacio($usuario,&$error, &$erores,$variable)
{
	if(trim($usuario)=="")
	{
		$error=true;
		$errores['$variable']="Introduzca". $variable.".\n";
	}
}

function calculo_dia($dia, $mes, $a�o, $dia1, $mes1, $a�o1)
	{
		//calculo timestam de las dos fechas
		$timestamp1 = mktime(0,0,0,$mes,$dia,$a�o);
		$timestamp2 = mktime(0,0,0,$mes1,$dia1,$a�o1);
		
		//resto a una fecha la otra
		$segundos_diferencia = $timestamp1 - $timestamp2;
		//echo $segundos_diferencia;
		
		//convierto segundos en días
		$dias_diferencia = $segundos_diferencia / (60 * 60 * 24);
		
		//obtengo el valor absoulto de los días (quito el posible signo negativo)
		$dias_diferencia = abs($dias_diferencia);
		
		//quito los decimales a los días de diferencia
		$dias_diferencia = floor($dias_diferencia);
		
		return $dias_diferencia+1;
	}

function comprobar_dni(&$variable, &$errores, &$error, &$var, &$var1)
	{
		$//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
		or die ("No se puede conectar con el servidor");

		//Creamos la consulta para saber cuantas unidades de ese material est�n alquiladas.
		if($var=="dni")
		{
			$instruccion = "select * from socio where DNI_SO like '".$variable."'";
		}
		
		$consulta = mysqli_query ($conexion,$instruccion)
			or die ("Fallo en la consulta");
			
		$nfilas = mysqli_num_rows ($consulta);
		
		if ($nfilas > 0)
		{
			$resultado = mysqli_fetch_array ($consulta);
			
			$var1=$resultado['ID_SO'];
		}
		else
		{
			$error=true;
      		$errores["$var"]="No existe ningun socio con ese dni";
		}
		$close = mysqli_close ($conexion);
	}

	function comprobar_cantidad(&$variable, &$errores, &$error, &$var, &$var1)
	{		
		//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
		or die ("No se puede conectar con el servidor");
								
		//Creamos la consulta para saber cuantas unidades de ese material est�n alquiladas.
		if($var=="cantidad")
		{
			$instruccion = "select * from material where ID_MAT like '".$var1."'";
		
		
			$consulta = mysqli_query ($conexion,$instruccion)
				or die ("Fallo en la consulta");
				
			$nfilas = mysqli_num_rows ($consulta);
			
			if ($nfilas > 0)
			{
				$resultado = mysqli_fetch_array ($consulta);
				
				$var3=$resultado['EN_ALMACEN'];
		
				if($variable>$var3)
				{
					$error=true;
	      			$errores["$var"]="¡Disponemos de $var3 unidades!";
				}	
			}
		}
		$close = mysqli_close ($conexion);
	}
		
function calculodni ($dni, &$errores, &$error)
{
	//Calculamos cuentos caracteres tiene el campo 'DNI'
	$digitos= strlen ($dni);
	//Comprobamos si el numero de caracteres contados coindicen a 9					
	if($digitos == 9)
	{
		//Una vez que sabemos que tiene 9 digitos, metemos en una variable los 8 primeros.
		$numero = substr($dni, 0, 8);
		//Comprobamos que los 8 primeros son n�meros.									
		if (is_numeric($numero))
		{
			//Metemos en una variable el ultimo caracter del campo 'DNI', la letra.
			$let = substr($dni, -1);
			//Creamos una cadena con todas las letras.
			$letra="Q W E R T Y U I O P A S D F G H J K L Z X C V B N M q w e r t y u i o p a s d f g h j k l z x c v b n m";
			//Metemos cada letra en un array.
			$separar = explode(" ",$letra);
			$e=0;
			$sw=0;
  			//Creamos un bucle para que recorra todo el array				
  			while ($e<52 && $sw==0)
  			{
  				//Comparamos cada letra del array con la letra del DNI
  				if ($separar[$e]==$let)
  				{
  					//Ponemos un chivato para avisar que hemos encontrado la letra.
  					$sw=1;
  				}
  				$e=$e+1;
  			}
  			//Si entra en este IF es porque no es una letra.				
  			if ($sw==0)
  			{
  				$errores["dni"]="¡Debes de introducir bien el DNI, XXXXXXXXA!";
				$error=true;
  			}
  			//Sino sabemos que la hemos encontrado.
  			else
  			{
  				$errores["dni"]="";
  			}
  						
		}
		//Nos muestra un error porque no son numeros los 8 primeros digitos.
		else
		{
			$errores["dni"]="¡Debes de introducir bien el DNI, XXXXXXXXA!";
			$error=true;
		}
	}
	//Nos da un erros porque no tiene 9 caracteres el campo 'DNI'
	else
	{
		$errores["dni"]="¡Debes de introducir bien el DNI, XXXXXXXXA!";
		$error=true;
	}
	
	//La funci�n ha sido creada por Juan El�as.
}

function calculopassword ($password, &$errores, &$error)
{
	//Calculamos cuantos digitos tiene el campo 'Contrase�a'
	$digitos= strlen ($password);

	//Comprobamos si el campo 'Contrase�a' tiene 8 digitos
	if($digitos==8)
	{
		//Si es cierto, ahora vemos si es num�rico
		if (is_numeric($password))
		{
			$errores["password"]="";
		}
		//Si no es numerico, nos da un error
		else
		{
			$errores["password"]="¡Debes de introducir 8 n�meros!";
		}
	}
	//Si no tiene 8 digitos, pues da un error.
	else
	{
		$errores["password"]="¡Debes de introducir 8 n�meros!";
	}
		
}

function calculoemial ($email, &$errores, &$error)
{
	$ar="@";
	//Comprobamos que el caracter '@' exista en el campo 'Email'
	if (strrpos($email, $ar))
	{
		//Si existe dividimos la cadena en dos partes.
		$separar = explode($ar,$email);
		
		//Tenemos una variable donde vamos a tener todos los dominios que se puede registrar.
		$domain="gmail.com hotmail.com yahoo.es";

		//Dividimos la s
		$sedomain = explode(" ",$domain);
							
		$cont=0;
		$sw1=0;
							
		while ($cont<3 && $sw1==0)
		{
			if($separar[1]==$sedomain[$cont])
			{
				$sw1=1;
			}
			$cont=$cont+1;
		}
							
		if ($sw1==1)
		{
			$errores["email"]="";
		}
		else
		{
			$errores["email"]="�Introduzca bien el Email, ejemplo@gmail.com!";
		}
	}
	else
	{
		$errores["email"]="�Introduzca bien el Email, ejemplo@gmail.com!";
	}
}

function calculotelefono ($telefono, &$errores, &$error)
{
	$tedigitos= strlen ($telefono);
					
		if($tedigitos==9)
		{
			if (is_numeric($telefono))
			{
				$errores["telefono"]="";
			}
			else
			{
				$errores["telefono"]="¡Debes de introducir 9 digitos!";
			}
		}
			else
		{
			$errores["telefono"]="¡Debes de introducir 9 digitos!";
		}
}

function calculocomentario ($comentario, &$errores, &$error)
{
	$codigitos= strlen ($comentario);
					
	if($codigitos<=120)
	{				
		$errores["comentario"]="";
	}
	else
	{
		$errores["comentario"]="�El comentario puede tener como m�ximo 120 caracteres!";
	}
}

function calculofichero (&$errores, &$error, &$copiarFichero, &$nombreDirectorio, &$nombreFichero)
{
		if ($_FILES['imagen']['error'] == UPLOAD_ERR_FORM_SIZE || $_FILES['imagen']['error'] == UPLOAD_ERR_INI_SIZE )
   		{
      		$errores["error"]="El tama�o de la imagen supera el l�mite permitido";
        	$copiarFichero=false;
        	$error=true;
       
      	}
      	else
      	{
      		$errores["error"]="";
      	}
	
	if (is_uploaded_file ($_FILES['imagen']['tmp_name']))
	{
		$nombreDirectorio = "img/";
        $nombreFichero = $_FILES['imagen']['name'];
         			
    	$nombreCompleto = $nombreDirectorio . $nombreFichero;
         
    	if (is_file($nombreCompleto))
        {
            $id = time();
            $nombreFichero = $id . "-" . $nombreFichero;
        }
         			 
         	$copiarFichero = true;
         	//$errores["false"]=""; 	
	
		
      			
		if ($_FILES['imagen']['type'] != "image/gif" && $_FILES['imagen']['type'] != "image/jpg")
    	{
      		$errores["type"]="No tiene la imagen el formato GIF o JPEG";
        	$copiarFichero=false;
        	$errorfichero=true;
        	$error=true;
    	}
		else
    	{
      		$errores["type"]="";
    	}
	}
	
		
	
	
	/*else
	{
		$errores["false"]="¡Debes de introducir una imagen!";
		$copiarFichero=false;
	}*/
							
				
	
}
?>
<?php 
	function comprobar_fecha_hoy ($fecha_inicial, &$errores, &$error, $var="fecha_i")
	{
		$anio = date("Y");
		$dia = date("d");
		$mes = date("n");
		
		$fecha_hoy = gmmktime(0,0,0,$mes,$dia,$anio);
		
		if($fecha_inicial < $fecha_hoy)
		{
			$error = true;
			$errores["$var"] = "�No puedes elegir una fecha inferior a hoy!";
		}
		
	}
	
	function comprobar_fecha($fecha_i, $fecha_f, &$errores, &$error, $var)
	{
		if($fecha_i>$fecha_f)
		{
			$error=true;
      		$errores["$var"]="�La fecha final debe ser superior!";
		}
		
	}
	
	function meses($fech_ini,$fech_fin) { 
   
 
   $fIni_yr=substr($fech_ini,0,4); 
    $fIni_mon=(int)substr($fech_ini,5,2); 
    $fIni_day=substr($fech_ini,8,2); 
 
   
   $fFin_yr=substr($fech_fin,0,4); 
    $fFin_mon=(int)substr($fech_fin,5,2); 
    $fFin_day=substr($fech_fin,8,2); 
 
   $yr_dif=$fFin_yr - $fIni_yr;
   
  
   if(strtotime($fech_ini) > strtotime($fech_fin)){ 
      echo 'ERROR -> la fecha inicial es mayor a la fecha final <br>'; 
      exit(); 
   } 
   else{ 
       if($yr_dif == 1){ 
         $fIni_mon = 12 - $fIni_mon; 
         $meses = $fFin_mon + $fIni_mon; 
         return $meses; 
         //LA FUNCION utf8_encode NOS SIRVE PARA PODER MOSTRAR ACENTOS Y 
         //CARACTERES RAROS 
         //echo utf8_encode("la diferencia de meses con un a�o de diferencia es -> ".$meses."<br>"); 
      } 
      else{ 
          if($yr_dif == 0){ 
			$meses=$fFin_mon - $fIni_mon; 
            return $meses; 
            //echo utf8_encode("la diferencia de meses con cero a�os de diferencia es -> ".$meses.", donde el mes inicial es ".$fIni_mon.", el mes final es ".$fFin_mon."<br>"); 
         } 
         else{ 
             if($yr_dif > 1){ 
               $fIni_mon = 12 - $fIni_mon; 
               $meses = $fFin_mon + $fIni_mon + (($yr_dif - 1) * 12); 
               return $meses; 
               //echo utf8_encode("la diferencia de meses con mas de un a�o de diferencia es -> ".$meses."<br>"); 
            } 
            else 
               echo "ERROR -> la fecha inicial es mayor a la fecha final <br>"; 
               exit(); 
         } 
      } 
   } 
 
} 
?>
<?PHP

// -----------------------------------------------------------------
// Biblioteca de variables y funciones para el manejo de fechas
// -----------------------------------------------------------------

// -----------------------------------------------------------------
// Tabla de meses
// -----------------------------------------------------------------
   $meses = array ("enero", "febrero", "marzo", "abril",
                   "mayo", "junio", "julio", "agosto",
                   "septiembre", "octubre", "noviembre", "diciembre");

// -----------------------------------------------------------------
// Convertir fecha a cadena
// -----------------------------------------------------------------
function date2string ($date)
{
   // Formato: d�a del mes (n�mero, sin ceros) /
   //          mes del a�o (n�mero, sin ceros) /
   //          a�o (cuatro d�gitos)
   // Ejemplo: 7/11/2002
   $string = date ("j/n/Y", strtotime($date));
   return ($string);
}

// -----------------------------------------------------------------
// Convertir (dia, mes, a�o) en fecha
// -----------------------------------------------------------------
function dmy2date ($dia, $mes, $anyo)
{
   $meses = array ("enero", "febrero", "marzo", "abril", "mayo",
                   "junio", "julio", "agosto", "septiembre",
                   "octubre", "noviembre", "diciembre");
   $i=0;
   $enc=0;
   while ($i<12 && !$enc)
   {
      if ($meses[$i] == $mes)
         $enc = 1;
      else
         $i++;
   }
   $fecha = date ("Y-m-d", mktime (0, 0, 0, $i+1, $dia, $anyo));
   return ($fecha);
}

// -----------------------------------------------------------------
// Obtener el d�a del mes de una fecha
// -----------------------------------------------------------------
function dayofdate ($date)
{
   $dia = date ("j", strtotime($date));
   return ($dia);
}

// -----------------------------------------------------------------
// Obtener el mes del a�o de una fecha
// -----------------------------------------------------------------
function monthofdate ($date)
{
   $mes = date ("n", strtotime($date));
   return ($mes);
}

// -----------------------------------------------------------------
// Obtener el a�o de una fecha
// -----------------------------------------------------------------
function yearofdate ($date)
{
   $anyo = date ("Y", strtotime($date));
   return ($anyo);
}

// -----------------------------------------------------------------
// Obtener la fecha de hoy
// -----------------------------------------------------------------
function today ()
{
   $todayDate = date("Y-m-d");
   return ($todayDate);
}

// -----------------------------------------------------------------
// Obtener el n�mero de días de un mes dado de un a�o dado
// -----------------------------------------------------------------
function daysofMonth ($month, $year)
{
   $ndays = date ("t", mktime (0, 0, 0, 1, $month, $year));
   return ($ndays);
}

?>