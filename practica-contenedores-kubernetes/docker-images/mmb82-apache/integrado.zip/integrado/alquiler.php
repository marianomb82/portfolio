<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
			
							<?php 
				
								if($usuario=="")
								{
									print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
									print ("<div class='margen'>&nbsp;</div>");
									print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
								}
								else
								{
								
									$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
									$nombre=(isset($_REQUEST['nombre'])) ? $_REQUEST['nombre'] : false;
									$telefono=(isset($_REQUEST['telefono'])) ? $_REQUEST['telefono'] : false;
									$insertar=(isset($_REQUEST['insertar'])) ? $_REQUEST['insertar'] : false;
									$sw=0;
									$sw1=0;
									
									
									if(!isset($_REQUEST['comienzo']))
										{
											$comienzo=0;
										 	if(isset($_SESSION['nombre']))
											{
												unset ($_SESSION['nombre']);
											}
											if(isset($_SESSION['dni']))
											{
												unset ($_SESSION['dni']);
											}
										}
										else
										{
											$comienzo=$_REQUEST['comienzo'];
										}
										$intervalo=4;
									
								?>
								
								<h2>Alquiler</h2>
	
									<form action="alquiler.php" method="post">
										<fieldset>
										<legend>Buscar gestores en la BBDD</legend>
											<p>Material: <input type="text" name="nombre" />
											DNI: <input type="text" name="dni" size="9" maxlength="9"/>
											<input type="submit" name="enviar" value="Buscar" /></p>
										</fieldset>
									</form>
									
								<?PHP
								
									// Conectar con el servidor de base de datos
									//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
									or die ("No se puede conectar con el servidor");
								
								if (isset($enviar) || isset($_SESSION['nombre']) || isset($_SESSION['dni']))
								{
									if($sw==1 && $sw1==0)
									{
										$instruccion= "select * from alquila where ID_MAT in (select ID_MAT from material where NOMBRE_MAT like '%".$_SESSION['nombre']."%') and DEVUELTO like 'No' order by FECHA_FIN asc";
										
									}
									elseif ($sw==0 && $sw1==1)
									{
										$instruccion= "select * from alquila where ID_SO in (select ID_SO from socio where DNI_SO like '%".$_SESSION['dni']."%') and DEVUELTO like 'No' order by FECHA_FIN asc";
										
									}
									elseif ($sw==1 && $sw1==1)
									{
										$instruccion= "select * from alquila where ID_MAT in (select ID_MAT from material where NOMBRE_MAT like '%".$_SESSION['nombre']."%') or ID_SO in (select ID_SO from socio where DNI_SO like '%".$_SESSION['dni']."%') and DEVUELTO like 'No' order by FECHA_FIN asc";
									}
									else
									{
										$instruccion = "select * from alquila where DEVUELTO like 'No' order by FECHA_FIN asc";
									}	
								}			
			        			else
			        			{
									$instruccion = "select * from alquila where DEVUELTO like 'No' order by FECHA_FIN asc";
			        			}
								
			        			$instruccion2 = $instruccion . " limit $comienzo,$intervalo";
					
								$consulta = mysqli_query($conexion,$instruccion) or die ("No se puede hacer la consulta1");
								
								$nfilas = mysqli_num_rows ($consulta);
								
								$consulta2 = mysqli_query($conexion,$instruccion2) or die ("No se puede hacer la consulta2");
								
								$nfilas2 = mysqli_num_rows ($consulta2);
									
			        					
										
										if($nfilas==0)
				        				{
				        					print "<center><p>No existen alquileres</p></center>";
				        				}
										else
										{
											
											print ("<form action='alquiler.php' method='post'>");
											print ("<fieldset class='margen4'>");
											print ("<legend>Listado de alquileres</legend>");
											print ("<br />");	
											$nfilas1 = mysqli_num_rows ($consulta);
											print ("<center>");     		
									    	print ("<table cellpadding='4'>");
									        print ("<tr>");
									        print ("<th>Material</th>");
									        print ("<th>DNI</th>");
									        print ("<th>Detalles</th>");
									        print ("<th>Modificar</th>");
									        print ("<th>Borrar</th>");
									        print ("</tr>");
								
									        for ($i=0; $i<$nfilas1; $i++)
									        {
									            $resultado = mysqli_fetch_array ($consulta);
									            print ("<TR>\n");
									            $instruccion3 = "select * from material where ID_MAT like '".$resultado['ID_MAT']."'";
																	
												$consulta3 = mysqli_query($conexion,$instruccion3)
													or die ("No se puede hacer la consulta1");
													
												$resultado3 = mysqli_fetch_array ($consulta3);
												
												print ("<TD>" . $resultado['NOMBRE_MAT'] . "</TD>\n");
									            
												$instruccion4 = "select * from socio where ID_SO like '".$resultado['ID_SO']."'";
																	
												$consulta4 = mysqli_query($conexion,$instruccion4)
													or die ("No se puede hacer la consulta1");
													
												$resultado4 = mysqli_fetch_array ($consulta4);
												print ("<TR>\n");
												print ("<TD>" . $resultado3['NOMBRE_MAT'] . "</TD>\n");
									            print ("<TD>" . $resultado4['DNI_SO'] . "</TD>\n");																				
									            print ("<center><TD><a href='detalle_alquiler.php?id=".$resultado['ID_AL']."'><img src='imagenes/ojo.png'></a></TD></center>\n");
									            print ("<center><TD><a href='modificar_alquiler.php?id=".$resultado['ID_AL']."'><img src='imagenes/modificar.png'></a></TD></center>\n");
									            print ("<center><TD><a href='borrar_alquiler.php?id=".$resultado['ID_AL']."'><img src='imagenes/borrar.png'></a></TD></center>\n");
									            		
									          }
									         print ("</TABLE>\n");
									         print ("</center>"); 
											     
										      
										       
										         
											print "<div class='paginado'>";
											print ("<center>"); 
											print("<table cellpadding='8'>");
											print("<tr>");
											print("<td>");
											print "<div class='anterior'>";        
											      if(($comienzo-1)<0)
												  {
												  	print "<img src='imagenes/atras_v.png' />";
												  }
												  else
												  {
												  	print "<a href='".$_SERVER['PHP_SELF']."?comienzo=".($comienzo-$intervalo)."'><img src='imagenes/atras.png' /></a> ";
												  }
											print "</div>";
											print("</td>");
											print("<td colspan='3'>");
											print "<div>"; 
												if (($comienzo+$intervalo)> $nfilas)
												  {
												      print "Mostrando de alquiler <b>".($comienzo+1)."</b> a alquiler <b>".($nfilas)."</b> de <b>$nfilas</b>  ";
												  }
												  else
												  {
												     print "Mostrando de alquiler <b>".($comienzo+1)."</b> a alquiler <b>".($comienzo+$intervalo)."</b> de <b>$nfilas</b>  ";
												  }
	
											print("</td>");
											print("<td>");
											print "<div class='anterior'>"; 
												         
												  if(($comienzo+$intervalo)>=$nfilas)
												  {
												     print "<img src='imagenes/siguiente_v.png' />";
												  }
												  else
												  {
												        print "<a href='".$_SERVER['PHP_SELF']."?comienzo=".($comienzo+$intervalo)."'><img src='imagenes/siguiente.png' /></a>";
												  }
										print "</div>";
										print("</td>");
										print("</tr>");
										print("</table>");
										print ("<center>"); 	  
									  print "</div>";
											
										// Cerrar conexión
											mysqli_close ($conexion);
									}
								}
							?>
							
								
								</fieldset>
							</form>
							<center>
							<div id="insertar">
								<table><tr><td><a href="inserta_alquiler.php"><img src="imagenes/agrega_c.png" title="Insertar alquiler"></img></a></td></tr></table>
								<p class="necesario"><i>Pinche en el icono para agregar un alquiler.</i></p>
							</div>
							</center>
							</div>
				        </td>
				  	</tr>
	           </table>
	           <div align="center">
					<?php include('includes/footerbis.php'); ?>
				</div>
		</div>
	</body>
</html>