<?php
	//@utor: Mariano Martín
	session_start();
	$login = false;
	if (isset($_SESSION['usuario'])){
		$login = true;
	}
	
	if (!isset($_SESSION['usuario'])){
		$_SESSION['destino']=$_SERVER['REQUEST_URI'];
		header('Location: login.php');
	}
	
	$usuario=$_SESSION['usuario'];
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"> 
		<title>Club Deportivo Sevilla</title>
		<link rel="stylesheet" type="text/css" href="cssbis/estilo.css" media="screen">
	    <script language="javascript" type="text/javascript" src="lib/precarga.js"></script>
	</head>

	<body onLoad="MM_preloadImages('imagenes/agregar_over.png', 'imagenes/album_over.png', 'imagenes/alta_over.png','imagenes/encuesta_over.png', 'imagenes/listar_over.png', 'imagenes/login_over.png', 'imagenes/presentacion_over.png', 'imagenes/salir_over.png',)">
		<div id="contenedor">
			<div id="cabecera">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="logo">
		            			<img id="img_logo" src="imagenes/logo_priv.png" />
		            		</div>
						</td>
						<td valign="top">
							<div id="titulo">
		             			<img src="imagenes/titulobis.png" />
		           			</div>
						</td>
					</tr>
	           </table>
			</div>
	        
	        <div id="cuerpo">
	        	
	            <table cellpadding="0" cellspacing="0">
					<tr>
						<td valign="top">
							<div id="menu">
		            			<table cellpadding="0" cellspacing="0" border="0" align="center">
	                	
	                				<?php include('includes/menu.php'); ?>
				                	
				                </table>
		            		</div>
						</td>
						<td valign="top">
							<div id="contenido">
			
							<?php 
				
								if($usuario=="")
								{
									print ("<h1>No puedes acceder, necesitas estar logado.</h1>");
									print ("<div class='margen'>&nbsp;</div>");
									print ("<div align='center'><img src='imagenes/acceso.png' /></div>");
								}
								else
								{
								
									$enviar=(isset($_REQUEST['enviar'])) ? $_REQUEST['enviar'] : false;
									$nombre=(isset($_REQUEST['nombre'])) ? $_REQUEST['nombre'] : false;
									$dni=(isset($_REQUEST['dni'])) ? $_REQUEST['dni'] : false;
									$insertar=(isset($_REQUEST['insertar'])) ? $_REQUEST['insertar'] : false;
									$sw=0;
									$sw1=0;
																		
									if(!isset($_REQUEST['comienzo']))
										{
											$comienzo=0;
										 	if(isset($_SESSION['nombre']))
											{
												unset ($_SESSION['nombre']);
											}
											if(isset($_SESSION['dni']))
											{
												unset ($_SESSION['dni']);
											}
										}
										else
										{
											$comienzo=$_REQUEST['comienzo'];
										}
										
										$intervalo=4;
									
								
								$hoy = gmmktime(0,0,0,date("n"), date("d"), date("Y"));
						
								// Conectar con el servidor de base de datos
								//variables para la conexión
						$servername = getenv("DB_HOST");
						$database = getenv("DB_NAME");
						$username = getenv("DB_USER");
						$password = getenv("DB_PASSWORD");
						
						$conexion = mysqli_connect ($servername, $username, $password,$database)
								or die ("No se puede conectar con el servidor");

								$instruccion = "INSERT INTO historial_realiza (`ID_AC`, `ID_SO`, `FECHA_IN_CONT`, `FECHA_FIN_CONT`, `IMPORTE_CONT`) select ID_AC, ID_SO, FECHA_INICIO_RE, FECHA_FIN_RE, IMPORTE_RE from realiza where FECHA_FIN_RE < $hoy";
					
								$consulta = mysqli_query($conexion,$instruccion) or die ("No se puede hacer la consulta76");
								
								$instruccion8 = "select ID_AC, ID_SO, FECHA_INICIO_RE, FECHA_FIN_RE, IMPORTE_RE from realiza where FECHA_FIN_RE < $hoy";
								
								$consulta8 = mysqli_query($conexion,$instruccion8) or die ("No se puede hacer la consulta2");
								
								$nfilas8 = mysqli_num_rows ($consulta8);
								
								for($i=0; $i<$nfilas8; $i++)
								{
									$resultado8 = mysqli_fetch_array($consulta8);
									
									$instruccion9 = "update actividad set N_PLAZAS_DIS=N_PLAZAS_DIS+1 where ID_AC like '".$resultado8['ID_AC']."'";
									
									$consulta9 = mysqli_query($conexion,$instruccion9) or die ("No se puede hacer la consulta");
								}
								
								
								$instruccion7 = "delete from realiza where FECHA_FIN_RE < $hoy";
										
								$consulta = mysqli_query( $conexion,$instruccion7) or die ("No se puede hacer la consulta2");
			
								?>
			
								<h2>contratación</h2>
	
									<form action="contratar.php" method="post">
										<fieldset>
										<legend>Buscar contratación</legend>
											<p>Nombre: <input type="text" name="nombre" />
											DNI Socio: <input type="text" name="dni" size="9" maxlength="9" />
											<input type="submit" name="enviar" value="Buscar" /></p>
										</fieldset>
									</form>
									
								<?PHP
								
									// Conectar con el servidor de base de datos
									
						$conexion = mysqli_connect ($servername, $username, $password,$database)
									or die ("No se puede conectar con el servidor");
								
									if (isset($enviar) || isset($_SESSION['nombre']) || isset($_SESSION['dni']))
									{
										if(trim($nombre)!="")
										{
											$sw=1;
											$_SESSION['nombre']=$nombre;
										}
										if (trim($dni)!="")
										{
											$sw1=1;
											$_SESSION['dni']=$dni;
										}
										
										if(isset($_SESSION['nombre']))
										{
											$sw=1;
										}
										if(isset($_SESSION['dni']))
										{
											$sw1=1;
										}
															
										if($sw==1 && $sw1==0)
										{
											$instruccion= "select * from realiza where ID_AC in (select ID_AC from actividad where NOMBRE_AC like '%".$_SESSION['nombre']."%') order by FECHA_FIN_RE asc";
											
										}
										elseif ($sw==0 && $sw1==1)
										{
											$instruccion= "select * from realiza where ID_SO in (select ID_SO from socio where DNI_SO like '%".$_SESSION['dni']."%') order by FECHA_FIN_RE asc";
											
										}
										elseif ($sw==1 && $sw1==1)
										{
											$instruccion= "select * from realiza where ID_AC in (select ID_AC from actividad where NOMBRE_AC like '%".$_SESSION['nombre']."%') or ID_SO in (select ID_SO from socio where DNI_SO like '%".$_SESSION['dni']."%') order by FECHA_FIN_RE asc";
										}
										else
										{
											$instruccion = "select * from realiza order by FECHA_FIN_RE asc";
										}				
									}										
								
									else
									{
										$instruccion = "select * from realiza order by FECHA_FIN_RE asc";
									}				
									
									$instruccion2 = $instruccion . " limit $comienzo,$intervalo";

									$consulta = mysqli_query( $conexion,$instruccion) or die ("No se puede hacer la consulta");
									
									$nfilas = mysqli_num_rows ($consulta);
									
									$consulta2 = mysqli_query( $conexion,$instruccion2) or die ("No se puede hacer la consulta");
									
									$nfilas2 = mysqli_num_rows ($consulta2);
			        						 
			        				if($nfilas==0)
			        				{
			        					print "<center><p>No existen contrataciones</p></center>";
			        				}
			        				else
			        				{
			        					print ("<form action='contratar.php' method='post'>");
										print ("<fieldset class='margen4'>");
										print ("<legend>Listado de cursos</legend>");
										print ("<br />");	
										$nfilas1 = mysqli_num_rows ($consulta);
										    if ($nfilas1 > 0)
										    {
												 print ("<center>");     		
										    	 print ("<table cellpadding='4'>");
										         print ("<tr>");
										         print ("<th>Curso</th>");
										         print ("<th>DNI cliente</th>");
										         print ("<th>Fecha inicio</th>");
										         print ("<th>Fecha fin</th>");
										         print ("<th>Importe</th>");
										         print ("<th>Detalles</th>");
										         print ("<th>Borrar</th>");
										         print ("</tr>");
										
										         for ($i=0; $i<$nfilas1; $i++)
										         {
										            $resultado = mysqli_fetch_array ($consulta);
										            print ("<TR>\n");
										            $instruccion55 = "select * from actividad where ID_AC like '".$resultado['ID_AC']."'";
										            $consulta55 = mysqli_query($conexion,$instruccion55) or die ("No se puede hacer la consulta1");
										            $resultado55 = mysqli_fetch_array ($consulta55);
										            print ("<TD>" . $resultado55['NOMBRE_AC'] . "</TD>\n");
										            $instruccion55 = "select * from socio where ID_SO like '".$resultado['ID_SO']."'";
										            $consulta55 = mysqli_query($conexion,$instruccion55) or die ("No se puede hacer la consulta2");
										            $resultado55 = mysqli_fetch_array ($consulta55);
										            print ("<TD>" . $resultado55['DNI_SO'] . "</TD>\n");
										            $fecha_i = date("d/n/Y",$resultado['FECHA_INICIO_RE']);
										            print ("<TD>" . $fecha_i . "</TD>\n");
										            $fecha_f = date("d/n/Y",$resultado['FECHA_FIN_RE']);
										            print ("<TD>" . $fecha_f . "</TD>\n");
										            print ("<TD>" . $resultado['IMPORTE_RE'] . "</TD>\n");
										            print ("<center><TD><a href='detalle_contratar.php?id=".$resultado['ID_RE']."'><img src='imagenes/ojo.png'></a></TD></center>\n");
										            print ("<center><TD><a href='borrar_contratar.php?id=".$resultado['ID_RE']."'><img src='imagenes/borrar.png'></a></TD></center>\n");
										          }
										         print ("</TABLE>\n");
										         print ("</center>"); 
										      }
										      		
										         
										print "<div class='paginado'>";
										print ("<center>"); 
										print("<table cellpadding='8'>");
										print("<tr>");
										print("<td>");
										print "<div class='anterior'>";        
										      if(($comienzo-1)<0)
											  {
											  	print "<img src='imagenes/atras_v.png' />";
											  }
											  else
											  {
											  	print "<a href='".$_SERVER['PHP_SELF']."?comienzo=".($comienzo-$intervalo)."'><img src='imagenes/atras.png' /></a> ";
											  }
										print "</div>";
										print("</td>");
										print("<td colspan='3'>");
										print "<div>"; 
											if (($comienzo+$intervalo)> $nfilas)
											  {
											      print "Mostrando de contratación <b>".($comienzo+1)."</b> a contratación <b>".($nfilas)."</b> de <b>$nfilas</b>  ";
											  }
											  else
											  {
											      print "Mostrando de contratación <b>".($comienzo+1)."</b> a contratación <b>".($comienzo+$intervalo)."</b> de <b>$nfilas</b>  ";
											  }

										print("</td>");
										print("<td>");
										print "<div class='anterior'>"; 
											         
											  if(($comienzo+$intervalo)>=$nfilas)
											  {
											     print "<img src='imagenes/siguiente_v.png' />";
											  }
											  else
											  {
											        print "<a href='".$_SERVER['PHP_SELF']."?comienzo=".($comienzo+$intervalo)."'><img src='imagenes/siguiente.png' /></a>";
											  }
									print "</div>";
									print("</td>");
									print("</tr>");
									print("</table>");
									print ("<center>"); 	  
								    print "</div>";
										
									// Cerrar conexión
										mysqli_close ($conexion);
								}
							}
						?>
							
								
								</fieldset>
							</form>
							<center>
							<div id="insertar">
								<table><tr><td><a href="inserta_contratacion.php"><img src="imagenes/agrega_c.png" title="Insertar Curso"></img></a></td></tr></table>
								<p class="necesario"><i>Pinche en el icono para agregar una contratación.</i></p>
							</div>
							</center>
							</div>
				        </td>
				  	</tr>
	           </table>
	           <div align="center">
					<?php include('includes/footerbis.php'); ?>
				</div>
		</div>
	</body>
</html>
